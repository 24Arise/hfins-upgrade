/* eslint-disable react/no-find-dom-node */
/*
 * @Author: YQS <qingsong.yang02@hand-china.com>
 * @Date: 2021-09-06 10:43:14
 * @LastEditTime: 2021-09-23 15:10:28
 * @LastEditors: YQS <qingsong.yang02@hand-china.com>
 * @Description: 高度自适应
 * @FilePath: \hfins-front-ecm-archive\src\utils\AutoRestHeight.js
 */

import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';

/**
 * @description: 自动适应高度
 * @param {*} children 子元素，
 * @param {*} diff 差距间隙，可以用作微调，
 * @param {*} topSelector 内部top位置的query selector
 * @param {*} style 自定义样式
 * @param {*} queryBarSelector query selector
 * @return {*}
 */
const AutoRestHeight = ({
  children,
  diff = 80,
  topSelector,
  style = {},
  queryBarSelector = undefined
}) => {
  const childrenRef = useRef(null);
  const frame = useRef(0);
  const [maxHeight, setMaxHeight] = useState('auto');
  useEffect(() => {
    const resize = () => {
      if (childrenRef.current) {
        const childrenRefWrapperDom = ReactDOM.findDOMNode(childrenRef.current);
        let childrenRefDom = childrenRefWrapperDom;
        let queryDom = childrenRefWrapperDom;
        if (topSelector) {
          childrenRefDom = childrenRefDom?.querySelector(topSelector);
        }
        if (queryBarSelector) {
          queryDom = queryDom?.querySelector(queryBarSelector);
        }
        const resizeObserver = new ResizeObserver(() => {
          // 监测到高度变化后需要处理的逻辑
          const { top: offsetTop } = childrenRefDom?.getBoundingClientRect();
          setMaxHeight(window.innerHeight - offsetTop - diff);
        });
        resizeObserver.observe(queryDom);
        const { top: offsetTop } = childrenRefDom.getBoundingClientRect();
        setMaxHeight(window.innerHeight - offsetTop - diff);
        if (childrenRef?.current?.handleResize) {
          childrenRef?.current?.handleResize();
        }
      }
    };
    resize();

    const handler = () => {
      cancelAnimationFrame(frame.current);
      frame.current = requestAnimationFrame(resize);
    };
    window.addEventListener('resize', handler);
    return () => {
      cancelAnimationFrame(frame.current);
      window.removeEventListener('resize', handler);
      // resizeObserver.disconnect();
    };
  }, []);

  if (React.isValidElement(children)) {
    return React.cloneElement(children, {
      ref: childrenRef,
      style: {
        ...style,
        maxHeight
      }
    });
  }
  return null;
};

export default AutoRestHeight;
