/*
 * @Author: yang.wang04@hand-china.com
 * @Date: 2021-08-05 16:31:35
 * @LastEditTime: 2021-11-22 15:58:30
 * @LastEditors: yang.wang04@hand-china.com
 * @Description: 导入配置模态框
 * @FilePath: \hscs-front-hsae\src\utils\ImportConfigModal.js
 */
import { Button, Form, Modal, Output, TextArea, Upload } from 'choerodon-ui/pro';
import { getAccessToken } from 'utils/utils';
import React from 'react';
import intl from 'utils/intl';
import notification from 'utils/notification';

const modalKey = Modal.key();

class ModalContent extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      // 导入结果
      importConfigResult: '',
      // 上传标识
      uploading: false
    };
  }

  /**
   * @description: 销毁
   * @param {*}
   * @return {*}
   */
  destroyAll() {
    Modal.destroyAll();
  }

  /**
   * @description: 上传
   * @param {*}
   * @return {*}
   */
  saveUpload = node => {
    this.upload = node;
  };

  /**
   * @description: repeat状态下的操作
   * @param {string} repeatSource 来源
   * @param {object} response 上传返回值
   * @return {*}
   */
  handleRepeatAction = async (repeatSource, response) => {
    if ((await Modal.confirm(response.message)) !== 'cancel') {
      const { tokenCache } = response;
      let resp;
      if (resp.failed) {
        notification.error({ message: resp.message });
      } else {
        notification.success({ message: resp.message });
      }
      this.setState({ importConfigResult: resp.message });
    } else {
      this.setState({ importConfigResult: '' });
    }
  };

  render() {
    const {
      name,
      action,
      accept,
      data,
      extra,
      repeatSource,
      queryFlag,
      tableDS,
      optionTips
    } = this.props;
    const props = {
      headers: {
        'Access-Control-Allow-Origin': '*',
        Authorization: `bearer ${getAccessToken()}`
      },
      name,
      action,
      multiple: false,
      accept,
      data,
      extra,
      uploadImmediately: false,
      showUploadBtn: false,
      showPreviewImage: true,
      // 上传成功
      onUploadSuccess: async res => {
        this.setState({
          uploading: false
        });
        const response = JSON.parse(res);
        try {
          if (response) {
            if (response.failed || response.status === 'ERROR') {
              this.setState({
                importConfigResult: response.message
              });
              notification.error({ message: response.message });
              return false;
            }
            if (response.status === 'REPEAT') {
              // 重复数据处理
              if (repeatSource) {
                await this.handleRepeatAction(repeatSource, response);
              }
              return true;
            }
            if (Array.isArray(response) && response.length > 0) {
              this.setState({
                importConfigResult: response
              });
              notification.info({ message: response });
              if (queryFlag) {
                tableDS.query(tableDS.currentPage);
              }
              return false;
            }
            this.setState({
              importConfigResult: response.message
            });
            notification.success({ message: response.message });
            if (queryFlag) {
              tableDS.query(tableDS.currentPage);
            }
            return false;
          }
          this.setState({
            importConfigResult: response.message
          });
          notification.error({ message: response.message });
        } catch (error) {
          notification.error({ message: error });
        }
      },
      // 上传失败
      onUploadError: (error, res) => {
        this.setState({
          uploading: false
        });
        notification.error({ message: res });
      }
    };

    // 点击上传
    const handleBtnClick = async () => {
      const { uploadValidate } = this.props;
      if (!this.upload.fileList[0]) {
        this.setState({
          uploading: false
        });
      } else if (this.upload.fileList[0] && this.upload.fileList[0].status) {
        this.setState({
          uploading: false
        });
      } else {
        this.setState({
          importConfigResult: '',
          uploading: true
        });
      }
      if (uploadValidate) {
        if (await uploadValidate()) {
          this.upload.startUpload();
        }
      } else {
        return this.upload.startUpload();
      }
    };

    return (
      <Form excludeUseColonTagList={['span', 'Button']}>
        <Output
          label={intl.get('hsae.common.button.uploadFiles').d('上传文件')}
          renderer={() => <Upload ref={this.saveUpload} {...props} />}
        />
        {optionTips}
        <Button
          loading={this.state.uploading}
          style={{ marginBottom: 10, width: 88 }}
          color="primary"
          onClick={handleBtnClick}
          disabled={this.props.commitDisabled}
        >
          {intl.get('hsae.common.button.submit').d('提交')}
        </Button>
        <Output
          label={intl.get('hsae.common.title.importInfo').d('导入信息')}
          renderer={() => (
            <TextArea
              style={{ width: '100%' }}
              placeholder={intl.get('hsae.common.title.importConfigResult').d('导入配置输出结果')}
              readOnly
              value={this.state.importConfigResult}
            />
          )}
        />
      </Form>
    );
  }
}

/**
 * @description: 打开导入配置
 * @param {string} params.title 标题
 * @param {string} params.name 发到后台的文件参数名
 * @param {string} params.action 上传的地址
 * @param {array} params.accept 接受上传的文件类型
 * @param {object} params.data 上传所需参数或返回上传参数的方法
 * @param {node} params.extra 额外的节点
 * @param {node} params.repeatSource repeat状态下需要操作的来源
 * @param {boolean} params.queryFlag 上传后是否查询
 * @param {dataSet} params.tableDS 数据集
 * @param {node} params.optionTips 操作标签
 * @param {promise} params.uploadValidate 上传校验
 * @param {boolean} params.commitDisabled 提交失效
 * @return {*}
 */
export default function openImportConfigModal(params) {
  Modal.open({
    key: modalKey,
    title: params.title || intl.get('hsae.common.title.importConfiguration').d('导入配置'),
    children: <ModalContent {...params} />,
    maskClosable: true,
    destroyOnClose: true,
    footer: null,
    closable: true
  });
}
