/**
 * @Description: 出入库列表页面
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/3/29 9:30
 * @LastEditTime: 2021/3/29 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */

import { Bind } from 'lodash-decorators';
import { Button, DataSet, Table } from 'choerodon-ui/pro/lib';
import { ButtonColor } from 'choerodon-ui/pro/lib/button/enum';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { Content, Header } from 'components/Page';
import { RouteComponentProps } from 'react-router';
import { isEmpty } from 'lodash';
import { observable } from 'mobx';
import { observer } from 'mobx-react';
import AutoResetHeight from '@common/components/AutoResetHeight';
import DocStatusProgress from '@common/components/DocStatusProgress';
import InventoryListDS from '@/pages/Inventory/stores/InventoryListDS';
import React, { Component } from 'react';
import formatterCollections from 'utils/intl/formatterCollections';
import intl from 'utils/intl';

@observer
class InventoryList extends Component<RouteComponentProps, any> {
  @observable inventoryListDS: DataSet;

  constructor(props) {
    super(props);
    this.inventoryListDS = new DataSet({ ...InventoryListDS() });
  }

  checkReadOnly(record) {
    const destructionStatus = record.get('status');
    return ['CONFIRMED'].includes(destructionStatus);
  }

  /**
   * 根据状态值确定进度条属性
   * @param string 状态值
   * @returns object 进度条属性
   */
  getProgress(status: string): number {
    let percent: number;
    if (status === 'GENERATED') {
      percent = 50;
    } else {
      percent = 100;
    }
    return percent;
  }

  @Bind()
  createDetailPage() {
    this.props.history.push('/ecm/archive-inventory-registration/create-detail');
  }

  @Bind()
  goToDetailPage(record) {
    let url;
    if (this.checkReadOnly(record)) {
      url = `/ecm/archive-inventory-registration/inventoryInfo/${record.get('inventoryHeaderId')}`;
    } else {
      url = `/ecm/archive-inventory-registration/detail/${record.get('inventoryHeaderId')}`;
    }
    this.props.history.push(url);
  }

  /**
   * 根据状态值确定进度条颜色属性
   * @param string 状态值
   * @returns object 进度条属性
   */
  @Bind()
  getProgressColor(status: string): string {
    switch (status) {
      case 'GENERATED':
        return '#1890FF';
      case 'CONFIRMED':
        return '#52C41A';
      default:
        return '#1890FF';
    }
    return '#1890FF';
  }

  columns: ColumnProps[] = [
    {
      name: 'inventoryNumber',
      width: 200,
      renderer: ({ record, value }) => {
        return (
          <a
            onClick={() => {
              this.goToDetailPage(record);
            }}
          >
            {value}
          </a>
        );
      }
    },
    {
      name: 'inventoryDate',
      width: 200
    },
    {
      name: 'employeeName',
      width: 200
    },
    {
      name: 'inventoryCategoryName',
      width: 200
    },
    {
      name: 'note'
    },
    {
      name: 'statusName',
      width: 200,
      renderer: ({ record, value }) => (
        <div>
          <DocStatusProgress
            percent={this.getProgress(record?.get('status'))}
            status={record?.get('status')}
            statusText={value}
          />
        </div>
      )
    }
  ];

  render() {
    return (
      <>
        <Header title={intl.get('hfsecm.archive.inventoryRegistration.registrationList')}>
          <Button color={ButtonColor.primary} onClick={() => this.createDetailPage()}>
            {intl.get('hfsecm.common.createDoc')}
          </Button>
          {!isEmpty(this.inventoryListDS.selected) && (
            <>
              <Button onClick={() => this.inventoryListDS.delete(this.inventoryListDS.selected)}>
                {intl.get('hfsecm.common.delete')}
              </Button>
            </>
          )}
        </Header>
        <Content>
          <AutoResetHeight topSelector=".c7n-pro-table">
            <Table queryFieldsLimit={3} dataSet={this.inventoryListDS} columns={this.columns} />
          </AutoResetHeight>
        </Content>
      </>
    );
  }
}

export default formatterCollections({
  code: ['hfsecm.common', 'hfsecm.archive.inventoryRegistration']
})(InventoryList);
