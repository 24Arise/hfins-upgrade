/**
 * @Description: 出入库详情页面只读
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/4/12 9:30
 * @LastEditTime: 2021/4/12 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { Card, Col, Row } from 'choerodon-ui';
import { ColumnAlign } from 'choerodon-ui/pro/lib/table/enum';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { Content, Header } from 'components/Page';
import { DataSet, Icon, Table, Tooltip } from 'choerodon-ui/pro/lib';
import { RouteComponentProps } from 'react-router';
import { observable } from 'mobx';
import { observer } from 'mobx-react';
import Collapse from '@common/components/Collapse';
import HeaderDS from '@/pages/Inventory/stores/HeaderDS';
import LineDS from '@/pages/Inventory/stores/LineDS';
import React, { Component } from 'react';
import formatterCollections from 'utils/intl/formatterCollections';
import intl from 'utils/intl';

import './index.module.less';
import { Bind } from 'lodash-decorators';
import { DocStatusColor } from '@common/utils/enum';

@observer
class InventoryDetail extends Component<RouteComponentProps> {
  headerDS: DataSet;

  lineDS: DataSet;

  @observable
  loading = true;

  constructor(props) {
    super(props);

    const {
      match: { params }
    } = props;
    this.headerDS = new DataSet({ ...HeaderDS(params?.inventoryHeaderId) });
    this.lineDS = new DataSet({ selection: false, ...LineDS() });
    this.lineDS.bind(this.headerDS, 'inventoryLineList');
  }

  componentDidMount() {
    this.headerDS.query().then(() => {
      this.loading = false;
    });
  }

  /**
   * 渲染头样式
   */
  @Bind()
  renderHeader() {
    const header = this.headerDS.current;
    const statusColor = DocStatusColor[header?.get('status')];
    return (
      <div className="header">
        <div className="docNumber">{header?.get('inventoryNumber')}</div>
        <div className="docStatus" style={{ color: statusColor, background: `${statusColor}3b` }}>
          {header?.get('statusName')}
        </div>
      </div>
    );
  }

  columns: ColumnProps[] = [
    {
      name: 'bookletNumberObject',
      align: ColumnAlign.center,
      width: 250
    },
    {
      name: 'boxNumber',
      align: ColumnAlign.center,
      width: 250
    },
    {
      name: 'roomObject',
      align: ColumnAlign.center,
      width: 250
    },
    {
      name: 'roomLocationObj',
      align: ColumnAlign.center
    },
    {
      name: 'shelfLocationObj',
      align: ColumnAlign.center
    },
    {
      name: 'layerLocationObject',
      align: ColumnAlign.center
    },
    {
      name: 'seqNumber',
      align: ColumnAlign.center
    }
  ];

  render() {
    const header = this.headerDS.current;
    return (
      <>
        <Header title={this.renderHeader()} backPath="/ecm/archive-inventory-registration/list" />
        <Content>
          <Collapse defaultActiveKey={['1', '2']}>
            <Collapse.Panel
              header={intl.get('hfsecm.archive.inventoryRegistration.inventoryRegistration')}
              key="1"
            >
              <Card className="docCard">
                <div className="alignCenter">
                  <p className="employeeName">{header?.get('employeeName')}</p>
                  <p className="dateStyle">
                    <Icon type="update" />
                    {header?.get('inventoryDate')?.format('YYYY-MM-DD')}
                  </p>
                </div>
                <div className="contentItem">
                  <Row>
                    <Col span={6}>
                      <label className="fieldDesc">
                        {intl.get('hfsecm.archive.inventoryRegistration.businessCategory')}
                      </label>
                      {header?.get('inventoryCategoryName')}
                    </Col>
                    <Col span={6}>
                      <label className="fieldDesc">
                        {intl.get('hfsecm.archive.inventoryRegistration.sourceDocumentNumber')}
                      </label>
                      {header?.get('sourceDocumentNumber')}
                    </Col>
                  </Row>
                  <Row>
                    <span>
                      <label className="fieldDesc">
                        {intl.get('hfsecm.archive.inventoryRegistration.note')}
                      </label>
                      <Tooltip title={header?.get('note')}>{header?.get('note')}</Tooltip>
                    </span>
                  </Row>
                </div>

                {/* {HeaderColumnsRenderer(header, showMore ? [...columns, ...moreColumns] : columns)}
                {moreColumns && (
                  <div style={{ textAlign: 'center' }}>
                    <a onClick={() => onClick(!showMore)}>
                      {intl.get(`hfins.con.conCreate.${showMore ? 'retract' : 'more'}`)}&nbsp;
                      <Icon type={showMore ? 'pull-up' : 'pull-down'} />
                    </a>
                  </div>
                )}
                {children} */}
              </Card>
              {/* <Row type="flex" justify="space-between" align="middle" className={styles.headerItem}>
                <Col className={styles.alignCenter}>
                  <span className={styles.employeeName}>{header?.get('employeeName')}</span>
                  <span className={styles.dateStyle}>
                    <Icon type="update" />
                    {header?.get('inventoryDate')?.format('YYYY-MM-DD')}
                  </span>
                </Col>
              </Row>
              <div className={styles.contentItem}>
                <Row>
                  <Col span={6}>
                    <label className={styles.fieldDesc}>
                      {intl.get('hfsecm.archive.inventoryRegistration.businessCategory')}
                    </label>
                    {header?.get('inventoryCategoryName')}
                  </Col>
                  <Col span={6}>
                    <label className={styles.fieldDesc}>
                      {intl.get('hfsecm.archive.inventoryRegistration.sourceDocumentNumber')}
                    </label>
                    {header?.get('sourceDocumentNumber')}
                  </Col>
                </Row>
                <Row>
                  <span>
                    <label className={styles.fieldDesc}>
                      {intl.get('hfsecm.archive.inventoryRegistration.note')}
                    </label>
                    <Tooltip title={header?.get('note')}>{header?.get('note')}</Tooltip>
                  </span>
                </Row>
              </div> */}
            </Collapse.Panel>
            <Collapse.Panel header={intl.get('hfsecm.archive.inventoryRegistration.list')} key="2">
              <Table dataSet={this.lineDS} columns={this.columns} />
            </Collapse.Panel>
          </Collapse>
        </Content>
      </>
    );
  }
}

export default formatterCollections({
  code: ['hfsecm.common', 'hfsecm.archive.inventoryRegistration']
})(InventoryDetail);
