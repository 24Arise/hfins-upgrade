/**
 * @Description: 出入库详情页面
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/3/29 9:30
 * @LastEditTime: 2021/3/29 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { Bind } from 'lodash-decorators';
import {
  Button,
  DataSet,
  DatePicker,
  Form,
  Lov,
  Select,
  Table,
  TextArea,
  TextField
} from 'choerodon-ui/pro/lib';
import { ButtonColor } from 'choerodon-ui/pro/lib/button/enum';
import { ColumnAlign, SelectionMode, TableButtonType } from 'choerodon-ui/pro/lib/table/enum';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { Content, Header } from 'components/Page';
import { RouteComponentProps } from 'react-router';
import { action, observable } from 'mobx';
import { getCurrentOrganizationId } from 'utils/utils';
import { observer } from 'mobx-react';
import { showEditor } from '@common/utils/editor';
// import { updateTab } from 'utils/menuTab';
import Collapse from '@common/components/Collapse';
import HeaderDS from '@/pages/Inventory/stores/HeaderDS';
import LineDS from '@/pages/Inventory/stores/LineDS';
import React, { Component } from 'react';
import ScanDS from '@/pages/Inventory/stores/ScanDS';
import commonConfig from '@common/config/commonConfig';
import formatterCollections from 'utils/intl/formatterCollections';
import intl from 'utils/intl';
import request from '@common/utils/request';

import { Buttons } from 'choerodon-ui/pro/lib/table/Table';
import { isEmpty } from 'lodash';

@observer
class InventoryDetail extends Component<RouteComponentProps> {
  @observable
  inventoryHeaderId: string;

  @observable
  inventoryNumber: string | null = null;

  @observable
  preTime: number = Date.now();

  @observable
  autoFlag = false; // 自动创建行标志

  scanDS: DataSet;

  headerDS: DataSet;

  lineDS: DataSet;

  constructor(props) {
    super(props);
    const {
      match: { params }
    } = props;
    this.inventoryHeaderId = params?.inventoryHeaderId;
    this.scanDS = new DataSet({
      ...ScanDS(),
      events: {
        update: ({ name, value }) => {
          if (name === 'archiveElement') {
            if (value === 'BOX') {
              this.lineDS.getField('bookletNumberObject')?.set('required', false);
              this.lineDS.getField('bookletBoxObject')?.set('required', true);
            } else {
              this.lineDS.getField('bookletNumberObject')?.set('required', true);
              this.lineDS.getField('bookletBoxObject')?.set('required', false);
            }
          }
        }
      }
    });

    this.lineDS = new DataSet({
      ...LineDS(),
      events: {
        update: this.handleLineUpdate,
        load: ({ dataSet }) => {
          const record = dataSet.get(0);
          const data = !record?.get('boxNumber') ? 'BOOKLET' : 'BOX';
          this.scanDS.create({ archiveElement: data }, 0);
        }
      }
    });

    this.headerDS = new DataSet({
      ...HeaderDS(this.inventoryHeaderId),
      // children: {
      //   lines: this.lineDS
      // },
      events: {
        update: this.handleHeaderUpdate,
        load: ({ dataSet }) => {
          this.lineDS
            .getField('bookletNumberObject')
            ?.setLovPara('inventoryHeaderId', this.inventoryHeaderId);
          this.lineDS
            .getField('bookletBoxObject')
            ?.setLovPara('inventoryHeaderId', this.inventoryHeaderId);

          this.lineDS
            .getField('bookletNumberObject')
            ?.setLovPara('inventoryCategory', dataSet.current?.get('inventoryCategory'));
          this.lineDS
            .getField('bookletBoxObject')
            ?.setLovPara('inventoryCategory', dataSet.current?.get('inventoryCategory'));
        }
      }
    });
  }

  componentDidMount() {
    this.lineDS.bind(this.headerDS, 'lines');
    if (this.inventoryHeaderId) {
      this.headerDS.query().then((resp: any) => {
        this.autoFlag = ['BORROW', 'RETURN', 'OUTBOUND'].includes(resp?.inventoryCategory);
      });
    } else {
      this.queryHeaderInitData(this.inventoryHeaderId);
    }
  }

  @action
  setInventoryNumber(value) {
    this.inventoryNumber = value;
  }

  @Bind
  async handleHeaderUpdate({ record, name, value }) {
    if (name === 'inventoryCategory') {
      record.set('sourceDocumentNumberObj', null);
      this.autoFlag = ['BORROW', 'RETURN', 'OUTBOUND'].includes(value);
      this.lineDS.removeAll();
      this.lineDS.getField('bookletNumberObject')?.setLovPara('inventoryCategory', value);
      this.lineDS.getField('bookletBoxObject')?.setLovPara('inventoryCategory', value);
    }
    if (name === 'sourceDocumentNumberObj' && value) {
      await this.lineDS.deleteAll(false).then(async () => {
        const url = `${
          commonConfig.ECM_API
        }/v1/${getCurrentOrganizationId()}/archive-inventory/line/by-source-document-id`;
        await request(url, {
          method: 'get',
          params: {
            inventoryCategory: record?.get('inventoryCategory'),
            sourceDocumentId: value.sourceDocumentId
          }
        }).then((resp: any) => {
          if (resp) {
            resp.forEach(record => {
              this.lineDS.create(record);
            });
          }
        });
      });
    }
  }

  @Bind
  handleLineUpdate({ record, name }) {
    if (name === 'roomObject') {
      record.set('roomLocationObj', null);
      record.set('shelfLocationObj', null);
      record.set('layerLocationObject', null);
      record.set('seqNumber', null);
    } else if (name === 'roomLocationObj') {
      record.set('shelfLocationObj', null);
      record.set('layerLocationObject', null);
      record.set('seqNumber', null);
    } else if (name === 'shelfLocationObj') {
      record.set('layerLocationObject', null);
      record.set('seqNumber', null);
    } else if (name === 'layerLocationObject') {
      record.set('seqNumber', null);
    }
  }

  /**
   * 查询头初始化数据
   */
  async queryHeaderInitData(inventoryHeaderId: string) {
    try {
      const data = await request(
        `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/header`,
        { data: { inventoryHeaderId }, method: 'get' }
      );
      this.headerDS.create(data);
    } catch (e) {
      console.error(`错误${e}`);
    }
  }

  @Bind
  /**
   * 从档案扫描处添加行数据
   */
  async handAddLineData(bookletNumber: string) {
    if (isEmpty(bookletNumber)) {
      return;
    }
    await request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/booklet-get-line`,
      {
        method: 'get',
        params: {
          bookletNumber
        }
      }
    ).then((res: any) => {
      this.setInventoryNumber(null);
      this.lineDS.create(res);
    });
  }

  /**
   * 节流函数
   * @param value
   * @param delay
   */
  @Bind
  throttle(value: string, delay: number) {
    const doTime = Date.now();
    if (doTime - this.preTime >= delay) {
      this.handAddLineData(value);
      this.preTime = Date.now();
    }
  }

  @Bind
  /**
   * 删除
   */
  async handleDelete() {
    await this.headerDS
      .delete(this.headerDS.current, intl.get('hfsecm.common.confirmToDeleteTheDocument'))
      .then((res: any) => {
        if (res) {
          const { history } = this.props;
          history.push('/ecm/archive-inventory-registration/list');
          // updateTab({
          //   path: '/ecm/archive-inventory-registration/list',
          //   key: 'list'
          // });
        }
      });
  }

  @Bind
  /**
   * 保存
   */
  async handleSave() {
    await this.headerDS.submit().then((success: any) => {
      if (success && success.content) {
        if (this.headerDS.current?.get('inventoryHeaderId')) {
          this.headerDS.setQueryParameter(
            'inventoryHeaderId',
            success.content[0]?.inventoryHeaderId
          );
          this.headerDS.query();
        } else {
          this.props.history.push(
            `/ecm/archive-inventory-registration/detail/${success.content[0]?.inventoryHeaderId}`
          );
        }
      }
    });
    // }
  }

  @Bind
  /**
   * 确认
   */
  async handleSubmit() {
    if (this.headerDS.dirty) {
      await this.headerDS.submit();
    }
    request(`${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/confirm`, {
      method: 'POST',
      data: this.headerDS.current?.toJSONData()
    }).then(success => {
      if (success) {
        const { history } = this.props;
        history.replace('/ecm/archive-inventory-registration');
      }
    });
  }

  @Bind
  changeState(value) {
    this.setInventoryNumber(value);
  }

  columns: ColumnProps[] = [
    {
      name: 'bookletNumberObject',
      align: ColumnAlign.center,
      editor: (record, name) =>
        showEditor(record, name) &&
        !this.autoFlag &&
        this.scanDS.current?.get('archiveElement') !== 'BOX'
    },
    {
      name: 'bookletBoxObject',
      align: ColumnAlign.center,
      editor: (record, name) =>
        showEditor(record, name) &&
        !this.autoFlag &&
        this.scanDS.current?.get('archiveElement') === 'BOX'
    },
    {
      name: 'roomObject',
      align: ColumnAlign.center,
      editor: (record, name) => showEditor(record, name) && !this.autoFlag
    },
    {
      name: 'roomLocationObj',
      align: ColumnAlign.center,
      editor: (record, name) => showEditor(record, name) && !this.autoFlag
    },
    {
      name: 'shelfLocationObj',
      align: ColumnAlign.center,
      editor: (record, name) => showEditor(record, name) && !this.autoFlag
    },
    {
      name: 'layerLocationObject',
      align: ColumnAlign.center,
      editor: (record, name) => showEditor(record, name) && !this.autoFlag
    },
    {
      name: 'seqNumber',
      align: ColumnAlign.center,
      editor: (record, name) => showEditor(record, name) && !this.autoFlag
    }
  ];

  handleAddLines = async () => {
    const { archiveElement, archiveNumber = null } = this.scanDS.current?.toJSONData();
    if (archiveNumber) {
      const url = `${
        commonConfig.ECM_API
      }/v1/${getCurrentOrganizationId()}/archive-inventory/line/by-number`;
      const params = {
        page: 0,
        size: 10,
        inventoryType: archiveElement,
        number: archiveNumber
      };
      const res: any = await this.fetchLovParam(url, params);
      if (res && !res.failed) {
        this.scanDS.current?.set('archiveNumber', null);
        this.lineDS.create({ ...res[0] }, 0);
      }
    }
  };

  fetchLovParam = (url, params) => {
    return request(url, {
      method: 'GET',
      params
    });
  };

  getButtons(): Array<Buttons> {
    const edit = !this.autoFlag && this.headerDS.current?.get('inventoryCategory');
    if (!edit) {
      return [];
    }
    return [
      <Button icon="playlist_add" onClick={() => this.lineDS.create({}, 0)}>
        {intl.get('hfsecm.common.add')}
      </Button>,
      TableButtonType.delete
    ];
  }

  render() {
    return (
      <>
        <Header
          title={intl.get('hfsecm.common.createDoc')}
          backPath="/ecm/archive-inventory-registration/list"
        >
          <Button onClick={this.handleSave} color={ButtonColor.primary}>
            {intl.get('hfsecm.common.save')}
          </Button>
          {this.headerDS.current?.get('inventoryNumber') && (
            <>
              <Button onClick={this.handleDelete} color={ButtonColor.primary}>
                {intl.get('hfsecm.common.delete')}
              </Button>
              <Button color={ButtonColor.primary} onClick={this.handleSubmit}>
                {intl.get('hfsecm.common.confirm')}
              </Button>
            </>
          )}
        </Header>
        <Content>
          <Collapse defaultActiveKey={['1', '2', '3']}>
            <Collapse.Panel
              header={intl.get('hfsecm.archive.inventoryRegistration.inventoryRegistration')}
              key="1"
            >
              <Form dataSet={this.headerDS} columns={3}>
                <TextField name="inventoryNumber" />
                <Select name="employeeObj" />
                <DatePicker name="inventoryDate" />
                <Select name="inventoryCategory" />
                <Lov name="sourceDocumentNumberObj" />
                <TextArea colSpan={4} rowSpan={2} name="note" style={{ height: 80 }} newLine />
              </Form>
            </Collapse.Panel>
            {['INBOUND', 'ADJUSTMENT'].indexOf(this.headerDS.current?.get('inventoryCategory')) >
              -1 && (
              <Collapse.Panel
                header={intl.get('hfsecm.archive.inventoryRegistration.scanBookletNumber')}
                key="2"
              >
                <Select
                  dataSet={this.scanDS}
                  name="archiveElement"
                  placeholder={intl.get('hfsecm.common.select')}
                  style={{ marginRight: 20, width: 200 }}
                  disabled={this.lineDS?.length > 0}
                />
                <TextField
                  dataSet={this.scanDS}
                  style={{ width: 320 }}
                  name="archiveNumber"
                  placeholder={intl.get('hfsecm.common.scan')}
                  disabled={!this.scanDS.current?.get('archiveElement')}
                  onEnterDown={() => {
                    this.handleAddLines();
                  }}
                />
              </Collapse.Panel>
            )}

            <Collapse.Panel header={intl.get('hfsecm.archive.inventoryRegistration.list')} key="3">
              <Table
                dataSet={this.lineDS}
                buttons={this.getButtons()}
                columns={this.columns}
                selectionMode={!this.autoFlag ? SelectionMode.rowbox : SelectionMode.none}
              />
            </Collapse.Panel>
          </Collapse>
        </Content>
      </>
    );
  }
}

export default formatterCollections({
  code: ['hfsecm.common', 'hfsecm.archive.inventoryRegistration']
})(InventoryDetail);
