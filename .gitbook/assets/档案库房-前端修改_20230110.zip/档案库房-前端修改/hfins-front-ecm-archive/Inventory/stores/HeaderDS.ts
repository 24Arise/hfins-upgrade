/**
 * @Description: 出入库详情页面定义
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/3/29 9:30
 * @LastEditTime: 2021/3/29 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldIgnore, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (inventoryHeaderId: string): DataSetProps => ({
  transport: {
    read: (config): AxiosRequestConfig => {
      return {
        ...config,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/header`,
        method: 'GET'
      };
    },
    submit: ({ data, params }): AxiosRequestConfig => {
      return {
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory`,
        method: 'POST',
        params,
        data: data[0]
      };
    },
    destroy: ({ data, params }): AxiosRequestConfig => {
      return {
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory`,
        params,
        data,
        method: 'DELETE'
      };
    }
  },
  autoQueryAfterSubmit: false,
  autoQuery: false,
  primaryKey: 'inventoryHeaderId',
  queryParameter: {
    inventoryHeaderId
  },
  fields: [
    {
      name: 'inventoryHeaderId',
      type: FieldType.string
    },
    {
      name: 'inventoryNumber',
      type: FieldType.string,
      format: FieldFormat.uppercase,
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationNumber'),
      disabled: true
    },
    {
      name: 'employeeObj',
      type: FieldType.object,
      ignore: FieldIgnore.always,
      label: intl.get('hfsecm.archive.inventoryRegistration.registrant'),
      required: true,
      lookupUrl: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/employees`,
      textField: 'employeeName',
      valueField: 'employeeId'
    },
    {
      name: 'employeeId',
      bind: 'employeeObj.employeeId'
    },
    {
      name: 'employeeName',
      bind: 'employeeObj.employeeName'
    },
    {
      name: 'inventoryDate',
      type: FieldType.date,
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationDate'),
      defaultValue: new Date(),
      required: true
    },
    {
      name: 'inventoryCategory',
      type: FieldType.string,
      lookupCode: 'HFSECM.INVENTORY_CATEGORY',
      required: true,
      textField: 'meaning',
      valueField: 'value',
      label: intl.get('hfsecm.archive.inventoryRegistration.businessCategory'),
      dynamicProps: {
        disabled: ({ record }) => record.get('inventoryHeaderId')
      }
    },
    {
      name: 'sourceDocumentNumberObj',
      type: FieldType.object,
      ignore: FieldIgnore.always,
      textField: 'sourceDocumentNumber',
      valueField: 'sourceDocumentId',
      label: intl.get('hfsecm.archive.inventoryRegistration.sourceDocumentNumber'),
      lovCode: 'HFSECM.INVENTORY_SOURCE_DOC',
      cascadeMap: { inventoryCategory: 'inventoryCategory' },
      dynamicProps: {
        disabled: ({ record }) => {
          return ['ADJUSTMENT', 'INBOUND'].includes(record.get('inventoryCategory'));
        },
        required: ({ record }) => {
          return !['ADJUSTMENT', 'INBOUND'].includes(record.get('inventoryCategory'));
        },
        lovPara: ({ record }) => {
          return { inventoryCategory: record.get('inventoryCategory') };
        }
      }
    },
    {
      name: 'sourceDocumentNumber',
      type: FieldType.string,
      bind: 'sourceDocumentNumberObj.sourceDocumentNumber'
    },
    {
      name: 'sourceDocumentId',
      type: FieldType.string,
      bind: 'sourceDocumentNumberObj.sourceDocumentId'
    },
    {
      name: 'status',
      type: FieldType.string
    },
    {
      name: 'note',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.inventoryRegistration.note')
    }
  ]
});
