/**
 * @Description: 出入库详情页面定义
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/3/29 9:30
 * @LastEditTime: 2021/3/29 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldIgnore, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  transport: {
    read: (config): AxiosRequestConfig => {
      return {
        ...config,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/lines`,
        method: 'GET'
      };
    },
    destroy: (config): AxiosRequestConfig => {
      return {
        ...config,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/line`,
        method: 'DELETE'
      };
    }
  },
  // primaryKey: 'inventoryHeaderId',
  fields: [
    // {
    //   name: 'inventoryHeaderId',
    //   type: FieldType.string
    // },
    {
      name: 'bookletNumberObject',
      type: FieldType.object,
      label: intl.get('hfsecm.archive.inventoryRegistration.bookletNumber'),
      ignore: FieldIgnore.always,
      lovCode: 'HFSECM.ARCHIVE_BOOKLET',
      required: true
    },
    {
      name: 'bookletId',
      // required: true,
      type: FieldType.string,
      bind: 'bookletNumberObject.bookletId'
    },
    {
      name: 'bookletNumber',
      type: FieldType.string,
      format: FieldFormat.uppercase,
      bind: 'bookletNumberObject.bookletNumber'
    },
    // {
    //   name: 'boxId',
    //   type: FieldType.string,
    //   bind: 'bookletNumberObject.boxId'
    // },
    {
      name: 'bookletBoxObject',
      type: FieldType.object,
      label: intl.get('hfsecm.archive.inventoryRegistration.boxNumber'),
      ignore: FieldIgnore.always,
      lovCode: 'HFSECM.ARCHIVE_BOX',
      textField: 'boxNumber',
      valueField: 'boxId',
      required: false
    },
    {
      name: 'boxId',
      // required: true,
      type: FieldType.string,
      bind: 'bookletBoxObject.boxId'
    },
    {
      name: 'boxNumber',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.inventoryRegistration.boxNumber'),
      format: FieldFormat.uppercase,
      bind: 'bookletBoxObject.boxNumber'
    },
    {
      name: 'roomObject',
      type: FieldType.object,
      label: intl.get('hfsecm.archive.inventoryRegistration.archiveRoom'),
      ignore: FieldIgnore.always,
      lovCode: 'HFSECM.ARCHIVE_ROOM',
      textField: 'roomName',
      valueField: 'roomId',
      required: true
    },
    {
      name: 'roomName',
      required: true,
      type: FieldType.intl,
      bind: 'roomObject.roomName'
    },
    {
      name: 'roomId',
      type: FieldType.string,
      bind: 'roomObject.roomId'
    },
    {
      name: 'roomCode',
      type: FieldType.string,
      bind: 'roomObject.roomCode'
    },
    {
      name: 'layerLocationObject',
      type: FieldType.object,
      ignore: FieldIgnore.always,
      label: intl.get('hfsecm.archive.inventoryRegistration.location'),
      lovCode: 'HFSECM.LOCATION_LAYER_GRID',
      cascadeMap: { roomCode: 'roomCode', shelfLocationCode: 'shelfLocationCode' },
      textField: 'layerGridLocationName',
      valueField: 'layerLocationId',
      required: true
    },
    {
      name: 'layerLocationId',
      required: true,
      type: FieldType.string,
      bind: 'layerLocationObject.layerLocationId'
    },
    {
      name: 'gridLocationId',
      type: FieldType.string,
      bind: 'layerLocationObject.gridLocationId'
    },
    {
      name: 'layerGridLocationName',
      type: FieldType.string,
      bind: 'layerLocationObject.layerGridLocationName'
    },
    {
      name: 'roomLocationObj',
      type: FieldType.object,
      ignore: FieldIgnore.always,
      textField: 'locationName',
      valueField: 'locationCode',
      lovCode: 'HFSECM.ARCHIVE_LOCATION',
      cascadeMap: { roomCode: 'roomCode' },
      required: true,
      label: intl.get('hfsecm.archive.inventoryRegistration.archivesRoom').d('档案室'),
      lovPara: {
        locationType: 'ROOM'
      }
    },
    {
      name: 'roomLocationId',
      type: FieldType.string,
      bind: 'roomLocationObj.locationId'
    },
    {
      name: 'roomLocationName',
      type: FieldType.string,
      bind: 'roomLocationObj.locationName'
    },
    {
      name: 'roomLocationCode',
      type: FieldType.string,
      bind: 'roomLocationObj.locationCode'
    },
    {
      name: 'shelfLocationObj',
      type: FieldType.object,
      ignore: FieldIgnore.always,
      lovCode: 'HFSECM.ARCHIVE_LOCATION_SHELF',
      label: intl.get('hfsecm.archive.inventoryRegistration.fileRack').d('档案架'),
      textField: 'locationCode',
      valueField: 'locationId',
      cascadeMap: { roomCode: 'roomCode', parentLocationCode: 'roomLocationCode' },
      required: true,
      lovPara: {
        locationType: 'SHELF'
      }
    },
    {
      name: 'shelfLocationName',
      type: FieldType.string,
      bind: 'shelfLocationObj.locationName'
    },
    {
      name: 'shelfLocationId',
      type: FieldType.string,
      bind: 'shelfLocationObj.locationId'
    },
    {
      name: 'shelfLocationCode',
      type: FieldType.string,
      bind: 'shelfLocationObj.locationCode'
    },
    {
      name: 'seqNumber',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.inventoryRegistration.latticeNumber').d('格子序号')
    },
    {
      name: 'inventoryType',
      type: FieldType.string,
      defaultValue: 'BOOKLET'
    }
  ]
});
