/**
 * @Description: 出入库登记主页面定义
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/3/29 9:30
 * @LastEditTime: 2021/3/29 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldIgnore, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory/main`,
      method: 'GET'
    }),
    destroy: ({ data }) => {
      return {
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive-inventory`,
        data,
        method: 'DELETE'
      };
    }
  },
  autoQuery: true,
  fields: [
    {
      name: 'inventoryNumber',
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationNumber'),
      type: FieldType.string,
      format: FieldFormat.uppercase
    },
    {
      name: 'inventoryDate',
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationDate'),
      type: FieldType.date
    },
    {
      name: 'employeeName',
      label: intl.get('hfsecm.archive.inventoryRegistration.registrant'),
      type: FieldType.string
    },
    {
      name: 'inventoryCategoryName',
      label: intl.get('hfsecm.archive.inventoryRegistration.businessCategory'),
      type: FieldType.string
    },
    {
      name: 'statusName',
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationStatus'),
      type: FieldType.string
    },
    {
      name: 'note',
      label: intl.get('hfsecm.archive.inventoryRegistration.note'),
      type: FieldType.string
    }
  ],
  queryFields: [
    {
      name: 'inventoryNumber',
      type: FieldType.string,
      format: FieldFormat.uppercase,
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationNumber')
    },
    {
      name: 'inventoryDate',
      type: FieldType.date,
      ignore: FieldIgnore.always,
      range: ['inventoryDateFrom', 'inventoryDateTo'],
      label: intl.get('hfsecm.archive.inventoryRegistration.registrationDate')
    },
    {
      name: 'inventoryDateFrom',
      type: FieldType.date,
      bind: 'inventoryDate.inventoryDateFrom'
    },
    {
      name: 'inventoryDateTo',
      type: FieldType.date,
      bind: 'inventoryDate.inventoryDateTo'
    },
    {
      name: 'employeeObj',
      type: FieldType.object,
      lovCode: 'HFSECM.EMPLOYEE',
      valueField: 'employeeId',
      textField: 'employeeName',
      label: intl.get('hfsecm.archive.inventoryRegistration.registrant')
    },
    {
      name: 'employeeId',
      type: FieldType.string,
      bind: 'employeeObj.employeeId'
    }
  ]
});
