/**
 * @Description: 条码扫描DS
 * @Author: wangxincheng <xincheng.wang@hand-china.com>
 * @Date: 2022/9/5 9:30
 * @LastEditTime: 2022/9/5 19:30
 * @Copyright: Copyright (c) 2022, Hand
 */
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldType } from 'choerodon-ui/dataset/data-set/enum';
// import intl from 'utils/intl';

export default (): DataSetProps => ({
  autoQuery: false,
  // autoCreate: true,
  // primaryKey: 'archiveId',
  fields: [
    {
      name: 'archiveElement',
      type: FieldType.string,
      label: '档案元素',
      lookupCode: 'HFSECM.INVENTORY_TYPE'
    },
    {
      name: 'archiveNumber',
      type: FieldType.string,
      label: '请扫描'
    }
  ]
});
