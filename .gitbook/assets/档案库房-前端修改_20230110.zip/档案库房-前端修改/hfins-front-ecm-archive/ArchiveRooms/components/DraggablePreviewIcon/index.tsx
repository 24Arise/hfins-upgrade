import { Icon } from 'choerodon-ui';
import { Modal } from 'choerodon-ui/pro';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import RoomStore from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/stores/RoomStore';
import style from './index.module.less';

interface DraggablePreviewIconProps {
  roomStore: RoomStore;
}

const DraggablePreviewIcon: React.FC<DraggablePreviewIconProps> = ({ roomStore }) => {
  const { currentRoomId } = roomStore;
  const previewUrl = useMemo(() => 'http://42.192.88.189:12306/pages/index.html?buildId=38', [
    currentRoomId
  ]);

  // 缩略图大小
  const iconSize = useMemo(
    () => ({
      height: 80,
      width: 80
    }),
    []
  );

  // 3D图缩放比例
  const scaleProportion = 0.1;

  // 右下角坐标
  const [coordinate, setCoordinate] = useState<{ x: number; y: number }>({
    x: iconSize.width,
    y: 250
  });

  const [hiddenFlag, setHiddenFlag] = useState(false);

  const wrapperRef: any = useRef();

  const handleMouseDown = e => {
    e.preventDefault();
    e.stopPropagation();
    e.persist();
    document.addEventListener('mousemove', handleMouseMove);
  };

  const handleMouseMove = useCallback(e => {
    let x = document.body.clientWidth - e.clientX + iconSize.width / 2;
    let y = document.body.clientHeight - e.clientY + iconSize.height / 2;
    if (x < iconSize.width) {
      x = iconSize.width;
    } else if (x > document.body.clientWidth) {
      x = document.body.clientWidth;
    }

    if (y < iconSize.height) {
      y = iconSize.height;
    } else if (y > document.body.clientHeight) {
      y = document.body.clientHeight;
    }

    setCoordinate({ x, y });
  }, []);

  const handleFullScreen = e => {
    e.stopPropagation();
    setHiddenFlag(true);
    Modal.open({
      footer: null,
      closable: true,
      destroyOnClose: true,
      fullScreen: true,
      autoCenter: true,
      className: 'hfins-ec-modal',
      afterClose: () => setHiddenFlag(false),
      children: (
        <iframe
          title="3D打印"
          width="100%"
          height="90%"
          scrolling="no"
          frameBorder={0}
          src={previewUrl}
        />
      )
    });
  };

  const handleMouseUp = e => {
    e.preventDefault();
    e.stopPropagation();
    e.persist();
    document.removeEventListener('mousemove', handleMouseMove);
  };

  return (
    <div
      className={style.previewIconWrapper}
      hidden={hiddenFlag}
      ref={wrapperRef}
      style={{ right: coordinate.x, bottom: coordinate.y }}
    >
      <div onMouseDown={handleMouseDown} onMouseUp={handleMouseUp}>
        <iframe
          title="3D打印"
          width={iconSize.width / scaleProportion}
          height={iconSize.height / scaleProportion}
          frameBorder="0"
          className={style.iconIframe}
          src={previewUrl}
          style={{
            transform: 'scale(0.1)',
            transformOrigin: '0% 0%',
            pointerEvents: 'none'
          }}
          scrolling="no"
        />
        <div
          className={style.iconIframe}
          style={{ width: iconSize.width, height: iconSize.height, zIndex: 999 }}
        />
      </div>
      <div className={style.fullScreen} style={{ left: iconSize.width - 25 }}>
        <Icon type="quanping" onClick={handleFullScreen} style={{ color: '#fff', fontSize: 18 }} />
      </div>
    </div>
  );
};

export default DraggablePreviewIcon;
