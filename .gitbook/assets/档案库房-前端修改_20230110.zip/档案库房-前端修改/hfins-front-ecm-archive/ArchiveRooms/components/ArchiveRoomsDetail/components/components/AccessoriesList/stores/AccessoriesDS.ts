import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

/**
 * 主查询
 */
export default (): DataSetProps => ({
  transport: {
    read: config => ({
      ...config,
      url: `${
        commonConfig.ECM_API
      }/v1/${getCurrentOrganizationId()}/archive/appendage/by-location-code`,
      method: 'GET'
    })
  },
  pageSize: 16,
  autoQuery: false,
  fields: [
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      label: intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')
    },
    {
      name: 'x1',
      type: FieldType.number,
      label: 'x1'
    },
    {
      name: 'x2',
      type: FieldType.number,
      label: 'x2'
    },
    {
      name: 'x3',
      type: FieldType.number,
      label: 'x3'
    },
    {
      name: 'x4',
      type: FieldType.number,
      label: 'x4'
    },
    {
      name: 'y1',
      type: FieldType.number,
      label: 'y1'
    },
    {
      name: 'y2',
      type: FieldType.number,
      label: 'y2'
    },
    {
      name: 'y3',
      type: FieldType.number,
      label: 'y3'
    },
    {
      name: 'y4',
      type: FieldType.number,
      label: 'y4'
    }
  ]
});
