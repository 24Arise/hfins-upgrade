import { Col, DataSet, Modal, Row, notification } from 'choerodon-ui/pro/lib';
import { nodeProps } from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/utils/enum';
import { observer } from 'mobx-react';
import { useDataSet } from 'utils/hooks';
import AccessoriesCard from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/components/components/Card/AccessoriesCard';
import AccessoriesDS from './stores/AccessoriesDS';
import EmptyRender from '@common/components/EmptyRender';
import React, { useCallback, useEffect } from 'react';
import RoomStore from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/stores/RoomStore';
import intl from 'utils/intl';

interface AccessoriesListProps {
  currentNode?: nodeProps;
  roomStore: RoomStore;
}

const AccessoriesList: React.FC<AccessoriesListProps> = ({ currentNode, roomStore }) => {
  const accessoriesDS = useDataSet(
    () =>
      new DataSet({
        ...AccessoriesDS(),
        events: {
          update: ({ dataSet, record, name, value }) => {
            if (name === 'enabledFlag') {
              let tip = intl.get('hfsecm.common.confirmeEnabledFlag').d('请确认是否启用？');
              if (!value) {
                tip = intl.get('hfsecm.common.disabledFlag').d('是否确认禁用?');
              }
              Modal.confirm({
                title: intl.get('hfsecm.common.sureTitle').d('确认'),
                children: <p>{tip}</p>,
                onOk: async () => {
                  const res: any = await roomStore.handleUpdateAppendageStatus([
                    record.toJSONData()
                  ]);
                  if (res && res.failed) {
                    notification.error({
                      message: res.message,
                      description: null,
                      placement: 'bottomRight'
                    });
                  } else {
                    notification.success({
                      message: intl.get('hfsecm.common.successfulOperation'),
                      description: null,
                      placement: 'bottomRight'
                    });
                  }
                  dataSet.query();
                },
                onCancel: () => {
                  record.reset();
                }
              });
            }
          }
        }
      }),
    AccessoriesList
  );

  useEffect(() => {
    const { setAccessoriesDS } = roomStore;
    setAccessoriesDS(accessoriesDS);
  }, []);

  useEffect(() => {
    if (
      currentNode?.locationCode &&
      currentNode?.locationType === 'ROOM' &&
      roomStore?.currentNode
    ) {
      accessoriesDS.setQueryParameter('locationCode', currentNode?.locationCode);
      accessoriesDS.query();
    }
  }, [currentNode]);

  const handleEdit = useCallback(record => {
    const { handleEditIndoorFittings } = roomStore;
    handleEditIndoorFittings(record, accessoriesDS);
  }, []);

  return accessoriesDS.records.length ? (
    <Row type="flex" gutter={16}>
      {accessoriesDS.records.map(record => (
        <Col style={{ display: 'inline-block', width: '25%' }}>
          <AccessoriesCard record={record} accessoriesDS={accessoriesDS} handleEdit={handleEdit} />
        </Col>
      ))}
    </Row>
  ) : (
    <EmptyRender title={intl.get('hfsecm.common.noData').d('暂无数据')} />
  );
};

export default observer(AccessoriesList);
