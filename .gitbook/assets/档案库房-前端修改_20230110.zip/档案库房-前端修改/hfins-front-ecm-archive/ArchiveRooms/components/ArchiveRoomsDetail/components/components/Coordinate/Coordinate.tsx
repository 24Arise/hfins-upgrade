import { Form } from 'choerodon-ui/pro/lib';
import { NumberField } from 'choerodon-ui/pro';
import { observer } from 'mobx-react';
import React, { ReactNode } from 'react';
import style from './Coordinate.module.less';

interface CoordinateProps {
  xField: string;
  yField: string;
  // eslint-disable-next-line react/no-unused-prop-types
  label?: ReactNode;
  // eslint-disable-next-line react/no-unused-prop-types
  required?: boolean;
}

const Coordinate: React.FC<CoordinateProps> = ({ xField, yField }) => {
  return (
    <Form.ItemGroup className={style.coordinateWrapper}>
      <span>(</span>
      <NumberField name={xField} />
      <span>,</span>
      <NumberField name={yField} />
      <span>)</span>
    </Form.ItemGroup>
  );
};

export default observer(Coordinate);
