import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldIgnore, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

/**
 * 主查询
 */
export default (): DataSetProps => ({
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/room`,
      method: 'GET'
    }),
    submit: config => {
      return {
        ...config,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/room`,
        method: 'POST'
      };
    }
  },
  pageSize: 16,
  autoQuery: false,
  fields: [
    {
      name: 'roomCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.roomCode').d('库房代码'),
      disabled: true
    },
    {
      name: 'description',
      type: FieldType.intl,
      label: intl.get('hfsecm.archive.room.roomName').d('库房名称'),
      required: true
    },
    {
      name: 'roomLocation',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.roomLocation').d('库房地址')
    },
    {
      name: 'chiefEmployeeCodeObj',
      type: FieldType.object,
      lovCode: 'HFSECM.EMPLOYEE',
      textField: 'employeeName',
      valueField: 'employeeId',
      ignore: FieldIgnore.always,
      label: intl.get('hfsecm.archive.room.supervisor').d('库房负责人')
    },
    {
      name: 'chiefEmployeeName',
      type: FieldType.string,
      bind: 'chiefEmployeeCodeObj.employeeName'
    },
    {
      name: 'chiefEmployeeCode',
      type: FieldType.string,
      bind: 'chiefEmployeeCodeObj.employeeCode'
    },
    {
      name: 'length',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.long').d('长(m)'),
      required: true
    },
    {
      name: 'width',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.width').d('宽(m)'),
      required: true
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      label: intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')
    }
  ]
});
