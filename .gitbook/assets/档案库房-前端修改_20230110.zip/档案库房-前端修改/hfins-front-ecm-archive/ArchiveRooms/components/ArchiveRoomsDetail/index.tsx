import { DataSet } from 'choerodon-ui/pro/lib';
import { Row } from 'choerodon-ui';
import { observer } from 'mobx-react';
import ContentPage from './components/ContentPage';
import DraggablePreviewIcon from '@/pages/ArchiveRooms/components/DraggablePreviewIcon';
import LeftPage from './components/LeftPage';
import React, { Component } from 'react';
import RoomStore from './stores/RoomStore';

interface ArchiveRoomsDetailProps {
  archiveStorageDS: DataSet;
  archiveRoomDS: DataSet;
  archiveFloorDS: DataSet;
  archiveShelfDS: DataSet;
  assignAppendageDS: DataSet;
}

@observer
class ArchiveRoomsDetail extends Component<ArchiveRoomsDetailProps> {
  roomStore: RoomStore;

  constructor(props) {
    super(props);
    const {
      archiveStorageDS,
      archiveRoomDS,
      archiveFloorDS,
      archiveShelfDS,
      assignAppendageDS
    } = this.props;
    this.roomStore = new RoomStore(
      archiveStorageDS,
      archiveRoomDS,
      archiveFloorDS,
      archiveShelfDS,
      assignAppendageDS
    );
  }

  render() {
    return (
      <Row style={{ height: '100%', background: '#f4f5f7', overflow: 'hidden' }} type="flex">
        <LeftPage roomStore={this.roomStore} />
        <ContentPage roomStore={this.roomStore} />
        <DraggablePreviewIcon roomStore={this.roomStore} />
      </Row>
    );
  }
}

export default ArchiveRoomsDetail;
