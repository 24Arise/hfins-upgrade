import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import intl from 'utils/intl';

export default () => ({
  FLOOR: [
    {
      name: 'locationCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.floorCode').d('楼层代码'),
      disabled: true
    },
    {
      name: 'description',
      type: FieldType.intl,
      label: intl.get('hfsecm.archive.room.floorName').d('楼层名称'),
      required: true
    },
    {
      name: 'height',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.floorHeight').d('层高'),
      required: true
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      label: intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')
    }
  ],
  GRID: [
    {
      name: 'locationCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.gridCode').d('格子代码'),
      disabled: true
    },
    {
      name: 'description',
      type: FieldType.intl,
      label: intl.get('hfsecm.archive.room.gridName').d('格子名称'),
      required: true
    },
    {
      name: 'faceName',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.faceName').d('格子朝向'),
      disabled: true
    }
  ],
  LAYER: [
    {
      name: 'locationCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.shelfCode').d('架层代码'),
      disabled: true
    },
    {
      name: 'description',
      type: FieldType.intl,
      label: intl.get('hfsecm.archive.room.shelfName').d('架层名称'),
      required: true
    }
  ],
  ROOM: [
    {
      name: 'locationCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.roomsCode').d('档案室代码'),
      disabled: true
    },
    {
      name: 'description',
      type: FieldType.intl,
      label: intl.get('hfsecm.archive.room.roomsName').d('档案室名称'),
      required: true
    },
    {
      name: 'x1',
      type: FieldType.number,
      label: 'x1',
      required: true
    },
    {
      name: 'x2',
      type: FieldType.number,
      label: 'x2',
      required: true
    },
    {
      name: 'x3',
      type: FieldType.number,
      label: 'x3',
      required: true
    },
    {
      name: 'x4',
      type: FieldType.number,
      label: 'x4',
      required: true
    },
    {
      name: 'y1',
      type: FieldType.number,
      label: 'y1',
      required: true
    },
    {
      name: 'y2',
      type: FieldType.number,
      label: 'y2',
      required: true
    },
    {
      name: 'y3',
      type: FieldType.number,
      label: 'y3',
      required: true
    },
    {
      name: 'y4',
      type: FieldType.number,
      label: 'y4',
      required: true
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      label: intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')
    }
  ],
  SHELF: [
    {
      name: 'locationCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.fileCode').d('档案架代码'),
      disabled: true
    },
    {
      name: 'description',
      type: FieldType.intl,
      label: intl.get('hfsecm.archive.room.fileName').d('档案架名称'),
      required: true
    },
    {
      name: 'length',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.long').d('长(m)'),
      disabled: true,
      required: true
    },
    {
      name: 'width',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.width').d('宽(m)'),
      disabled: true,
      required: true
    },
    {
      name: 'height',
      type: FieldType.number,
      disabled: true,
      label: intl.get('hfsecm.archive.room.height').d('高(m)'),
      required: true
    },
    {
      name: 'rows',
      type: FieldType.number,
      disabled: true,
      label: intl.get('hfsecm.archive.room.rows').d('层数'),
      required: true
    },
    {
      name: 'cols',
      type: FieldType.number,
      disabled: true,
      label: intl.get('hfsecm.archive.room.cols').d('列数'),
      required: true
    },
    {
      name: 'shelfType',
      type: FieldType.string,
      disabled: true,
      lookupCode: 'HFSECM.ARCHIVE_SHELF_TYPE',
      label: intl.get('hfsecm.archive.room.shelfType').d('档案架类型'),
      required: true
    },
    {
      name: 'archivedType',
      type: FieldType.string,
      disabled: true,
      lookupCode: 'HFSECM.ARCHIVED_TYPE ',
      label: intl.get('hfsecm.archive.room.archivedType').d('归档类型'),
      required: true
    },
    {
      name: 'capacity',
      type: FieldType.number,
      disabled: true,
      label: intl.get('hfsecm.archive.room.capacity').d('每格容量'),
      required: true
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      label: intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')
    }
  ]
});
