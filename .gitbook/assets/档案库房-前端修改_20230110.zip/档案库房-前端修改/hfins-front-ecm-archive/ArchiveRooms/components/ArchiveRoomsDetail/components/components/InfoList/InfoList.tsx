import { Alert } from 'choerodon-ui';
import { Button, CheckBox, Col, DataSet, Row } from 'choerodon-ui/pro/lib';
import { FuncType } from 'choerodon-ui/pro/lib/button/enum';
import { nodeProps } from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/utils/enum';
import { observer } from 'mobx-react';
import { useDataSet } from 'hzero-front/lib/utils/hooks';
import EmptyRender from '@common/components/EmptyRender';
import Icon from '@common/components/Icon';
import InfoCard from '../Card/InfoCard';
import InfoListDS from './stores/InfoListDS';
import React, { useCallback, useEffect, useState } from 'react';
import RoomStore from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/stores/RoomStore';
import intl from 'utils/intl';

interface InfoListProps {
  currentNode?: nodeProps;
  roomStore: RoomStore;
}

const InfoList: React.FC<InfoListProps> = ({ currentNode, roomStore }) => {
  const infoListDS = useDataSet(() => new DataSet({ ...InfoListDS() }), InfoList);
  const [checked, setChecked] = useState<boolean>(false);

  useEffect(() => {
    if (currentNode?.locationCode || currentNode?.roomCode) {
      infoListDS.setQueryParameter(
        'parentLocationCode',
        currentNode?.locationCode || currentNode?.roomCode
      );
      infoListDS.setQueryParameter('parentLocationType', currentNode?.locationType);
      infoListDS.setQueryParameter('roomCode', currentNode?.roomCode);
      infoListDS.query();
    }
    setChecked(false);
  }, [currentNode]);

  const handlePrint = useCallback(() => {
    const { handlePrint } = roomStore;
    handlePrint(infoListDS);
  }, [roomStore]);

  const handleSelectAll = useCallback(
    checked => {
      if (checked) {
        infoListDS.selectAll();
      } else {
        infoListDS.unSelectAll();
      }
      setChecked(checked);
    },
    [checked]
  );

  const renderAlertContent = () => {
    return (
      <>
        <Icon type="tips" size={16} style={{ margin: '0 8px 0 12px' }} />
        {intl.get('hfsecm.archive.room.belongsObject').d('当前查看对象归属于')}
        <span style={{ color: 'rgba(8, 64, 248, 1)' }}>{currentNode?.locationInfo}</span>
      </>
    );
  };

  return infoListDS.records.length ? (
    <>
      <Row type="flex">
        <Col
          span={18}
          style={{
            background: 'rgba(240, 248, 255, 1)',
            color: 'rgba(0, 0, 0, 0.65)',
            borderRadius: 2
          }}
        >
          <Alert message={renderAlertContent()} />
        </Col>
        <Col span={6} style={{ textAlign: 'right' }}>
          <CheckBox
            checked={checked}
            disabled={!infoListDS.records.length}
            onChange={value => handleSelectAll(value)}
          >
            {intl.get('hfsecm.common.selectAll').d('全选')}
          </CheckBox>
          <Button
            icon="print"
            onClick={() => handlePrint()}
            funcType={FuncType.flat}
            disabled={!infoListDS.selected.length}
            style={{
              marginLeft: 10
            }}
          >
            {intl.get('hfins.common.print').d('打印')}
          </Button>
        </Col>
      </Row>
      <Row type="flex" gutter={16}>
        {infoListDS.records.map(record => (
          <Col style={{ display: 'inline-block', width: '25%' }}>
            <InfoCard record={record} infoListDS={infoListDS} currentNode={currentNode} />
          </Col>
        ))}
      </Row>
    </>
  ) : (
    <EmptyRender title={intl.get('hfsecm.archive.room.noChildInfo').d('无子级信息哦')} />
  );
};

export default observer(InfoList);
