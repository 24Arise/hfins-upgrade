import { Card } from 'choerodon-ui';
import { CheckBox, Col, DataSet, Row, Tooltip } from 'choerodon-ui/pro/lib';
import Icon from '@common/components/Icon';
import React, { useCallback } from 'react';
import Record from 'choerodon-ui/pro/lib/data-set/Record';
import intl from 'utils/intl';
import style from './InfoCard.module.less';

interface InfoCardProps {
  record: Record;
  infoListDS: DataSet;
  currentNode?: any;
}

const InfoCard: React.FC<InfoCardProps> = ({ record, infoListDS, currentNode = {} }) => {
  const handleSelect = useCallback((checked, record) => {
    if (checked) {
      infoListDS.select(record);
    } else {
      infoListDS.unSelect(record);
    }
  }, []);

  return (
    <Card className={style.wrapper}>
      <Row type="flex" justify="space-between" style={{ marginBottom: 10 }}>
        <Col className={style.title}>
          <Tooltip
            title={
              currentNode?.locationType === 'ROOM'
                ? `${record?.get('locationCode')}/${record?.get('description')}`
                : record?.get('description')
            }
          >
            {currentNode?.locationType === 'ROOM'
              ? `${record?.get('locationCode')}/${record?.get('description')}`
              : record?.get('description')}
          </Tooltip>
        </Col>
        <Col>
          <CheckBox
            checked={record.isSelected}
            record={record}
            onChange={value => handleSelect(value, record)}
          />
        </Col>
      </Row>
      <Row type="flex" align="middle">
        <Col style={{ position: 'relative' }}>
          <Icon type="a-rongqi" size={60} />
          <div className={style.backgroundIconWrapper}>
            <div className={style.backgroundIcon} style={{ height: record?.get('percentage') }} />
          </div>
          <span className={style.percentage}>{record?.get('percentage')}</span>
        </Col>
        <Col className={style.rightContent}>
          <div>
            <label className={style.capacity}>
              {intl.get('hfsecm.archive.room.totalCapacity').d('总容量')}
            </label>
            <span className={style.capacityNum}>{record.get('capacity')}</span>
          </div>
          <div>
            <label className={style.used}>
              {intl.get('hfsecm.archive.room.usedCapacity').d('已使用')}
            </label>
            <span className={style.capacityNum}>{record.get('usedCapacity')}</span>
          </div>
          <div>
            <label className={style.unused}>
              {intl.get('hfsecm.archive.room.unusedCapacity').d('未使用')}
            </label>
            <span className={style.capacityNum}>{record.get('unusedCapacity')}</span>
          </div>
        </Col>
      </Row>
    </Card>
  );
};

export default InfoCard;
