import '../../../index.modules.less';
import { DataSet } from 'choerodon-ui/pro/lib';
import { Modal } from 'choerodon-ui/pro';
import { Room } from '../../ArchiveRoomModal';
import { action, observable } from 'mobx';
import { getCurrentOrganizationId } from 'utils/utils';
import { getNewNode, getParentNode, processTreeList } from '../utils/fun';
import { nodeProps } from '../utils/enum';
import PrintTag from '@/pages/Archive/Modal/PrintTag';
import React from 'react';
import Record from 'choerodon-ui/pro/lib/data-set/Record';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';
import openAssignAppendageModal from '../../commonModal/assignAppendage';
import openAssignShelfModal from '../../commonModal/assignShelf';
import openDetailModal from '../../commonModal/detailModal';
import request from '@common/utils/request';

export default class RoomStore {
  @observable
  currentNode: nodeProps | undefined = undefined;

  @observable
  treeList: Array<any> = [];

  @observable
  currentStep = 0;

  @observable
  currentRoomId = '';

  archiveRoomTreeDS: DataSet = new DataSet();

  // 室内配件ds
  accessoriesDS?: DataSet;

  archiveStorageDS: DataSet;

  archiveRoomDS: DataSet;

  archiveFloorDS: DataSet;

  archiveShelfDS: DataSet;

  assignAppendageDS: DataSet;

  constructor(
    archiveStorageDS: DataSet,
    archiveRoomDS: DataSet,
    archiveFloorDS: DataSet,
    archiveShelfDS: DataSet,
    assignAppendageDS: DataSet
  ) {
    this.archiveStorageDS = archiveStorageDS;
    this.archiveRoomDS = archiveRoomDS;
    this.archiveFloorDS = archiveFloorDS;
    this.archiveShelfDS = archiveShelfDS;
    this.assignAppendageDS = assignAppendageDS;
  }

  @action
  setArchiveRoomTreeDS = (archiveRoomTreeDS: DataSet) => {
    this.archiveRoomTreeDS = archiveRoomTreeDS;
  };

  @action
  setAccessoriesDS = (accessoriesDS: DataSet) => {
    this.accessoriesDS = accessoriesDS;
  };

  @action
  setTreeList = (treeList: Array<any>) => {
    this.treeList = treeList;
  };

  handleSelect = (treeNode: nodeProps) => {
    this.currentNode = treeNode;
  };

  handleSaveNode = (dataSet: DataSet) => {
    dataSet.submit().then(() => {
      // this.archiveRoomTreeDS.query();
      if (this.currentNode) {
        this.currentNode.description = dataSet.records[0].get('description');
      }
    });
  };

  handlePrint = (listDS: DataSet) => {
    const locationIdStr = listDS.selected.map(record => {
      return record?.get('locationId');
    });
    const paramName = 'locationIds';
    const templateCode = 'HFSECM_ARCHIVE_LOCATION_QR';
    Modal.open({
      closable: true,
      footer: null,
      fullScreen: true,
      className: 'hfins-ec-modal',
      title: intl.get('hfsecm.common.printTemplate').d('打印模板'),
      children: (
        <PrintTag paramValue={locationIdStr} paramName={paramName} templateCode={templateCode} />
      )
    });
  };

  // 复制节点
  handleCopy = (treeNode: nodeProps, childCopyFlag: boolean) => {
    this.handleCopyNode(treeNode, childCopyFlag).then(() => {
      if (!treeNode.locationType || treeNode.locationType === 'FLOOR') {
        this.archiveRoomTreeDS.query();
      } else {
        this.handleTreeNode(treeNode, false);
      }
    });
  };

  // 复制节点
  handleCopyNode = (treeNode: nodeProps, childCopyFlag: boolean) => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/copy`,
      {
        method: 'POST',
        data: {
          childCopyFlag,
          locationId: treeNode.locationId
        }
      }
    );
  };

  // 启用/禁用配件
  handleUpdateAppendageStatus = data => {
    return request(`${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/appendage`, {
      method: 'POST',
      data
    });
  };

  // 请求子级树数据
  handleGetTreeData = (params: {
    locationType?: string;
    locationCode?: string;
    roomCode?: string;
  }): any => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/room/child-location`,
      {
        method: 'GET',
        params
      }
    );
  };

  // todo 无效声明，测试使用，后续移除
  treeNode: nodeProps | undefined = undefined;

  // 三维立体图
  handleThreeDimensional = (treeNode: nodeProps) => {
    // todo 占位
    this.treeNode = treeNode;
  };

  // 创建平级
  handleCreateLevel = (treeNode: nodeProps) => {
    let step = 0;
    const parentNode = JSON.parse(JSON.stringify(treeNode.parentNode));
    if (treeNode.locationType === 'FLOOR') {
      step = 1;
    } else if (!treeNode.locationType) {
      step = 0;
    } else if (treeNode.locationType === 'ROOM') {
      step = 2;
    }
    openDetailModal(
      step,
      intl.get('hfsecm.archive.room.createRooms').d('新建库房'),
      treeNode,
      () => {
        if (!treeNode.locationType || treeNode.locationType === 'FLOOR') {
          this.archiveRoomTreeDS.query();
        } else if (treeNode.locationType === 'ROOM') {
          treeNode.parentNode = parentNode;
          this.handleTreeNode(treeNode, false);
        }
      }
    );
  };

  // 分配室内配件
  handleDistributionIndoorFittings = async (treeNode: nodeProps) => {
    const res: any = await this.handleQueryRoomIfo({ locationId: treeNode.locationId });
    res.currentParts = 'room';
    this.archiveRoomDS.data = [res];
    let title = '';
    if (treeNode.locationInfo) {
      const desc1 = treeNode.locationInfo.indexOf('\\');
      const subStr1 = treeNode.locationInfo.slice(desc1 + 1);
      const desc2 = subStr1.indexOf('\\');
      title = subStr1.slice(0, desc2);
    }
    const text = res.description;
    const floors = [{ code: res.parentLocationCode, title }];
    openAssignAppendageModal(text, floors, this.handleAssignAppendageOk);
  };

  handleAssignAppendageOk = (assignAppendageDS, floors) => {
    Modal.open({
      title: intl.get('hfsecm.archive.room.assignAppendage').d('分配室内配件'),
      drawer: true,
      style: { width: 430 },
      closable: true,
      children: (
        <Room
          dataSet={this.archiveRoomDS}
          assignAppendageDS={assignAppendageDS}
          editAppendage={null}
          floorInfo={floors}
          isDisabled
        />
      ),
      afterClose: () => {
        assignAppendageDS.reset();
        this.accessoriesDS?.query();
      }
    });
  };

  // 查询当前档案室信息
  handleQueryRoomIfo = params => {
    return request(`${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location`, {
      method: 'GET',
      params
    });
  };

  // 编辑室内配件
  handleEditIndoorFittings = async (record: Record, accessoriesDS: DataSet) => {
    const ds = new DataSet();
    const res: any = await this.handleQueryRoomIfo({ locationId: this.currentNode?.locationId });
    res.currentParts = record.get('appendageType') === 'DOOR' ? 'door' : 'win';
    res.currentAppendage = record.get('appendageCode');
    ds.data = [res];
    let title = '';
    if (this.currentNode?.locationInfo) {
      const desc1 = this.currentNode?.locationInfo.indexOf('\\');
      const subStr1 = this.currentNode?.locationInfo.slice(desc1 + 1);
      const desc2 = subStr1.indexOf('\\');
      title = subStr1.slice(0, desc2);
    }
    const floors = [{ code: res.parentLocationCode, title }];
    Modal.open({
      title: intl.get('hfsecm.archive.room.editAppendage').d('编辑室内配件'),
      drawer: true,
      style: { width: 430 },
      closable: true,
      destroyOnClose: true,
      children: (
        <Room
          dataSet={ds}
          assignAppendageDS={undefined}
          floorInfo={floors}
          editAppendage={record}
          isDisabled
        />
      ),
      onOk: () => {
        accessoriesDS.query();
      },
      afterClose: () => {
        this.treeNode = this.currentNode;
      }
    });
  };

  // 处理节点
  async handleTreeNode(treeNode: nodeProps, isChild: boolean) {
    let params = {
      locationType: treeNode.locationType,
      locationCode: treeNode.locationCode,
      roomCode: treeNode.roomCode
    };
    if (!isChild) {
      params = {
        locationType: treeNode?.parentNode?.locationType,
        locationCode: treeNode?.parentNode?.locationCode,
        roomCode: treeNode?.parentNode?.roomCode
      };
    }
    const nodeList = await this.handleGetTreeData(params);
    if (nodeList?.childLocations) {
      const treeList = await processTreeList(nodeList?.childLocations);
      if (isChild) {
        // 对比接口返回的节点和树节点，添加不在树节点上的接口返回节点
        const newNodeList = await getNewNode(treeNode?.childLocations, treeList);
        newNodeList.forEach(node => {
          treeNode?.childLocations?.push(node);
        });
        this.currentNode = treeNode;
      } else {
        // 获取节点的父节点
        const parent: any = await getParentNode(this.treeList, params);
        if (parent) {
          // 对比接口返回的节点和树节点，添加不在树节点上的接口返回节点
          const newNodeList = await getNewNode(treeNode?.childLocations, treeList);
          parent.childLocations = [];
          newNodeList.forEach(node => {
            parent?.childLocations?.push(node);
          });
          this.currentNode = treeNode;
        }
      }
    }
  }

  // 创建子级
  handleCreateChild = (treeNode: nodeProps) => {
    let step = 0;
    if (treeNode.locationType === 'FLOOR') {
      step = 2;
    } else if (!treeNode.locationType) {
      step = 1;
    }
    openDetailModal(
      step,
      intl.get('hfsecm.archive.room.createRooms').d('新建库房'),
      treeNode,
      () => {
        if (!treeNode.locationType) {
          this.archiveRoomTreeDS.query();
        } else {
          this.handleTreeNode(treeNode, true);
        }
      }
    );
  };

  // 分配档案架
  handleDistributionFileRack = (treeNode: nodeProps) => {
    const data: any = JSON.parse(JSON.stringify(treeNode));
    this.archiveRoomDS.data = [data];
    openAssignShelfModal(this.archiveRoomDS.current, 'assign', () =>
      this.handleTreeNode(treeNode, false)
    );
  };
}
