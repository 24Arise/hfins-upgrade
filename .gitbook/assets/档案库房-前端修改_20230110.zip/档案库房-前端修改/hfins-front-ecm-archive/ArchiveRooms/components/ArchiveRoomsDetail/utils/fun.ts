import { nodeProps } from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/utils/enum';

export const processTreeList = (list: Array<any>, expand = false, parentNode?: any) => {
  return list.map(node => {
    const cacheNode = {
      locationType: node.locationType,
      locationCode: node.locationCode,
      roomCode: node.roomCode
    };
    return {
      ...node,
      expand,
      parentNode,
      childLocations: node.childLocations
        ? processTreeList(node.childLocations, expand, cacheNode)
        : undefined
    };
  });
};

export const getParentNode = (
  nodeList: Array<any>,
  {
    locationType,
    locationCode,
    roomCode
  }: { locationType?: string; locationCode?: string; roomCode?: string }
): nodeProps | null => {
  let parentNode: nodeProps | null = null;
  function recursion(
    nodeList: Array<any>,
    {
      locationType,
      locationCode,
      roomCode
    }: { locationType?: string; locationCode?: string; roomCode?: string }
  ) {
    for (let i = 0; i < nodeList?.length; i++) {
      if (parentNode) {
        break;
      }
      const node = nodeList[i];
      if (
        node.locationType === locationType &&
        node.locationCode === locationCode &&
        node.roomCode === roomCode
      ) {
        parentNode = node;
        break;
      } else {
        recursion(node.childLocations, { locationCode, locationType, roomCode });
      }
    }
  }
  recursion(nodeList, { locationCode, locationType, roomCode });
  return parentNode;
};

// 只比对子级节点，库房节点查询刷新
export const getNewNode = (oldNodeList?: Array<nodeProps>, newNodeList?: Array<nodeProps>) => {
  const nodeList: Array<nodeProps> = [];
  newNodeList?.forEach(node => {
    const flag = oldNodeList?.some(oldNode => oldNode.locationId === node.locationId);
    if (!flag) {
      nodeList.push(node);
    }
  });
  return nodeList;
};
