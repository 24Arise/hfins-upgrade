import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';

/**
 * 主查询
 */
export default (): DataSetProps => ({
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location`,
      method: 'GET'
    }),
    submit: config => {
      return {
        ...config,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location`,
        method: 'POST'
      };
    }
  },
  pageSize: 16,
  autoQuery: false
});
