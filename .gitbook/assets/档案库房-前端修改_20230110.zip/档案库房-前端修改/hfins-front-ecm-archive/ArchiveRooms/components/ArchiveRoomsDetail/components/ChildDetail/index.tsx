import {
  Button,
  DataSet,
  Form,
  IntlField,
  NumberField,
  Select,
  Switch,
  TextField
} from 'choerodon-ui/pro/lib';
import { FuncType } from 'choerodon-ui/pro/lib/button/enum';
import { IReactionDisposer } from 'mobx/lib/internal';
import { observer } from 'mobx-react';
import { reaction } from 'mobx';
import AccessoriesList from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/components/components/AccessoriesList';
import Card from '@common/components/Card';
import ChildDetailDS from './stores/ChildDetailDS';
import Collapse from '@common/components/Collapse';
import Coordinate from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/components/components/Coordinate/Coordinate';
import FieldsFun from './stores/fields';
import InfoList from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/components/components/InfoList/InfoList';
import React, { Component } from 'react';
import RoomStore from '../../stores/RoomStore';
import intl from 'utils/intl';
import styles from '../index.module.less';

interface ChildDetailProps {
  roomStore: RoomStore;
}
@observer
class ChildDetail extends Component<ChildDetailProps> {
  childDetailDS: DataSet = new DataSet({
    ...ChildDetailDS()
  });

  fieldConfigMap: Map<string, any> = new Map();

  disposer: IReactionDisposer = reaction(
    () => this.roomStore.currentNode,
    currentNode => {
      if (currentNode?.locationId) {
        this.childDetailDS.setQueryParameter('locationId', currentNode?.locationId);
        this.childDetailDS.query();
      }
    },
    {
      fireImmediately: true
    }
  );

  fieldDisposer: IReactionDisposer = reaction(
    () => this.roomStore.currentNode?.locationType,
    locationType => {
      if (locationType) {
        this.unmountFields();
        this.replaceFields(locationType);
      }
    },
    {
      fireImmediately: true
    }
  );

  componentWillUnmount() {
    this.unmountFields();
    this.disposer();
    this.fieldDisposer();
  }

  unmountFields() {
    if (this.fieldConfigMap) {
      for (const key of this.fieldConfigMap.keys()) {
        this.childDetailDS.fields.delete(key);
      }
      this.fieldConfigMap.clear();
    }
  }

  replaceFields(locationType) {
    const fields = FieldsFun();
    if (fields[locationType]) {
      fields[locationType].forEach(field => {
        this.fieldConfigMap.set(field.name as string, 1);
        this.childDetailDS.addField(field.name as string, field);
      });
    }
  }

  get roomStore() {
    return this.props.roomStore;
  }

  get buttonRender() {
    const {
      handleSaveNode,
      currentNode,
      handleDistributionIndoorFittings,
      handleDistributionFileRack
    } = this.roomStore;
    let button = (
      <Button
        icon="save"
        style={{ height: 22 }}
        funcType={FuncType.flat}
        onClick={() => handleSaveNode(this.childDetailDS)}
      >
        {intl.get('hfsecm.common.save').d('保存')}
      </Button>
    );
    if (currentNode?.locationType === 'ROOM') {
      button = (
        <>
          <Button
            icon="fenpei-o"
            style={{ height: 22 }}
            onClick={() => handleDistributionIndoorFittings(currentNode)}
            funcType={FuncType.flat}
          >
            {intl.get('hfsecm.archive.room.distributionIndoorFittings').d('分配室内配件')}
          </Button>
          <Button
            icon="fenpei-o"
            style={{ height: 22 }}
            onClick={() => handleDistributionFileRack(currentNode)}
            funcType={FuncType.flat}
          >
            {intl.get('hfsecm.archive.room.distributionFileRack').d('分配档案架')}
          </Button>
          <Button
            icon="save"
            style={{ height: 22 }}
            funcType={FuncType.flat}
            onClick={() => handleSaveNode(this.childDetailDS)}
          >
            {intl.get('hfsecm.common.save').d('保存')}
          </Button>
        </>
      );
    }
    return button;
  }

  get formRender() {
    const locationType = this.roomStore.currentNode?.locationType;
    let element = <></>;
    switch (locationType) {
      case 'FLOOR':
        element = (
          <>
            <TextField name="locationCode" />
            <IntlField name="description" />
            <NumberField name="height" />
            <Switch name="enabledFlag" />
          </>
        );
        break;
      case 'ROOM':
        element = (
          <>
            <TextField name="locationCode" />
            <IntlField name="description" />
            <Coordinate
              xField="x1"
              yField="y1"
              required
              label={intl.get('hfsecm.archive.room.upperLeftCoordinate').d('左上坐标')}
            />
            <Coordinate
              xField="x2"
              yField="y2"
              required
              label={intl.get('hfsecm.archive.room.upperRightCoordinate').d('右上坐标')}
            />
            <Coordinate
              xField="x3"
              yField="y3"
              required
              label={intl.get('hfsecm.archive.room.lowerRightCoordinate').d('右下坐标')}
            />
            <Coordinate
              xField="x4"
              yField="y4"
              required
              label={intl.get('hfsecm.archive.room.lowerLeftCoordinate').d('左下坐标')}
            />
            <Switch name="enabledFlag" />
          </>
        );
        break;
      case 'SHELF':
        element = (
          <>
            <TextField name="locationCode" />
            <IntlField name="description" />
            <NumberField name="length" />
            <NumberField name="width" />
            <NumberField name="height" />
            <NumberField name="rows" />
            <NumberField name="cols" />
            <Select name="shelfType" />
            <Select name="archivedType" />
            <NumberField name="capacity" />
            <Switch name="enabledFlag" />
          </>
        );
        break;
      case 'LAYER':
        element = (
          <>
            <TextField name="locationCode" />
            <IntlField name="description" />
          </>
        );
        break;
      case 'GRID':
        element = (
          <>
            <TextField name="locationCode" />
            <IntlField name="description" />
            <TextField name="faceName" />
          </>
        );
        break;
      default:
        break;
    }
    return element;
  }

  get panelDesc() {
    const locationType = this.roomStore.currentNode?.locationType;
    let desc = '';
    switch (locationType) {
      case 'FLOOR':
        desc = intl.get('hfsecm.archive.room.roomInfo').d('库房信息');
        break;
      case 'ROOM':
        desc = intl.get('hfsecm.archive.room.infoShelf').d('档案架信息');
        break;
      case 'SHELF':
        desc = intl.get('hfsecm.archive.room.infoLayer').d('档案架信息-层');
        break;
      case 'LAYER':
        desc = intl.get('hfsecm.archive.room.infoGrid').d('档案架信息-格');
        break;
      case 'GRID':
        desc = intl.get('hfsecm.archive.room.infoShelf').d('档案架信息');
        break;
      default:
        break;
    }
    return desc;
  }

  render() {
    const { currentNode } = this.roomStore;
    return (
      <div className={styles.detailWrapper}>
        <Card
          title={intl.get('hfsecm.archive.room.basicInfo').d('基本信息')}
          bordered={false}
          extra={this.buttonRender}
        >
          <Form dataSet={this.childDetailDS} columns={3}>
            {this.formRender}
          </Form>
        </Card>
        <Collapse defaultActiveKey={['accessories', 'list']}>
          {currentNode?.locationType === 'ROOM' && (
            <Collapse.Panel
              id={intl.get('hfsecm.archive.room.indoorFittings').d('室内配件')}
              key="accessories"
              header={intl.get('hfsecm.archive.room.indoorFittings').d('室内配件')}
            >
              <AccessoriesList currentNode={currentNode} roomStore={this.roomStore} />
            </Collapse.Panel>
          )}
          <Collapse.Panel id={this.panelDesc} key="list" header={this.panelDesc}>
            <InfoList currentNode={currentNode} roomStore={this.roomStore} />
          </Collapse.Panel>
        </Collapse>
      </div>
    );
  }
}

export default ChildDetail;
