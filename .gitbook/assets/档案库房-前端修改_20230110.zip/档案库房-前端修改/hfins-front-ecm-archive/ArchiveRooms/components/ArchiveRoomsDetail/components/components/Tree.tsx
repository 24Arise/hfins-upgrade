import { Col, Dropdown, Menu, Row } from 'choerodon-ui/pro';
import { Icon, Popconfirm } from 'choerodon-ui';
import { nodeProps } from '../../utils/enum';
import { observer } from 'mobx-react';
import Icons from '@common/components/Icon';
import React, { Component } from 'react';
import RoomStore from '../../stores/RoomStore';
import classNames from 'classnames';
import intl from 'utils/intl';
import style from './Tree.module.less';

interface TreeProps {
  treeList?: Array<nodeProps>;
  roomStore: RoomStore;
}

@observer
class Tree extends Component<TreeProps> {
  get treeList() {
    return this.props.treeList;
  }

  locationTypeElement(locationType?: string) {
    let element = (
      <span className={classNames(style.shortName)}>
        {' '}
        <Icons type="department" size={26} />
      </span>
    );
    switch (locationType) {
      case 'FLOOR':
        element = (
          <span className={classNames(style.shortName, style.floor)}>
            {intl.get('hfsecm.archive.room.floor').d('楼')}
          </span>
        );
        break;
      case 'ROOM':
        element = (
          <span className={classNames(style.shortName, style.room)}>
            {intl.get('hfsecm.archive.room.room').d('室')}
          </span>
        );
        break;
      case 'SHELF':
        element = (
          <span className={classNames(style.shortName, style.frame)}>
            {intl.get('hfsecm.archive.room.shelf').d('架')}
          </span>
        );
        break;
      case 'LAYER':
        element = (
          <span className={classNames(style.shortName, style.layer)}>
            {intl.get('hfsecm.archive.room.layer').d('层')}
          </span>
        );
        break;
      case 'GRID':
        element = (
          <span className={classNames(style.shortName, style.grid)}>
            {intl.get('hfsecm.archive.room.grid').d('格')}
          </span>
        );
        break;
      default:
        break;
    }

    return element;
  }

  iconElement(treeNode: nodeProps) {
    const { handleThreeDimensional } = this.props.roomStore;
    let element = <></>;
    if (treeNode.roomId) {
      element = (
        <>
          <Icons
            type="a-sanweiliti"
            onClick={() => {
              handleThreeDimensional(treeNode);
            }}
            size={14}
            style={{ marginRight: 5 }}
          />{' '}
          <Dropdown overlay={() => this.menuElement(treeNode)}>
            <Icons type="more1" size={12} />
          </Dropdown>{' '}
        </>
      );
    } else if (treeNode.locationType === 'FLOOR' || treeNode.locationType === 'ROOM') {
      element = (
        <Dropdown overlay={() => this.menuElement(treeNode)}>
          <Icons type="more1" size={12} />
        </Dropdown>
      );
    }
    return element;
  }

  menuElement(treeNode: nodeProps) {
    const {
      handleCopy,
      handleCreateLevel,
      handleDistributionIndoorFittings,
      handleCreateChild,
      handleDistributionFileRack
    } = this.props.roomStore;
    const flag = treeNode.locationType === 'FLOOR' || treeNode.locationType === 'ROOM';
    return (
      <Menu>
        <Menu.Item onClick={() => handleCreateLevel(treeNode)}>
          {intl.get('hfsecm.archive.room.createLevel').d('创建平级')}
        </Menu.Item>
        {(treeNode.locationType === 'FLOOR' || !treeNode.locationType) && (
          <Menu.Item onClick={() => handleCreateChild(treeNode)}>
            {' '}
            {intl.get('hfsecm.archive.room.createChild').d('创建子级')}
          </Menu.Item>
        )}
        {treeNode.locationType === 'ROOM' && (
          <Menu.Item onClick={() => handleDistributionFileRack(treeNode)}>
            {intl.get('hfsecm.archive.room.distributionFileRack').d('分配档案架')}
          </Menu.Item>
        )}
        {treeNode.locationType === 'ROOM' && (
          <Menu.Item onClick={() => handleDistributionIndoorFittings(treeNode)}>
            {intl.get('hfsecm.archive.room.distributionIndoorFittings').d('分配室内配件')}
          </Menu.Item>
        )}
        {flag && (
          <Menu.Item>
            <Popconfirm
              title={intl.get('hfsecm.archive.room.childCopyTips').d('是否复制子级明细信息')}
              onConfirm={() => handleCopy(treeNode, true)}
              onCancel={() => handleCopy(treeNode, false)}
              okText={intl.get('hfsecm.common.yes').d('是')}
              cancelText={intl.get('hfsecm.common.no').d('否')}
            >
              {intl.get('hfsecm.common.copy').d('复制')}
            </Popconfirm>
          </Menu.Item>
        )}
      </Menu>
    );
  }

  selectedElement(treeNode: nodeProps) {
    const { currentNode } = this.props.roomStore;
    let flag = false;
    if (currentNode?.roomId) {
      flag = currentNode?.roomId === treeNode.roomId;
    } else if (currentNode?.locationId) {
      flag = currentNode?.locationId === treeNode.locationId;
    }
    return flag ? style.selected : '';
  }

  handleTreeNodeStatus = (treeNode: nodeProps) => {
    treeNode.expand = !treeNode.expand;
  };

  handleSelect = (treeNode: nodeProps) => {
    const { handleSelect } = this.props.roomStore;
    handleSelect(treeNode);
  };

  render() {
    return (
      <div className={style.treeWrapper}>
        {this.treeList?.map(treeNode => (
          <div className={style.treeContent}>
            <Row type="flex" className={style.nodeLine} align="middle">
              <Col>
                {treeNode?.childLocations?.length ? (
                  <Icon
                    onClick={() => this.handleTreeNodeStatus(treeNode)}
                    className={classNames(
                      style.archiveAction,
                      treeNode.expand ? style.archiveIconRotate : ''
                    )}
                    type="baseline-arrow_right"
                  />
                ) : (
                  ''
                )}
                <span
                  onClick={() => {
                    this.handleSelect(treeNode);
                  }}
                >
                  {this.locationTypeElement(treeNode.locationType)}
                </span>
              </Col>
              <Col style={{ flex: 1 }}>
                <Row
                  type="flex"
                  justify="space-between"
                  className={classNames(this.selectedElement(treeNode))}
                  onClick={() => {
                    this.handleSelect(treeNode);
                  }}
                  style={{ padding: '5px 0' }}
                >
                  <Col className={style.description}>
                    <span
                      className={classNames(treeNode.enabledFlag ? '' : style.treeNodeDisabled)}
                    >
                      {treeNode.locationType && treeNode.locationType === 'SHELF'
                        ? `${treeNode.locationCode}/${treeNode.description}`
                        : treeNode.description}
                    </span>
                  </Col>
                  <Col className={style.icon}>{this.iconElement(treeNode)}</Col>
                </Row>
              </Col>
            </Row>
            {treeNode?.expand && (
              <div style={{ marginLeft: 30 }}>
                <Tree treeList={treeNode.childLocations} roomStore={this.props.roomStore} />
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }
}

export default Tree;
