import { Button, Col, DataSet, Row, Switch, Tooltip } from 'choerodon-ui/pro/lib';
import { Card } from 'choerodon-ui';
import Icon from '@common/components/Icon';
import React from 'react';
import Record from 'choerodon-ui/pro/lib/data-set/Record';
import intl from 'utils/intl';
import style from './AccessoriedCard.module.less';

interface AccessoriesCardProps {
  record: Record;
  accessoriesDS: DataSet;
  handleEdit: (record: Record) => void;
}

const AccessoriesCard: React.FC<AccessoriesCardProps> = ({ record, accessoriesDS, handleEdit }) => {
  return (
    <Card className={style.wrapper}>
      <Row type="flex" justify="space-between">
        <Col className={style.title}>
          {record.get('appendageType') === 'WINDOW' && (
            <Icon type="a-chuangtianchong" size={24} style={{ marginRight: 5 }} />
          )}
          {record.get('appendageType') === 'DOOR' && (
            <Icon type="a-zu57" size={24} style={{ marginRight: 5 }} />
          )}
          <Tooltip title={`${record?.get('appendageCode')}/${record?.get('description')}`}>
            {record?.get('appendageCode')}/{record?.get('description')}
          </Tooltip>
        </Col>
        <Col>
          <Switch name="enabledFlag" dataSet={accessoriesDS} record={record} />
        </Col>
      </Row>
      <Tooltip
        title={`( ${record?.get('x1')} ,${record?.get('y1')} ) 、( ${record?.get(
          'x2'
        )} ,${record?.get('y2')} )`}
      >
        <div className={style.coordinate}>
          {intl.get('hfsecm.archive.room.coordinate').d('坐标')}：( {record?.get('x1')} ,
          {record?.get('y1')} ) 、( {record?.get('x2')} , {record?.get('y2')} )
        </div>
      </Tooltip>

      <div className={style.edit}>
        <Button
          icon="edit-o"
          className={style.button}
          disabled={!record.get('enabledFlag')}
          onClick={() => handleEdit(record)}
        >
          {intl.get('hfsecm.common.edit').d('编辑')}
        </Button>
      </div>
    </Card>
  );
};

export default AccessoriesCard;
