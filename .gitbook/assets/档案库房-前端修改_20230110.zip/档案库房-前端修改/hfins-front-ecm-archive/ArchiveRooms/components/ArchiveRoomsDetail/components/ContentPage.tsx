import { observer } from 'mobx-react';
import ChildDetail from './ChildDetail';
import React, { Component } from 'react';
import RoomStore from '../stores/RoomStore';
import WareHouse from './Warehouse';
import style from './ContentPage.module.less';

interface ContentPageProps {
  roomStore: RoomStore;
}

@observer
class ContentPage extends Component<ContentPageProps> {
  pageElement() {
    let element = <></>;
    const { currentNode } = this.props.roomStore;
    if (currentNode?.roomId) {
      element = <WareHouse roomStore={this.props.roomStore} />;
    } else {
      element = <ChildDetail roomStore={this.props.roomStore} />;
    }
    return element;
  }

  render() {
    return <div className={style.content}>{this.pageElement()}</div>;
  }
}

export default ContentPage;
