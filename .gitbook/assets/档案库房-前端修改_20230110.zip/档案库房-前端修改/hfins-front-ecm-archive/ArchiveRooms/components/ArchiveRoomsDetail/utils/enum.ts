export type nodeProps = {
  locationId?: string;
  locationCode?: string;
  description: string;
  locationType?: string;
  locationInfo?: string;
  expand?: boolean;
  roomId?: string;
  roomCode?: string;
  enabledFlag?: boolean;
  position?: string;
  parentNode?: {
    locationType?: string;
    locationCode?: string;
    roomCode?: string;
  };
  childLocations?: Array<nodeProps>;
};
