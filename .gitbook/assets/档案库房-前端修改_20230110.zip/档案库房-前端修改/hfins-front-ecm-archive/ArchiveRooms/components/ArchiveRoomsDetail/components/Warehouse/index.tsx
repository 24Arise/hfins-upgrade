import {
  Button,
  DataSet,
  Form,
  IntlField,
  Lov,
  NumberField,
  Switch,
  TextField
} from 'choerodon-ui/pro/lib';
import { FuncType } from 'choerodon-ui/pro/lib/button/enum';
import { IReactionDisposer } from 'mobx/lib/internal';
import { observer } from 'mobx-react';
import { reaction } from 'mobx';
import Card from '@common/components/Card';
import Collapse from '@common/components/Collapse';
import InfoList from '@/pages/ArchiveRooms/components/ArchiveRoomsDetail/components/components/InfoList/InfoList';
import React, { Component } from 'react';
import RoomStore from '../../stores/RoomStore';
import WarehouseDS from './stores/WarehouseDS';
import intl from 'utils/intl';
import style from '../index.module.less';

interface WarehouseProps {
  roomStore: RoomStore;
}
@observer
class Warehouse extends Component<WarehouseProps> {
  wareHouseDS: DataSet = new DataSet({ ...WarehouseDS() });

  disposer: IReactionDisposer = reaction(
    () => this.roomStore.currentNode?.roomId,
    roomId => {
      if (roomId) {
        this.wareHouseDS.setQueryParameter('roomId', roomId);
        this.wareHouseDS.query();
      }
    },
    {
      fireImmediately: true
    }
  );

  componentWillUnmount() {
    this.disposer();
  }

  get roomStore() {
    return this.props.roomStore;
  }

  get buttonRender() {
    const { handleSaveNode } = this.roomStore;
    return (
      <Button
        icon="save"
        style={{ height: 22 }}
        funcType={FuncType.flat}
        onClick={() => handleSaveNode(this.wareHouseDS)}
      >
        {intl.get('hfsecm.common.save').d('保存')}
      </Button>
    );
  }

  render() {
    const { currentNode } = this.roomStore;
    return (
      <div className={style.detailWrapper}>
        <Card
          title={intl.get('hfsecm.archive.room.basicInfo').d('基本信息')}
          bordered={false}
          extra={this.buttonRender}
        >
          <Form dataSet={this.wareHouseDS} columns={3}>
            <TextField name="roomCode" />
            <IntlField name="description" />
            <TextField name="roomLocation" />
            <Lov name="chiefEmployeeCodeObj" />
            <NumberField name="length" />
            <NumberField name="width" />
            <Switch name="enabledFlag" />
          </Form>
        </Card>
        <Collapse defaultActiveKey={['list']}>
          <Collapse.Panel
            id={intl.get('hfsecm.archive.room.floorInfo').d('楼层信息')}
            key="list"
            header={intl.get('hfsecm.archive.room.floorInfo').d('楼层信息')}
          >
            <InfoList currentNode={currentNode} roomStore={this.roomStore} />
          </Collapse.Panel>
        </Collapse>
      </div>
    );
  }
}

export default Warehouse;
