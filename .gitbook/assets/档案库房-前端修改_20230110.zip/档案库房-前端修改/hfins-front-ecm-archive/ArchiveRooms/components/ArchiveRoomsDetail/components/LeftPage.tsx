import { ArchiveRoomTreeDS } from '@/pages/ArchiveRooms/stores';
import { Bind } from 'lodash-decorators';
import { Button, DataSet, Form, Icon, Radio, TextField } from 'choerodon-ui/pro/lib';
import { ButtonColor, FuncType } from 'choerodon-ui/pro/lib/button/enum';
import { Popover } from 'choerodon-ui';
import { ViewMode } from 'choerodon-ui/pro/lib/radio/enum';
import { action, observable } from 'mobx';
import { observer } from 'mobx-react';
import { processTreeList } from '../utils/fun';
import React, { Component } from 'react';
import RoomStore from '../stores/RoomStore';
import Tree from './components/Tree';
import intl from 'utils/intl';
import style from './LeftPage.module.less';

interface LeftPageProps {
  roomStore: RoomStore;
}

@observer
class LeftPage extends Component<LeftPageProps> {
  @observable
  expand = false;

  @observable
  value = '';

  @observable
  treeList: Array<any> = [];

  archiveRoomTreeDS: DataSet = new DataSet({
    ...ArchiveRoomTreeDS()
  });

  componentDidMount() {
    const { setArchiveRoomTreeDS } = this.props.roomStore;
    setArchiveRoomTreeDS(this.archiveRoomTreeDS);
    this.archiveRoomTreeDS.addEventListener('load', this.handleLoadEvent);
  }

  componentWillUnmount() {
    this.archiveRoomTreeDS.removeEventListener('load', this.handleLoadEvent);
  }

  @Bind
  async handleLoadEvent({ dataSet }) {
    const { handleSelect, currentNode, setTreeList } = this.props.roomStore;
    const list = dataSet.records.map(record => record.toJSONData());
    this.treeList = await processTreeList(list, false);
    setTreeList(this.treeList);
    if (this.treeList.length && !currentNode) {
      handleSelect(this.treeList[0]);
    }
  }

  @action
  handleFoldTree = () => {
    this.expand = !this.expand;
    this.treeList = processTreeList(this.treeList, this.expand);
  };

  @action
  handleChange = val => {
    this.value = val;
  };

  handleListSearch = () => {
    this.archiveRoomTreeDS.setQueryParameter('keyword', this.value);
    this.archiveRoomTreeDS.query();
  };

  resetSearchForm = () => {
    this.value = '';
    this.archiveRoomTreeDS.queryDataSet?.reset();
    this.archiveRoomTreeDS.query();
  };

  handleReSearchData = () => {
    this.archiveRoomTreeDS.query();
  };

  // 渲染搜索表单
  renderForm = () => {
    return (
      <div style={{ width: 350 }}>
        <Form dataSet={this.archiveRoomTreeDS.queryDataSet}>
          <TextField name="roomCode" />
          <TextField name="description" />
          <Form.ItemGroup label={intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')}>
            <Radio mode={ViewMode.button} name="enabledFlag" defaultChecked value="all">
              {intl.get('hfsecm.common.all').d('全部')}
            </Radio>
            <Radio mode={ViewMode.button} name="enabledFlag" value="true">
              {intl.get('hfsecm.common.enabledFlag').d('启用')}
            </Radio>
            <Radio mode={ViewMode.button} name="enabledFlag" value="false">
              {intl.get('hfsecm.common.disabled').d('禁用')}
            </Radio>
          </Form.ItemGroup>
        </Form>
        <div
          style={{
            width: '100%',
            height: 40,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <Button
            onClick={() => {
              this.resetSearchForm();
            }}
          >
            {intl.get('hfsecm.common.reset').d('重置')}
          </Button>
          <Button
            color={ButtonColor.primary}
            onClick={() => {
              this.handleReSearchData();
            }}
          >
            {intl.get('hfsecm.common.inquiry').d('查询')}
          </Button>
        </div>
      </div>
    );
  };

  render() {
    return (
      <div className={style.contentLeft}>
        <div className={style.searchForm}>
          <div className={style.textFiled}>
            <TextField
              prefix={<Icon type="search" style={{ color: '#D0D0D0' }} />}
              placeholder={intl.get('hfsecm.archive.room.codeAndName').d('库房代码/名称')}
              value={this.value}
              onChange={this.handleChange}
              onEnterDown={this.handleListSearch}
              clearButton
              onClear={() => {
                this.handleListSearch();
              }}
            />
          </div>
          <div className={style.moreAction}>
            <Popover
              overlayStyle={{ zIndex: 11 }}
              trigger="hover"
              placement="bottomLeft"
              content={this.renderForm()}
              getPopupContainer={targetNode => targetNode.parentElement || document.body}
            >
              <Button funcType={FuncType.raised} icon="filter2" />
            </Popover>
          </div>
        </div>
        <div className={style.fold}>
          <Button onClick={this.handleFoldTree} funcType={FuncType.flat}>
            {this.expand
              ? intl.get('hfsecm.archive.room.packUp').d('全部收起')
              : intl.get('hfsecm.archive.room.expand').d('全部展开')}
          </Button>
        </div>
        <div className={style.tree}>
          <Tree treeList={this.treeList} roomStore={this.props.roomStore} />
        </div>
      </div>
    );
  }
}

export default LeftPage;
