import { ArchiveRoomDS, ArchiveShelfDS } from '../../stores';
import {
  Button,
  DataSet,
  Form,
  IntlField,
  Modal,
  Select,
  Spin,
  Table,
  TextField,
  notification
} from 'choerodon-ui/pro/lib';
import { Checkbox } from 'choerodon-ui';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { SelectionMode } from 'choerodon-ui/pro/lib/table/enum';
import { formatterCollections } from 'utils/intl/formatterCollections';
import { getCurrentOrganizationId } from 'hzero-front/src/utils/utils';
import { observable } from 'mobx';
import { observer } from 'mobx-react';
import React, { Component } from 'react';
import commonConfig from '@common/config/commonConfig';
import intl from 'hzero-front/src/utils/intl';
import request from '@common/utils/request';
import roomShelf from '../images/roomShelf.svg';
import viewShelf from '../images/view.svg';

interface shelfProps {
  dataSet: DataSet;
  roomDS: DataSet;
  isEditCreate: any;
}

@observer
class ArchiveShelf extends Component<shelfProps> {
  @observable queryDS: DataSet;

  @observable roomDS: DataSet;

  @observable currentDS: any;

  @observable loading: boolean;

  constructor(props) {
    super(props);
    this.loading = false;
    this.queryDS = new DataSet({
      ...ArchiveShelfDS(),
      transport: {
        read: ({ data, params }) => ({
          data: { standardType: 'SHELF', ...data },
          params,
          url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/shelf`,
          method: 'GET'
        })
      }
    });
    this.roomDS = new DataSet({
      ...ArchiveRoomDS(),
      transport: {
        read: ({ data, params }) => ({
          data,
          params,
          url: `${
            commonConfig.ECM_API
          }/v1/${getCurrentOrganizationId()}/archive/location/room/shelf`,
          method: 'GET'
        })
      }
    });
    this.roomDS.setQueryParameter('roomCode', this.props.roomDS.get(0)?.get('roomCode'));
    if (this.props.isEditCreate === 'FLOOR') {
      this.loading = true;
      this.roomDS.setQueryParameter(
        'locationCode',
        this.props.roomDS.get(0)?.get('parentLocationCode')
      );
      this.roomDS.setQueryParameter('locationType', 'FLOOR');
    } else if (this.props.isEditCreate === 'ROOM') {
      this.loading = true;
      this.roomDS.setQueryParameter('locationCode', this.props.roomDS.get(0)?.get('locationCode'));
      this.roomDS.setQueryParameter('locationType', 'ROOM');
    }
    this.roomDS.query().then(() => {
      this.loading = false;
    });
  }

  getShelfColumns(name: string): ColumnProps[] {
    return [
      {
        name
      },
      {
        name: 'description',
        width: 130,
        editor: this.currentDS === 'assign'
      },
      {
        name: 'assignNum',
        editor: this.currentDS === 'assign',
        hidden: this.currentDS !== 'assign'
      },
      {
        name: 'length',
        width: 90
      },
      {
        name: 'width',
        width: 90
      },
      {
        name: 'height',
        width: 90
      },
      {
        name: 'rows',
        width: 60
      },
      {
        name: 'cols',
        width: 60
      },
      {
        name: 'shelfType'
      },
      {
        name: 'archivedType'
      },
      {
        name: 'capacity',
        width: 110
      }
    ];
  }

  handleAssign = async (type, selData) => {
    this.currentDS = 'assign';
    // this.props.dataSet.setQueryParameter('parentLocationCode', null);
    await this.props.dataSet.query();
    const shelfModal = Modal.open({
      closable: true,
      title: intl.get('hfsecm.archive.room.assignShelf').d('分配档案架'),
      style: { width: '880px' },
      children: (
        <Table
          columns={this.getShelfColumns('standardCode')}
          dataSet={this.props.dataSet}
          buttons={[
            <Button
              key="add"
              icon="playlist_add"
              onClick={() => this.handleAddShelfType(shelfModal)}
            >
              {intl.get('hfsecm.archive.room.addShelfType').d('新增档案架规格')}
            </Button>
          ]}
        />
      ),
      onOk: async () => {
        this.loading = true;
        // /archive/location/shelf
        // 得到选中的档案架
        const { selected } = this.props.dataSet;
        const locationList: any = [];
        const standardList: any = [];
        if (type === 'all') {
          this.roomDS.selected.forEach(item => locationList.push(item.toData()));
        } else {
          locationList.push(selData?.toData());
        }
        if (selected && selected.length) {
          selected.forEach(sel => {
            standardList.push(sel.toData());
          });
          this.handleAssignReq({ locationList, standardList }).then(async (res: any) => {
            if (res?.failed) {
              notification.error({
                message: res.message,
                description: null,
                placement: 'bottomRight'
              });
            } else {
              notification.success({
                message: intl.get('hfsecm.common.successfulOperation'),
                description: null,
                placement: 'bottomRight'
              });
              await this.roomDS.query();
            }
          });
        }
        this.loading = false;
      }
    });
  };

  /**
   * 查询所有的档案室以及档案架信息
   * @param data
   * @returns
   */
  handleQueryRoom = params => {
    // archive/location/room
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/room/shelf`,
      {
        method: 'GET',
        params
      }
    );
  };

  /**
   * 批量分配档案架
   */
  handleAssignReq = data => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/shelf`,
      {
        method: 'POST',
        data
      }
    );
  };

  /**
   * 新增档案架
   * @returns
   */
  handleAddShelfType = modal => {
    this.props.dataSet.create({}, 0);
    Modal.open({
      closable: true,
      title: intl.get('hfsecm.archive.room.addShelfType').d('新增档案架规格'),
      children: (
        <Form record={this.props.dataSet.current} columns={2}>
          <TextField name="standardCode" />
          <IntlField name="description" />
          <TextField name="length" />
          <TextField name="width" />
          <TextField name="height" />
          <TextField name="rows" />
          <TextField name="cols" />
          <Select name="shelfType" />
          <Select name="archivedType" />
          <TextField name="capacity" />
        </Form>
      ),
      onOk: async () => {
        this.loading = true;
        const res = await this.props.dataSet.validate();
        if (res) {
          this.props.dataSet.submit().then(subRes => {
            if (subRes.failed) {
              notification.error({
                message: subRes.message,
                description: null,
                placement: 'bottomRight'
              });
              return false;
            }
            notification.success({
              message: intl.get('hfsecm.common.successfulOperation'),
              description: null,
              placement: 'bottomRight'
            });

            this.props.dataSet.query();
            modal.update();
          });
          this.loading = false;
        } else {
          this.loading = false;
          return false;
        }
      },
      onCancel: () => {
        this.props.dataSet.reset();
      }
    });
  };

  /**
   * 查看已分配的档案架
   */
  handleViewAssign = async data => {
    this.loading = true;
    this.currentDS = 'view';
    this.queryDS.setQueryParameter('parentLocationCode', data.get('locationCode'));
    this.queryDS.setQueryParameter('roomCode', data.get('roomCode'));
    await this.queryDS.query();
    this.loading = false;
    const shelfColumns = this.getShelfColumns('locationCode');
    Modal.open({
      closable: true,
      title: intl.get('hfsecm.archive.room.assignShelf').d('分配档案架'),
      style: { width: '880px' },
      children: (
        <Table columns={shelfColumns} dataSet={this.queryDS} selectionMode={SelectionMode.none} />
      )
    });
  };

  queryShelf = params => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/shelf`,
      {
        method: 'GET',
        params
      }
    );
  };

  /**
   * 全选
   * @returns
   */
  handleCheckAll = checked => {
    if (checked) {
      this.roomDS?.selectAll();
    } else {
      this.roomDS?.unSelectAll();
    }
  };

  @observable
  handleCheck = record => {
    if (record?.isSelected) {
      this.roomDS.unSelect(record);
    } else {
      this.roomDS.select(record);
    }
  };

  render() {
    return (
      <>
        <Spin spinning={this.loading}>
          <div className="ecm-section">
            <div className="ecm-section-header shelf-flex">
              <p className="ecm-shelf-header">{intl.get('hfsecm.common.basicInformation')}</p>
              <div className="ecm-section-btnGroups ecm-shelf-btnGroups">
                <Checkbox
                  onChange={e => {
                    this.handleCheckAll(e.target.checked);
                  }}
                >
                  {intl.get('hfsecm.archive.room.selectAll').d('全选')}
                </Checkbox>
                <Button
                  className="ecm-btn-assign"
                  disabled={this.roomDS.selected?.length < 1}
                  onClick={() => this.handleAssign('all', null)}
                  icon="fenpei-o"
                >
                  {intl.get('hfsecm.archive.room.assignShelf').d('分配档案架')}
                </Button>
              </div>
            </div>

            <div className="ecm-room-flex">
              {this.roomDS.map(item => {
                return (
                  <div className="ecm-room-shelf">
                    <div className="ecm-room-shelf-flex">
                      <p className="ecm-room-shelf-flex-p">{item.get('description')}</p>
                      <div
                        onClick={() => {
                          this.handleCheck(item);
                        }}
                      >
                        <Checkbox value={item.isSelected} />
                      </div>
                    </div>
                    <div className="ecm-room-shelf-flex">
                      <img src={roomShelf} alt="" className="shelf-img" />
                      <div className="shelf-info">
                        <div className="shelf-info-msg">
                          <p className="shelf-info-msg-label">
                            {intl.get('hfsecm.archive.room.shelfTypeNum').d('档案架种类数')}:
                          </p>
                          <p className="shelf-info-msg-value">{item.get('typeNumber')}</p>
                        </div>
                        <div className="shelf-info-msg">
                          <p className="shelf-info-msg-label">
                            {intl.get('hfsecm.archive.room.shelfNum').d('档案架个数')}:
                          </p>
                          <p className="shelf-info-msg-value">{item.get('shelfNumber')}</p>
                        </div>
                      </div>
                    </div>
                    <div className="ecm-section-btnGroups">
                      <p
                        className="ecm-btn-assign ecm-btn-singleAssign"
                        onClick={() => {
                          this.handleAssign('signle', item);
                        }}
                      >
                        {intl.get('hfsecm.archive.room.assignShelf').d('分配档案架')}
                      </p>
                      <p
                        className="ecm-btn-view"
                        onClick={() => {
                          this.handleViewAssign(item);
                        }}
                      >
                        <img src={viewShelf} alt="" />
                        {intl.get('hfsecm.archive.room.viewShelf').d('查看')}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Spin>
      </>
    );
  }
}

export default formatterCollections({ code: ['hfsecm.common', 'hfsecm.archive.room'] })(
  ArchiveShelf
);
