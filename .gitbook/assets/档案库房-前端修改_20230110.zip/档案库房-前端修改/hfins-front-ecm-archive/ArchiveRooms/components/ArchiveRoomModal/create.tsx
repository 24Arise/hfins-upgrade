import { DataSet } from 'choerodon-ui/pro/lib';
import { Floor, Room, Shelf, Storage } from './index';
import { Steps } from 'choerodon-ui';
import { formatterCollections } from 'utils/intl/formatterCollections';
import React, { Component } from 'react';
import intl from 'hzero-front/src/utils/intl';

const Step = Steps.Step;

interface roomsProps {
  storageDS: DataSet;
  floorDS: DataSet;
  roomDS: DataSet;
  shelfDS: DataSet;
  currentStep: number;
  floorInfo: any;
}

class CreateRooms extends Component<roomsProps> {
  stepList: any;

  constructor(props) {
    super(props);
    // 楼栋和楼层信息 不可变更
    this.stepList = [
      {
        title: intl.get('hfsecm.archive.room.storageSetting').d('库房设置'),
        content: <Storage dataSet={this.props.storageDS} floor={this.props.floorDS} />
      },
      {
        title: intl.get('hfsecm.archive.room.floorSetting').d('楼层设置'),
        content: <Floor dataSet={this.props.floorDS} />
      },
      {
        title: intl.get('hfsecm.archive.room.roomSetting').d('档案室设置'),
        content: <Room dataSet={this.props.roomDS} floorInfo={this.props.floorInfo} />
      },
      {
        title: intl.get('hfsecm.archive.room.shelfSetting').d('档案架设置'),
        content: <Shelf dataSet={this.props.shelfDS} roomDS={this.props.roomDS} />
      },
      {
        title: intl.get('hfsecm.archive.room.roomPreview').d('库房预览'),
        content: '555'
      }
    ];
  }

  render() {
    return (
      <>
        <Steps current={this.props.currentStep} type="navigation">
          {this.stepList.map(item => (
            <Step key={item.title} title={item.title} />
          ))}
        </Steps>
        <div className="steps-content">{this.stepList[this.props.currentStep].content}</div>
      </>
    );
  }
}

export default formatterCollections({ code: ['hfsecm.common', 'hfsecm.archive.room'] })(
  CreateRooms
);
