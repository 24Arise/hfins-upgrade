import {
  Button,
  DataSet,
  Dropdown,
  Form,
  IntlField,
  Menu,
  Output,
  Spin,
  TextField
} from 'choerodon-ui/pro';
import { Checkbox, Radio, notification } from 'choerodon-ui';
import { FieldFormat, FieldType } from 'choerodon-ui/dataset/data-set/enum';
import { formatterCollections } from 'utils/intl/formatterCollections';
import { getCurrentOrganizationId } from 'hzero-front/src/utils/utils';
import { observable } from 'mobx';
import { observer } from 'mobx-react';
import Icon from '@common/components/Icon';
import ItemGroup from 'choerodon-ui/pro/lib/form/ItemGroup';
import React, { Component, ReactNode } from 'react';
import commonConfig from '@common/config/commonConfig';
import completeSvg from '../images/complete.svg';
import intl from 'hzero-front/src/utils/intl';
import openAssignAppendageModal from '../commonModal/assignAppendage';
import request from '@common/utils/request';

interface roomProps {
  dataSet: DataSet;
  floorInfo: any;
  isDisabled?: boolean;
  assignAppendageDS?: DataSet;
  editAppendage?: any;
  isEditCreate?: string;
}

const FIELDS = [
  {
    name: 'appendageType',
    type: FieldType.string,
    required: true
  },
  {
    name: 'appendageCode',
    type: FieldType.string,
    label: intl.get('hfsecm.archive.room.appendCode').d('配件代码'),
    format: FieldFormat.uppercase,
    required: true
  },
  {
    name: 'description',
    type: FieldType.string,
    label: intl.get('hfsecm.archive.room.appendDesc').d('配件名称'),
    required: true
  },
  {
    name: 'roomCode',
    type: FieldType.string,
    required: true
  },
  {
    name: 'locationCode',
    type: FieldType.string,
    required: true
  },
  {
    name: 'coordinate',
    type: FieldType.string
  },
  {
    name: 'enabledFlag',
    type: FieldType.boolean,
    label: intl.get('hfsecm.common.enabledFlag')
  },
  {
    name: 'x1',
    type: FieldType.number
  },
  {
    name: 'x2',
    type: FieldType.number
  },
  {
    name: 'y1',
    type: FieldType.number
  },
  {
    name: 'y2',
    type: FieldType.number
  }
];

@observer
class ArchiveRoom extends Component<roomProps> {
  @observable list: any = [];

  @observable loading = false;

  // 当前楼层
  @observable mode: any = '';

  // 当前配件(档案室, 门还是窗)
  @observable currentParts = 'room';

  // 当前正在编辑的坐标是哪个顶点
  @observable currentPort = '';

  @observable assignAppendageDS: DataSet;

  // 是新建还是创建平级/子集
  @observable createType: any;

  // 配件DS集合
  @observable DSList: any = [];

  @observable maxDoorIndex = 1;

  @observable maxWinIndex = 1;

  constructor(props) {
    super(props);
    this.props.dataSet.getField('roomNumber')?.set('required', false);
    this.assignAppendageDS = new DataSet();
    if (this.props.dataSet.length && this.props.dataSet.get(0)?.get('locationId')) {
      this.props.dataSet.setQueryParameter('roomCode', this.props.dataSet.get(0)?.get('roomCode'));
      if (this.props.isEditCreate) {
        if (this.props.isEditCreate === 'FLOOR') {
          this.props.dataSet.setQueryParameter(
            'locationCode',
            this.props.dataSet.get(0)?.get('parentLocationCode')
          );
          this.props.dataSet.setQueryParameter('locationType', 'FLOOR');
        } else if (this.props.isEditCreate === 'ROOM') {
          this.props.dataSet.setQueryParameter(
            'locationCode',
            this.props.dataSet.get(0)?.get('locationCode')
          );
          this.props.dataSet.setQueryParameter('locationType', 'ROOM');
        }
        this.props.dataSet.query().then(res => {
          const roomList: any = [];
          res.forEach((r: any) => {
            r.roomList.forEach(room => {
              room.currentParts = 'room';
            });
            roomList.push(...r.roomList);
          });
          this.props.dataSet.data = roomList;
          // 配件信息, 多语言组件只能DS, 遂 一个档案室创建一个配件的DS, 对应的DS名称以档案室编码
        });
      }
    }
    this.props.dataSet.forEach(item => {
      const dsName = item.get('locationCode');
      const appData: any = [];
      this.DSList[dsName] = new DataSet({
        fields: FIELDS,
        transport: {
          submit: ({ data, params }) => {
            return {
              data,
              params,
              url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/appendage`,
              method: 'POST'
            };
          }
        },
        events: {
          update: ({ record, name, value }) =>
            this.handleAppendageUpdate(item, { record, name, value })
        }
      });
      if (item.get('doors')) {
        appData.push(...item.get('doors'));
      }
      if (item.get('windows')) {
        appData.push(...item.get('windows'));
      }
      this.DSList[dsName].data = appData;
    });
  }

  async componentDidMount() {
    setTimeout(async () => {
      if (this.props.floorInfo.length) {
        this.mode = this.props.floorInfo[0].code;
      }
      // 当编辑配件时
      if (this.props.editAppendage) {
        const appenList: any = this.props.editAppendage.toData();
        this.DSList[appenList.locationCode].data = [appenList];
      }
    }, 20);
    setTimeout(async () => {
      const doorMaxSeq: any =
        (await this.handleQueryMaxSeq({
          locationCode: this.props.dataSet.get(0)?.get('locationCode'),
          appendageType: 'DOOR',
          roomCode: this.props.dataSet.get(0)?.get('roomCode')
        })) || 1;
      this.maxDoorIndex = doorMaxSeq;
      const winMaxSeq: any =
        (await this.handleQueryMaxSeq({
          locationCode: this.props.dataSet.get(0)?.get('locationCode'),
          appendageType: 'WINDOW',
          roomCode: this.props.dataSet.get(0)?.get('roomCode')
        })) || 1;
      this.maxWinIndex = winMaxSeq;

      if (this.props.assignAppendageDS && this.props.assignAppendageDS?.length > 0) {
        const assignData = this.props.assignAppendageDS?.get(0);
        this.assignAppendageDS.create(
          {
            doorNum: assignData?.get('doorNum'),
            winNum: assignData?.get('winNum')
          },
          0
        );
        this.handleAssignOk(this.props.dataSet.current);
      }
    }, 500);
  }

  handleAppendageUpdate = (item, { record, name, value }) => {
    if (name === 'x1' || name === 'y1' || name === 'x2' || name === 'y2') {
      if (value) {
        this.renderImage(item, record.get('appendageType'));
      }
    }
  };

  handleChangeRadio = value => {
    this.mode = value.target.value;
  };

  /**
   * 分配室内配件
   * @returns
   */
  handleAssign = async (data, type) => {
    // debugger
    let text = '';
    this.assignAppendageDS.reset();
    this.assignAppendageDS.create({}, 0);

    if (type === 'single') {
      const { title = '' } = this.props.floorInfo.filter(f => f.code === this.mode)[0];
      text = title + data.get('description');
      openAssignAppendageModal(text, data, this.handleAssignModalOk);
    } else {
      let flag = true;
      // 批量分配
      const showTitle: any = [];
      for (let i = 0, j = data.length; i < j; i++) {
        // debugger
        for (let m = 0, n = this.props.floorInfo.length; m < n; m++) {
          if (data[i].get('parentLocationCode') === this.props.floorInfo[m].code) {
            showTitle.push(this.props.floorInfo[m].title + data[i].get('description'));
          }
        }
        // 当选中的数据有未保存过的数据, 提示
        if (!data[i].get('locationId')) {
          notification.warning({
            message: intl
              .get('hfsecm.archive.room.notSaveData')
              .d('选择的数据中存在未保存的档案室, 请先保存'),
            description: null,
            placement: 'bottomRight'
          });
          flag = false;
          return false;
        }
      }
      if (flag) {
        text = showTitle.join(',');
        openAssignAppendageModal(text, 'all', this.handleAssignModalOk);
      }
    }
  };

  handleAssignModalOk = (ds, data) => {
    const assign = ds.toData();
    this.assignAppendageDS.data = assign;
    if (data === 'all') {
      const { selected = [] } = this.props.dataSet;
      if (selected.length) {
        selected.forEach(item => {
          this.handleAssignOk(item);
        });
      }
    } else {
      this.handleAssignOk(data);
    }
  };

  handleAssignOk = async data => {
    if (await this.assignAppendageDS?.validate()) {
      if (this.assignAppendageDS.current?.get('doorNum') > 0) {
        // 得到最大的序号
        // this.maxDoorIndex -= 1;
        for (let i = 0; i < this.assignAppendageDS.current?.get('doorNum'); i++) {
          // this.maxDoorIndex++;
          const doorIndex = this.maxDoorIndex < 10 ? `0${this.maxDoorIndex}` : this.maxDoorIndex;
          this.DSList[data.get('locationCode')].create(
            {
              roomCode: data.get('roomCode'),
              locationCode: data.get('locationCode'),
              appendageType: 'DOOR',
              appendageCode: `D0${doorIndex}`,
              seqNumber: this.maxDoorIndex,
              x1: null,
              y1: null,
              x2: null,
              y2: null,
              description: `门`,
              currentIndex: i
            },
            0
          );
          this.maxDoorIndex++;
        }
        const filterData = this.DSList[data.get('locationCode')]?.filter(
          item => item.get('appendageType') === 'DOOR'
        );
        data.set('doors', filterData);
        this.renderParts(data);
      }
      if (this.assignAppendageDS.current?.get('winNum') > 0) {
        for (let i = 0; i < this.assignAppendageDS.current?.get('winNum'); i++) {
          // this.maxDoorIndex++;
          const seq = this.maxWinIndex < 10 ? `0${this.maxWinIndex}` : this.maxWinIndex;
          this.DSList[data.get('locationCode')].create(
            {
              roomCode: data.get('roomCode'),
              locationCode: data.get('locationCode'),
              appendageType: 'WINDOW',
              description: `窗户`,
              appendageCode: `W0${seq}`,
              seqNumber: this.maxWinIndex,
              x1: null,
              y1: null,
              x2: null,
              y2: null
            },
            0
          );
          this.maxWinIndex++;
        }
        const filterData = this.DSList[data.get('locationCode')]?.filter(
          item => item.get('appendageType') === 'WINDOW'
        );
        data.set('windows', filterData);
        this.renderParts(data);
      }
    } else {
      return false;
    }
  };

  handleFocusPoint = value => {
    this.currentPort = value;
  };

  /**
   * 门
   * @params data 当前档案室
   * @returns
   */
  renderDoorMenu = data => {
    const door = this.DSList[data.get('locationCode')]?.filter(
      item => item.get('appendageType') === 'DOOR'
    );
    if (door && door.length > 0) {
      return (
        <Menu>
          {door.map(iem => {
            return (
              <Menu.Item key={`${iem.get('appendageCode')}-${iem.get('description')}`}>
                <a
                  onClick={() => {
                    data.set('currentParts', 'door');
                    data.set('currentAppendage', iem.get('appendageCode'));
                    this.renderDoorData(iem);
                  }}
                >
                  {iem.get('description')}
                </a>
              </Menu.Item>
            );
          })}
        </Menu>
      );
    }
    return <></>;
  };

  /**
   * 窗户菜单
   */
  renderWinMenu = data => {
    const win = this.DSList[data.get('locationCode')]?.filter(
      item => item.get('appendageType') === 'WINDOW'
    );
    if (win && win.length > 0) {
      return (
        <Menu>
          {win.map(iem => {
            return (
              <Menu.Item key={`${iem.get('appendageCode')}-${iem.get('description')}`}>
                <a
                  onClick={() => {
                    data.set('currentParts', 'win');
                    data.set('currentAppendage', iem.get('appendageCode'));
                    this.renderWinData(iem);
                  }}
                >
                  {iem.get('description')}
                </a>
              </Menu.Item>
            );
          })}
        </Menu>
      );
    }
    return <></>;
  };

  /**
   * 渲染选中门的form表单
   */
  renderDoorData = data => {
    // 得到当前档案室筛选的门的数据
    if (data) {
      return (
        <Form className="ecm-room-part-form" record={data}>
          <Output name="appendageCode" />
          <IntlField name="description" />
          <ItemGroup
            label={intl.get('hfsecm.archive.room.appendageCoordinate1').d('坐标1')}
            required
            compact
          >
            <TextField
              className="ecm-room-part-form-item"
              name="x1"
              onFocus={() => {
                this.handleFocusPoint('doorx1');
              }}
            />
            <span> , </span>
            <TextField
              className="ecm-room-part-form-item"
              name="y1"
              onFocus={() => {
                this.handleFocusPoint('doory1');
              }}
            />
          </ItemGroup>
          <ItemGroup
            label={intl.get('hfsecm.archive.room.appendageCoordinate2').d('坐标2')}
            required
            compact
          >
            <TextField
              className="ecm-room-part-form-item"
              name="x2"
              onFocus={() => {
                this.handleFocusPoint('doorx2');
              }}
            />
            <span> , </span>
            <TextField
              className="ecm-room-part-form-item"
              name="y2"
              onFocus={() => {
                this.handleFocusPoint('doory2');
              }}
            />
          </ItemGroup>
        </Form>
      );
    }
  };

  /**
   * 渲染选中窗的form表单
   */
  renderWinData = data => {
    // 得到当前档案室筛选的门的数据
    if (data) {
      return (
        <Form className="ecm-room-part-form" record={data}>
          <Output name="appendageCode" />
          <IntlField name="description" />
          <ItemGroup
            label={intl.get('hfsecm.archive.room.appendageCoordinate1').d('坐标1')}
            required
            compact
          >
            <TextField
              className="ecm-room-part-form-item"
              name="x1"
              onFocus={() => {
                this.handleFocusPoint('winx1');
              }}
            />
            <span> , </span>
            <TextField
              className="ecm-room-part-form-item"
              name="y1"
              onFocus={() => {
                this.handleFocusPoint('winy1');
              }}
            />
          </ItemGroup>
          <ItemGroup
            label={intl.get('hfsecm.archive.room.appendageCoordinate2').d('坐标2')}
            required
            compact
          >
            <TextField
              className="ecm-room-part-form-item"
              name="x2"
              onFocus={() => {
                this.handleFocusPoint('winx2');
              }}
            />
            <span> , </span>
            <TextField
              className="ecm-room-part-form-item"
              name="y2"
              onFocus={() => {
                this.handleFocusPoint('winy2');
              }}
            />
          </ItemGroup>
        </Form>
      );
    }
  };

  @observable
  handleCheck = record => {
    if (record?.isSelected) {
      this.props.dataSet.unSelect(record);
    } else {
      this.props.dataSet.select(record);
    }
  };

  handleShowRoom = () => {
    const rommDS: any = this.props.dataSet.filter(
      item => item.get('parentLocationCode') === this.mode
    );
    return rommDS.map(item => {
      return (
        <div className="ecm-room-sec">
          <div className="ecm-room-sec-header ">
            <p className="ecm-room-sec-header-title">{item.get('description')}</p>
            {(!this.props.isDisabled || (this.props.isDisabled && !this.props.editAppendage)) && (
              <div className="ecm-room-sec-header-oprate">
                <Button
                  className="ecm-room-sec-header-btn"
                  onClick={() => this.handleAssign(item, 'single')}
                  disabled={!item.get('locationId')}
                  icon="fenpei-o"
                >
                  {intl.get('hfsecm.archive.room.assignRoomParts').d('分配室内配件')}
                </Button>
                <div
                  onClick={() => {
                    this.handleCheck(item);
                  }}
                >
                  <Checkbox value={item.isSelected} style={{ marginTop: '6px' }} />
                </div>
              </div>
            )}
          </div>
          <div className="ecm-room-flex-part">
            {(!this.props.isDisabled || (this.props.isDisabled && !this.props.editAppendage)) && (
              <Button
                onClick={() => {
                  item.set('currentParts', 'room');
                }}
                className={[
                  'ecm-room-flex-radio',
                  'part-room',
                  item.get('currentParts') === 'room' ? 'part-room-active' : ''
                ].join(' ')}
              >
                {item.get('roomComplete') && (
                  <img className="part-radio-image" src={completeSvg} alt="" />
                )}
                <Icon type="a-fangzi" size={14} />
                {intl.get('hfsecm.archive.room.archiveRooms').d('档案室')}
              </Button>
            )}
            {((this.props.isDisabled && item.get('currentParts') === 'door') ||
              !this.props.isDisabled ||
              (this.props.isDisabled && !this.props.editAppendage)) && (
              <Dropdown
                overlay={() => this.renderDoorMenu(item)}
                disabled={this.DSList[item.get('locationCode')]?.length < 1}
              >
                <Button
                  onClick={() => {
                    item.set('currentParts', 'door');
                    const filter = this.DSList[item.get('locationCode')]?.filter(
                      d => d.get('appendageType') === 'DOOR'
                    );
                    if (filter && filter.length) {
                      item.set('currentAppendage', filter[0]?.get('appendageCode'));
                      this.renderDoorData(filter[0]);
                    }
                  }}
                  disabled={
                    !this.DSList[item.get('locationCode')]?.filter(
                      d => d.get('appendageType') === 'DOOR'
                    )
                  }
                  className={[
                    'ecm-room-flex-radio',
                    'part-door',
                    item.get('currentParts') === 'door' ? 'part-door-active' : ''
                  ].join(' ')}
                >
                  {/* <img src={doorImg} alt="" /> */}
                  <Icon type="a-men" size={14} />
                  {intl.get('hfsecm.archive.room.door').d('门')}
                  {this.DSList[item.get('locationCode')]?.length > 0 && (
                    <p className="part-door-num">
                      {
                        this.DSList[item.get('locationCode')]?.filter(
                          app => app.get('appendageType') === 'DOOR'
                        ).length
                      }
                    </p>
                  )}
                </Button>
              </Dropdown>
            )}
            {((this.props.isDisabled && item.get('currentParts') === 'win') ||
              !this.props.isDisabled ||
              (this.props.isDisabled && !this.props.editAppendage)) && (
              <Dropdown
                overlay={() => this.renderWinMenu(item)}
                disabled={this.DSList[item.get('locationCode')]?.length < 1}
              >
                <Button
                  onClick={() => {
                    item.set('currentParts', 'win');
                    const filter = this.DSList[item.get('locationCode')]?.filter(
                      d => d.get('appendageType') === 'WINDOW'
                    );
                    item.set('currentAppendage', filter[0]?.get('appendageCode'));
                    this.renderDoorData(filter[0]);
                  }}
                  disabled={
                    !this.DSList[item.get('locationCode')]?.filter(
                      d => d.get('appendageType') === 'WINDOW'
                    ).length
                  }
                  className={[
                    'ecm-room-flex-radio',
                    'part-win',
                    item.get('currentParts') === 'win' ? 'part-win-active' : ''
                  ].join(' ')}
                >
                  {/* <img src={winsImg} alt="" /> */}
                  <Icon type="a-chuang" size={14} style={{ marginRight: '1px' }} />
                  {intl.get('hfsecm.archive.room.window').d('窗')}
                  {this.DSList[item.get('locationCode')]?.length > 0 && (
                    <p className="part-win-num">
                      {
                        this.DSList[item.get('locationCode')]?.filter(
                          app => app.get('appendageType') === 'WINDOW'
                        ).length
                      }
                    </p>
                  )}
                </Button>
              </Dropdown>
            )}
          </div>
          <div className="ecm-room-flex-part">
            {/** 档案室图 */}
            <div className={['ecm-room-room'].join(' ')}>{this.renderParts(item)}</div>

            <div className="ecm-room-part-sec">
              <div className="ecm-room-part-sec-header">
                <p className="ecm-room-part-sec-header-title">
                  {intl.get('hfsecm.common.basicInformation')}
                </p>
                <div className="ecm-room-part-sec-header-btnGroup">
                  {item.get('currentParts') !== 'room' && !this.props.isDisabled && (
                    <Button
                      className="part-btn delete-btn"
                      onClick={() => this.handleDeleteAppendage(item)}
                    >
                      {intl.get('hfsecm.common.delete')}
                    </Button>
                  )}
                  <Button
                    className="part-btn cancel-btn"
                    onClick={() => {
                      this.handleCancel(item);
                    }}
                  >
                    {intl.get('hfsecm.common.cancel')}
                  </Button>
                  <Button className="part-btn sure-btn" onClick={() => this.handleSave(item)}>
                    {intl.get('hfsecm.common.save')}
                  </Button>
                </div>
              </div>
              {item.get('currentParts') === 'room' && (
                <Form record={item} className="ecm-room-part-form" disabled={this.props.isDisabled}>
                  <Output name="locationCode" />
                  <TextField name="description" />
                  <ItemGroup
                    label={intl.get('hfsecm.archive.room.leftTopCoordinate').d('左上坐标')}
                    required
                    compact
                  >
                    <TextField
                      className="ecm-room-part-form-item"
                      name="x1"
                      onFocus={() => {
                        this.handleFocusPoint('roomLeftTop');
                      }}
                    />
                    <span> , </span>
                    <TextField
                      className="ecm-room-part-form-item"
                      name="y1"
                      onFocus={() => {
                        this.handleFocusPoint('roomLeftTop');
                      }}
                    />
                  </ItemGroup>
                  <ItemGroup
                    label={intl.get('hfsecm.archive.room.rightTopCoordinate').d('右上坐标')}
                    required
                    compact
                  >
                    <TextField
                      className="ecm-room-part-form-item"
                      name="x2"
                      onFocus={() => {
                        this.handleFocusPoint('roomRightTop');
                      }}
                    />
                    <span> , </span>
                    <TextField
                      className="ecm-room-part-form-item"
                      name="y2"
                      onFocus={() => {
                        this.handleFocusPoint('roomRightTop');
                      }}
                    />
                  </ItemGroup>
                  <ItemGroup
                    label={intl.get('hfsecm.archive.room.rightBottomCoordinate').d('右下坐标')}
                    required
                    compact
                  >
                    <TextField
                      className="ecm-room-part-form-item"
                      name="x3"
                      onFocus={() => {
                        this.handleFocusPoint('roomRightBottom');
                      }}
                    />
                    <span> , </span>
                    <TextField
                      className="ecm-room-part-form-item"
                      name="y3"
                      onFocus={() => {
                        this.handleFocusPoint('roomRightBottom');
                      }}
                    />
                  </ItemGroup>
                  <ItemGroup
                    label={intl.get('hfsecm.archive.room.leftBottomCoordinate').d('左下坐标')}
                    required
                    compact
                  >
                    <TextField
                      className="ecm-room-part-form-item"
                      name="x4"
                      onFocus={() => {
                        this.handleFocusPoint('roomLeftBottom');
                      }}
                    />
                    <span> , </span>
                    <TextField
                      className="ecm-room-part-form-item"
                      name="y4"
                      onFocus={() => {
                        this.handleFocusPoint('roomLeftBottom');
                      }}
                    />
                  </ItemGroup>
                </Form>
              )}
              {item.get('currentParts') === 'door' && this.getAppendage('DOOR', item)}
              {item.get('currentParts') === 'win' && this.getAppendage('WINDOW', item)}
            </div>
          </div>
        </div>
      );
    });
  };

  /**
   *
   */
  getAppendage = (type, parent) => {
    if (type === 'DOOR') {
      const locationCode = parent.get('locationCode');
      const currentAppendage =
        parent.get('currentAppendage') || this.DSList[locationCode]?.get(0)?.get('appendageCode');
      if (this.DSList[locationCode]?.length > 0) {
        const filter = this.DSList[locationCode]?.filter(
          item => item.get('appendageCode') === currentAppendage
        );
        // if (filter) {
        return this.renderDoorData(filter[0]);
      }
    }
    if (type === 'WINDOW') {
      const locationCode = parent.get('locationCode');
      const currentAppendage =
        parent.get('currentAppendage') || this.DSList[locationCode]?.get(0)?.get('appendageCode');
      if (this.DSList[locationCode]?.length > 0) {
        const filter = this.DSList[locationCode]?.filter(
          item => item.get('appendageCode') === currentAppendage
        );
        return this.renderWinData(filter[0]);
      }
    }
  };

  /**
   * 删除配件
   * @params data 当前档案室信息
   */
  handleDeleteAppendage = data => {
    const type = this.DSList[data.get('locationCode')].get(0)?.get('appdageType') || 'DOOR';
    // 得到要删除的配件编码
    this.DSList[data.get('locationCode')].forEach(item => {
      if (item.get('appendageCode') === data.get('currentAppendage')) {
        item.set('_status', 'delete');
        this.DSList[data.get('locationCode')].delete(item);
      }
    });
    this.renderImage(data, type);
    data.set('currentParts', 'room');
  };

  handleCancel = data => {
    if (data.get('currentParts') === 'room') {
      data.reset();
    } else {
      this.DSList[data.get('locationCode')].forEach(item => {
        if (item.get('appendageCode') === data.get('currentAppendage')) {
          item.reset();
        }
      });
      if (!this.DSList[data.get('locationCode')].length) {
        data.set('currentParts', 'room');
      }
    }
  };

  /**
   * 渲染图形
   * @returns
   */
  renderParts = item => {
    return (
      <>
        {item.get('currentParts') === 'room' && (
          <div className="ecm-room-room-div">
            <p
              className={[
                'room-point1',
                this.currentPort === 'roomLeftTop' && 'room-point-focus'
              ].join(' ')}
            />
            <p
              className={[
                'room-point2',
                this.currentPort === 'roomRightTop' && 'room-point-focus'
              ].join(' ')}
            />
            <p
              className={[
                'room-point3',
                this.currentPort === 'roomLeftBottom' && 'room-point-focus'
              ].join(' ')}
            />
            <p
              className={[
                'room-point4',
                this.currentPort === 'roomRightBottom' && 'room-point-focus'
              ].join(' ')}
            />
          </div>
        )}
        {item.get('currentParts') === 'door' && (
          <div className="ecm-room-room-div">{this.renderImage(item, 'DOOR')}</div>
        )}
        {item.get('currentParts') === 'win' && (
          <div className="ecm-room-room-div">{this.renderImage(item, 'WINDOW')}</div>
        )}
      </>
    );
  };

  /**
   * 渲染门/窗的图纸
   * @params item 档案室下所有的信息
   */
  renderImage = (item, type) => {
    const doorImgae: Array<ReactNode> = [];
    const imageData = this.DSList[item.get('locationCode')]?.filter(
      app => app.get('appendageType') === type
    );
    // 判断当前状态
    if (imageData && imageData.length > 0) {
      // 新建档案室中的附属物信息时, 一共有多少个门, 均分至四条边,每条边有几个门
      let num =
        type === 'DOOR'
          ? this.assignAppendageDS.current?.get('doorNum')
          : this.assignAppendageDS.current?.get('winNum');
      num = num || 0;
      // 四条边, 每条边均分几个配件
      const avgDoor = Math.floor(num / 4);
      // 取余, 当余数大于0时, 将多余的按顺序分配至上右下左 四条边
      const yuNum = num % 4;
      // 计算每条边有多少个配件
      const appNum1 = avgDoor + (yuNum > 0 ? 1 : 0);
      const appNum2 = avgDoor + (yuNum > 1 ? 1 : 0);
      const appNum3 = avgDoor + (yuNum > 2 ? 1 : 0);
      const appNum4 = avgDoor;
      // 得到档案室左顶点的X轴,y轴坐标值
      const { x1, x2, y1, y3 } = item.toData();
      imageData.forEach((dr, index) => {
        let showLeft1 = 0;
        let showLeft2 = 0;
        let showTop1 = 0;
        let showTop2 = 0;
        let left1 = 0;
        let top1 = 0;
        let left2 = 0;
        let top2 = 0;
        let width = 5;
        let height = 5;
        // 由于档案室的宽高固定, 须计算出按照当前宽高, 每1px 坐标该偏移多少
        const diffX = (x2 - x1) / 120;
        const diffY = (y3 - y1) / 80;
        if (dr.get('x1') || dr.get('y1') || dr.get('x2') || dr.get('y2')) {
          if (dr.get('x1') || String(dr.get('x1') === '0')) {
            // if (dr.get('x1') !== x1) {
            showLeft1 = (dr.get('x1') - x1) / diffX - 5 < 0 ? 0 : (dr.get('x1') - x1) / diffX - 5;
            // } else {
            //   showLeft1 = ((dr.get('x1') - x1) / diffX - 5) < 0 ? 0 : ((dr.get('x1') - x1) / diffX - 5);
            // }
          }
          if (dr.get('x2') || String(dr.get('x2') === '0')) {
            // if (dr.get('x2') !== x2) {
            showLeft2 = (dr.get('x2') - x1) / diffX - 5 < 0 ? 0 : (dr.get('x2') - x1) / diffX - 5;
            // } else {
            //   showLeft2 = ((dr.get('x2') - x1) / diffX - 5) < 0 ? 0 : ((dr.get('x2') - x1) / diffX - 5);
            // }
          }
          if (dr.get('y1') || String(dr.get('y1') === '0')) {
            // if (dr.get('y1') !== y1) {
            showTop1 = (dr.get('y1') - y1) / diffY - 5 < 0 ? 0 : (dr.get('y1') - y1) / diffY - 5;
            // } else {
            //   showTop1 = ((dr.get('y1') - y1) / diffY - 5) < 0 ? 0 : ((dr.get('y1') - y1) / diffY - 5);
            // }
          }
          if (dr.get('y2') || String(dr.get('y2')) === '0') {
            // if (dr.get('y2') !== y3) {
            showTop2 = (dr.get('y2') - y1) / diffY - 5 < 0 ? 0 : (dr.get('y2') - y1) / diffY - 5;
            // } else {
            //   showTop2 = ((dr.get('y2') - y3) / diffY - 5) < 0 ? 0 : ((dr.get('y2') - y3) / diffY - 5);
            // }
          }
          width = showLeft2 - showLeft1 || 5;
          height = showTop2 - showTop1 || 5;
        } else {
          if (index % 4 === 0) {
            left1 = Math.floor((x2 - x1) / appNum1) * (index / 4 + 1) - 100 + x1;
            left2 = Math.floor((x2 - x1) / appNum1) * (index / 4 + 1) + x1;
            top1 = 0;
            top2 = 0;
          }
          if (index % 4 === 1) {
            const i = (index - 1) / 4 + 1;
            top1 = Math.floor((y3 - y1) / appNum2) * i - 100 + y1;
            top2 = Math.floor((y3 - y1) / appNum2) * i + y1;
            left1 = x2;
            left2 = x2;
          }
          if (index % 4 === 2) {
            const i = (index - 2) / 4 + 1;
            left1 =
              Math.floor((x2 - x1) / appNum3) * i - 100 < x1
                ? x1
                : Math.floor((x2 - x1) / appNum3) * i - 100;
            left2 =
              Math.floor((x2 - x1) / appNum3) * i < x1 ? x1 : Math.floor((x2 - x1) / appNum3) * i;
            top1 = y3 - y1;
            top2 = y3 - y1;
          }
          if (index % 4 === 3) {
            const i = (index - 3) / 4 + 1;
            top1 =
              Math.floor((y3 - y1) / appNum4) * i - 100 < y1
                ? y1
                : Math.floor((y3 - y1) / appNum4) * i - 100;
            top2 =
              Math.floor((y3 - y1) / appNum4) * i < y1 ? y1 : Math.floor((y3 - y1) / appNum4) * i;
            left1 = 0;
            left2 = 0;
          }
          // if (left1 !== x1) {
          showLeft1 = (left1 - x1) / diffX - 5 < 0 ? 0 : (left1 - x1) / diffX - 5;
          // } else {
          //   showLeft1 = ((left1 - x1) / diffX - 5) < 0 ? 0 : ((left1 - x1) / diffX - 5);
          // }
          // if (left2 !== x2) {
          showLeft2 = (left2 - x1) / diffX - 5 < 0 ? 0 : (left2 - x1) / diffX - 5;
          // } else {
          //   showLeft2 = ((left2 - x1) / diffX - 5) < 0 ? 0 : ((left2 - x1) / diffX - 5);
          // }
          // if (top1 !== y1) {
          showTop1 = (top1 - y1) / diffY - 5 < 0 ? 0 : (top1 - y1) / diffY - 5;
          // } else {
          //   showTop1 = ((top1 - y1) / diffY - 5) < 0 ? 0 : ((top1 - y1) / diffY - 5);
          // }
          // if (top2 !== y3) {
          showTop2 = (top2 - y1) / diffY - 5 < 0 ? 0 : (top2 - y1) / diffY - 5;
          // } else {
          //   showTop1 = ((top2 - y3) / diffY - 5) < 0 ? 0 : ((top2 - y3) / diffY - 5);
          // }
          width = showLeft2 - showLeft1 || 5;
          height = showTop2 - showTop1 || 5;
          dr.init('x1', left1);
          dr.init('y1', top1);
          dr.init('x2', left2);
          dr.init('y2', top2);
        }
        // 正在修改部分,展示顶点,否则不展示
        doorImgae.push(
          <>
            <div
              className="room-doors"
              style={{
                width: `${width}px`,
                height: `${height}px`,
                top: `${showTop1}px`,
                left: `${showLeft1}px`
              }}
              onClick={() => {
                item.set('currentAppendage', dr.get('appendageCode'));
                if (type === 'DOOR') {
                  this.renderDoorData(dr);
                } else {
                  this.renderWinData(dr);
                }
              }}
            />
            {item.get('currentAppendage') === dr.get('appendageCode') && (
              <>
                <div
                  className="room-doors-point"
                  style={{ left: `${showLeft1}px`, top: `${showTop1}px` }}
                />
                <div
                  className="room-doors-point"
                  style={{ left: `${showLeft2}px`, top: `${showTop2}px` }}
                />
              </>
            )}
          </>
        );
      });
    }
    return doorImgae;
  };

  /**
   * 保存
   * @returns
   */
  handleSave = async data => {
    this.loading = true;
    if (data.get('currentParts') === 'room') {
      if (await data?.validate()) {
        const roomStatus = data.get('locationId');
        const doorsData: any = [];
        const winsData: any = [];
        if (data.get('doors') || data.get('windows')) {
          this.DSList[data.get('locationCode')].forEach(item => {
            if (item.get('appendageType') === 'DOOR') {
              doorsData.push(item.toJSONData());
            } else if (item.get('appendageType') === 'WINDOW') {
              winsData.push(item.toJSONData());
            }
          });
          if (data.get('_status') === 'create') {
            data.set('_status', 'update');
          }
        }
        data?.set('doors', doorsData);
        data?.set('windows', winsData);
        const reqData = data.toJSONData();
        reqData._status = reqData.locationId ? 'update' : 'create';
        // this.props.dataSet.submit(data);
        this.handleSaveSingle(reqData).then(async (res: any) => {
          this.loading = false;
          if (res && res.failed) {
            notification.error({
              message: res.message,
              description: null,
              placement: 'bottomRight'
            });
          } else {
            data.set({ ...res[0] });
            notification.success({
              message: intl.get('hfsecm.common.successfulOperation'),
              description: null,
              placement: 'bottomRight'
            });
            setTimeout(() => {
              data._status = 'update';
            }, 0);
            // 判断是否是新建, 新建, DSList 则需要插值
            if (!roomStatus) {
              this.DSList[data.get('locationCode')] = new DataSet({
                fields: FIELDS,
                events: {
                  update: ({ record, name, value }) =>
                    this.handleAppendageUpdate(data, { record, name, value })
                }
              });
            } else {
              const appendage: any = [];
              res[0].doors.forEach(item => {
                item._status = 'update';
                appendage.push(item);
              });
              if (res[0].windows) {
                res[0].windows.forEach(item => {
                  item._status = 'update';
                  appendage.push(item);
                });
              }
              this.DSList[res[0].locationCode].data = appendage;
            }
          }
        });
      } else {
        this.loading = false;
      }
    } else {
      const doorsData: any = [];
      const winsData: any = [];
      this.DSList[data.get('locationCode')].forEach(item => {
        if (item.get('appendageType') === 'DOOR') {
          doorsData.push(item.toJSONData());
        } else if (item.get('appendageType') === 'WINDOW') {
          winsData.push(item.toJSONData());
        }
      });
      if (data.get('_status') === 'create') {
        data.set('_status', 'update');
      }
      data?.set('doors', doorsData);
      data?.set('windows', winsData);
      const reqData = data.toJSONData();
      reqData._status = 'update';
      this.handleSaveSingle(reqData)
        .then(async (res: any) => {
          if (res && res.failed) {
            notification.error({
              message: res.message,
              description: null,
              placement: 'bottomRight'
            });
            this.loading = false;
          } else {
            data.set({ ...res[0] });
            notification.success({
              message: intl.get('hfsecm.common.successfulOperation'),
              description: null,
              placement: 'bottomRight'
            });
            const appendage: any = [];

            res[0].doors.forEach(item => {
              item._status = 'update';
              appendage.push(item);
            });
            if (res[0].windows) {
              res[0].windows.forEach(item => {
                item._status = 'update';
                appendage.push(item);
              });
            }
            this.DSList[res[0].locationCode].data = appendage;
            this.loading = false;
          }
        })
        .catch(() => {
          this.loading = false;
        });
    }
  };

  /**
   * 保存单个档案室
   */
  handleSaveSingle = data => {
    return request(`${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location`, {
      method: 'POST',
      data: [data]
    });
  };

  /**
   * 查询配件的最大序号
   * @returns
   */
  handleQueryMaxSeq = params => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/appendage/sequence`,
      {
        method: 'GET',
        params
      }
    );
  };

  /**
   * 全选
   * @returns
   */
  handleCheckAll = checked => {
    if (checked) {
      this.props.dataSet?.selectAll();
    } else {
      this.props.dataSet?.unSelectAll();
    }
  };

  render() {
    return (
      <>
        <Spin spinning={this.loading}>
          <div className="ecm-section">
            <p className="ecm-section-header">{intl.get('hfsecm.common.basicInformation')}</p>
            <div className="ecm-section-flex">
              <Radio.Group
                value={this.mode}
                onChange={this.handleChangeRadio}
                style={{ marginBottom: 16 }}
              >
                {this.props.floorInfo?.map(floor => {
                  return <Radio.Button value={floor.code}>{floor.title}</Radio.Button>;
                })}
              </Radio.Group>
              {this.props.isDisabled && (
                <div className="ecm-section-flex-operator">
                  <Checkbox
                    onChange={e => {
                      this.handleCheckAll(e.target.checked);
                    }}
                  >
                    {intl.get('hfsecm.archive.room.selectAll').d('全选')}
                  </Checkbox>
                  <Button
                    className="ecm-room-sec-header-btn"
                    disabled={this.props.dataSet.selected?.length < 1}
                    onClick={() => this.handleAssign(this.props.dataSet.selected, 'all')}
                    icon="fenpei-o"
                  >
                    {intl.get('hfsecm.archive.room.assignRoomParts').d('分配室内配件')}
                  </Button>
                </div>
              )}
            </div>
            <p>{intl.get('hfsecm.archive.room.roomTips').d('注：坐标以cm为单位测量填写')}</p>

            {/** 展示当前楼层的档案室信息 */}
            {this.mode && <div className="ecm-room-flex">{this.handleShowRoom()}</div>}
          </div>
        </Spin>
      </>
    );
  }
}

export default formatterCollections({ code: ['hfsecm.common', 'hfsecm.archive.room'] })(
  ArchiveRoom
);
