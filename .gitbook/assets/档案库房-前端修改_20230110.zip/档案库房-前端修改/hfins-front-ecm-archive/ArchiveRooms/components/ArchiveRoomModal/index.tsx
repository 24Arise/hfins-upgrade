import Floor from './floor';
import Room from './room';
import Shelf from './shelf';
import Storage from './storage';

export { Storage, Floor, Room, Shelf };
