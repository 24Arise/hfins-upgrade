import { DataSet, Form, IntlField, Lov, NumberField, TextField } from 'choerodon-ui/pro/lib';
import { formatterCollections } from 'utils/intl/formatterCollections';
// import { observable } from 'mobx';
import ItemGroup from 'choerodon-ui/pro/lib/form/ItemGroup';
import React, { Component } from 'react';
import intl from 'hzero-front/src/utils/intl';

interface storageProps {
  dataSet: DataSet;
  floor: DataSet;
  isEditCreate: any;
}

class CreateRooms extends Component<storageProps> {
  stepList: any;

  render() {
    return (
      <>
        <div className="ecm-section">
          <p className="ecm-section-header">{intl.get('hfsecm.common.basicInformation')}</p>
          <Form dataSet={this.props.dataSet} columns={2} disabled={this.props.floor?.length > 0}>
            <TextField name="roomCode" />
            <IntlField name="description" />
            <TextField name="roomLocation" colSpan={2} />
            <Lov name="destructorObj" colSpan={2} />
          </Form>
        </div>
        <div className="ecm-section">
          <p className="ecm-section-header">{intl.get('hfsecm.archive.room.physicalProperty')}</p>
          <Form dataSet={this.props.dataSet} columns={2} disabled={this.props.floor?.length > 0}>
            <NumberField name="length" />
            <NumberField name="width" />
            {!this.props.isEditCreate && (
              <ItemGroup
                label={intl.get('hfsecm.archive.room.storageFloor').d('该楼栋一共有')}
                required
                compact
              >
                <span className="ecm-storage-flex-input">
                  {' '}
                  <TextField
                    name="floorNumber"
                    suffix={intl.get('hfsecm.archive.room.layer').d('层')}
                  />
                </span>
              </ItemGroup>
            )}
            {!this.props.isEditCreate && (
              <ItemGroup label={intl.get('hfsecm.archive.room.floorsHeight').d('层高为')} compact>
                <span className="ecm-storage-flex-input">
                  <TextField
                    name="floorHeight"
                    suffix={intl.get('hfsecm.archive.room.lengthUnit').d('米')}
                  />
                </span>
              </ItemGroup>
            )}
          </Form>
        </div>
      </>
    );
  }
}

export default formatterCollections({ code: ['hfsecm.common', 'hfsecm.archive.room'] })(
  CreateRooms
);
