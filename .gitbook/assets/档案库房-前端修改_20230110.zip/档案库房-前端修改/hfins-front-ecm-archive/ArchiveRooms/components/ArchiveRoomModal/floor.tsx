import { DataSet, Form, IntlField, TextField } from 'choerodon-ui/pro/lib';
import { formatterCollections } from 'utils/intl/formatterCollections';
import { observer } from 'mobx-react';
import ItemGroup from 'choerodon-ui/pro/lib/form/ItemGroup';
import React, { Component } from 'react';
import intl from 'hzero-front/src/utils/intl';

interface floorProps {
  dataSet: DataSet;
}

@observer
class ArchiveFloors extends Component<floorProps> {
  stepList: any;

  render() {
    return (
      <>
        {this.props.dataSet.map(item => {
          return (
            <div className="ecm-section">
              <p className="ecm-section-header">
                {intl.get('hfsecm.common.basicInformation')}/{item.get('description')}
              </p>
              <Form record={item} columns={2} disabled={item.get('locationId')}>
                <TextField name="locationCode" disabled />
                <IntlField name="description" />
                <TextField name="height" colSpan={2} />
                <ItemGroup
                  label={intl.get('hfsecm.archive.room.floorIncludeRooms').d('该楼层一共有')}
                  required
                  compact
                >
                  <span className="ecm-storage-flex-input">
                    {' '}
                    <TextField
                      name="roomNumber"
                      suffix={intl.get('hfsecm.archive.room.roomsCount').d('个档案室')}
                    />
                  </span>
                </ItemGroup>
              </Form>
            </div>
          );
        })}
      </>
    );
  }
}

export default formatterCollections({ code: ['hfsecm.common', 'hfsecm.archive.room'] })(
  ArchiveFloors
);
