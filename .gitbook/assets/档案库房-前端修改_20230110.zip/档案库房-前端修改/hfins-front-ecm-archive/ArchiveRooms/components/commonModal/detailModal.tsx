/*
 * @Description: 消息推送历史错误数据回滚弹窗
 * @Author: hualv.jiang <hualv.jiang@hand-china.com>
 * @Date: 2020-11-04 14:35:02
 * @LastEditTime: 2021-11-13 14:28:18
 * @Copyright: Copyright (c) 2020, Hand
 */

import { ArchiveFloorDS, ArchiveRoomDS, ArchiveShelfDS, ArchiveStorageDS } from '../../stores';
import { Button, DataSet, Modal } from 'choerodon-ui/pro';
import { Floor, Room, Shelf, Storage } from '../ArchiveRoomModal/index';
import { Steps, notification } from 'choerodon-ui';
import { getCurrentOrganizationId } from 'hzero-front/src/utils/utils';
import { observable } from 'mobx';
import React, { Component } from 'react';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';
import request from '@common/utils/request';

const modalKey = Modal.key();
const Step = Steps.Step;

interface roomsProps {
  currentStep: number;
  callback?: any;
  treeNode?: {
    desciption: null;
    roomCode: null;
    locationType: null;
    locationCode: null;
    parentLocationCode: null;
    childLocations: [];
    locationId: null;
    locationInfo: any;
    parentNode: any;
  };
}

class CreateRooms extends Component<roomsProps> {
  @observable stepList: any;

  @observable archiveRoomDS: DataSet;

  @observable archiveFloorDS: DataSet;

  @observable archiveStorageDS: DataSet;

  @observable archiveShelfDS: DataSet;

  @observable isEditCreate: any;

  @observable floorsInfo: any;

  constructor(props) {
    super(props);
    this.isEditCreate = '';
    this.floorsInfo = [];
    this.archiveStorageDS = new DataSet({
      autoCreate: true,
      ...ArchiveStorageDS()
    });
    this.archiveRoomDS = new DataSet({
      ...ArchiveRoomDS(),
      events: {
        update: ({ record }) => {
          record.set('roomComplete', false);
        }
      }
    });
    this.archiveFloorDS = new DataSet({
      ...ArchiveFloorDS(),
      events: {
        submit: ({ dataSet }) => {
          dataSet.forEach(item => {
            if (item.get('roomNumber')) {
              this.floorsInfo.push({
                code: item.get('locationCode'),
                title: item.get('description')
              });
            }
          });
        }
      }
    });

    this.archiveShelfDS = new DataSet({
      ...ArchiveShelfDS()
    });
    this.stepList = [];
    this.props.callback('storage', this.archiveStorageDS);
    this.props.callback('floor', this.archiveFloorDS);
    this.props.callback('room', this.archiveRoomDS);
    this.props.callback('shelf', this.archiveShelfDS);

    if (this.props.treeNode && this.props.treeNode.roomCode) {
      // this.floorsInfo = [];
      /**
       * 判断是否是创建平级/ 子集 进来的
       */
      const {
        roomCode = null,
        locationType = null,
        parentLocationCode = null,
        locationCode = null,
        locationInfo = ''
      } = this.props.treeNode;
      if (roomCode) {
        // 判断当前是处于第几步
        if (locationType === 'FLOOR') {
          this.archiveFloorDS.setQueryParameter('roomCode', roomCode);
          // this.archiveFloorDS.data = [currentData];
          this.archiveStorageDS.setQueryParameter('roomCode', roomCode);
          this.archiveStorageDS.query();
          if (this.props.currentStep === 2) {
            this.isEditCreate = 'ROOM';
            let title = '';
            if (locationInfo) {
              const desc1 = locationInfo.indexOf('\\');
              title = locationInfo.slice(desc1 + 1);
            }
            this.floorsInfo.push({ code: locationCode, title });
            this.archiveFloorDS.query();
            let codeIndex = 1;
            this.handleQueryMaxSeq({
              locationType: 'ROOM',
              roomCode,
              parentLocationCode: locationCode
            }).then((res: any) => {
              codeIndex = res < 10 ? `0${res}` : res;
              const code = `${locationCode}${codeIndex}`;
              this.archiveRoomDS.create(
                {
                  roomCode,
                  parentLocationCode: locationCode,
                  description: '档案室',
                  currentParts: 'room',
                  locationType: 'ROOM',
                  locationCode: code
                },
                0
              );
            });
          } else {
            this.isEditCreate = 'FLOOR';
            let fIndex = 1;
            this.handleQueryMaxSeq({
              locationType: 'FLOOR',
              parentLocationCode,
              roomCode
            }).then((res: any) => {
              fIndex = res;
              // 查询最大的序号
              this.archiveFloorDS.create({
                roomCode,
                parentLocationCode: roomCode,
                locationType,
                locationCode: `${parentLocationCode}-${fIndex}`
              });
            });
          }
        } else if (locationType === 'ROOM') {
          this.isEditCreate = 'ROOM';
          let title = '';
          if (locationInfo) {
            const desc1 = locationInfo.indexOf('\\');
            const subStr1 = locationInfo.slice(desc1 + 1);
            const desc2 = subStr1.indexOf('\\');
            title = subStr1.slice(0, desc2);
          }
          // this.archiveFloorDS.data = [currentData];
          // 档案室创建平级
          if (this.props.currentStep === 2) {
            this.archiveStorageDS.setQueryParameter('roomCode', roomCode);
            this.archiveStorageDS.query();
            this.archiveFloorDS.setQueryParameter('roomCode', roomCode);
            this.archiveFloorDS.query().then(floorData => {
              floorData.forEach(fl => {
                if (fl.locationCode === parentLocationCode) {
                  this.archiveFloorDS.data = [fl];
                }
              });
            });
            this.floorsInfo.push({ code: parentLocationCode, title });
            let codeIndex = 1;
            this.handleQueryMaxSeq({
              locationType: 'ROOM',
              parentLocationCode,
              roomCode
            }).then((res: any) => {
              codeIndex = res < 10 ? `0${res}` : res;
              const code = `${parentLocationCode}${codeIndex}`;
              this.archiveRoomDS.create(
                {
                  roomCode,
                  parentLocationCode,
                  locationType,
                  description: '档案室',
                  locationCode: code,
                  currentParts: 'room'
                },
                0
              );
            });
          }
        } else if (!locationType) {
          // 创建子集
          if (this.props.currentStep === 1) {
            this.isEditCreate = 'FLOOR';
            let fIndex = 1;
            this.handleQueryMaxSeq({
              locationType: 'FLOOR',
              parentLocationCode: roomCode,
              roomCode
            }).then((res: any) => {
              fIndex = res;
              this.archiveFloorDS.create(
                {
                  roomCode,
                  parentLocationCode: roomCode,
                  locationType: 'FLOOR',
                  locationCode: `${roomCode}-${fIndex}`,
                  description: `${fIndex}${intl.get('hfsecm.archive.room.floor')}`
                },
                0
              );
            });
            this.archiveStorageDS.setQueryParameter('roomCode', roomCode);
            this.archiveStorageDS.query();
          } else {
            this.isEditCreate = '';
          }
        }
      }

      // // 楼栋和楼层信息 不可变更
      // this.stepList = [
      //   {
      //     title: intl.get('hfsecm.archive.room.storageSetting').d('库房设置'),
      //     content: (
      //       <Storage
      //         dataSet={this.archiveStorageDS}
      //         floor={this.archiveFloorDS}
      //         isEditCreate={this.isEditCreate}
      //       />
      //     )
      //   },
      //   {
      //     title: intl.get('hfsecm.archive.room.floorSetting').d('楼层设置'),
      //     content: <Floor dataSet={this.archiveFloorDS} />
      //   },
      //   {
      //     title: intl.get('hfsecm.archive.room.roomSetting').d('档案室设置'),
      //     content: (
      //       <Room
      //         dataSet={this.archiveRoomDS}
      //         floorInfo={this.floorsInfo}
      //         isDisabled={false}
      //         editAppendage={null}
      //       />
      //     )
      //   },
      //   {
      //     title: intl.get('hfsecm.archive.room.shelfSetting').d('档案架设置'),
      //     content: (
      //       <Shelf
      //         dataSet={this.archiveShelfDS}
      //         roomDS={this.archiveRoomDS}
      //         isEditCreate={this.isEditCreate}
      //       />
      //     )
      //   },
      //   {
      //     title: intl.get('hfsecm.archive.room.roomPreview').d('库房预览'),
      //     content: '555'
      //   }
      // ];
    } else {
      // this.archiveStorageDS.create({}, 0)
      this.isEditCreate = '';
    }
    // 楼栋和楼层信息 不可变更
    this.stepList = [
      {
        title: intl.get('hfsecm.archive.room.storageSetting').d('库房设置'),
        content: (
          <Storage
            dataSet={this.archiveStorageDS}
            floor={this.archiveFloorDS}
            isEditCreate={this.isEditCreate}
          />
        )
      },
      {
        title: intl.get('hfsecm.archive.room.floorSetting').d('楼层设置'),
        content: <Floor dataSet={this.archiveFloorDS} />
      },
      {
        title: intl.get('hfsecm.archive.room.roomSetting').d('档案室设置'),
        content: (
          <Room
            dataSet={this.archiveRoomDS}
            floorInfo={this.floorsInfo}
            isDisabled={false}
            editAppendage={null}
            isEditCreate={this.isEditCreate}
          />
        )
      },
      {
        title: intl.get('hfsecm.archive.room.shelfSetting').d('档案架设置'),
        content: (
          <Shelf
            dataSet={this.archiveShelfDS}
            roomDS={this.archiveRoomDS}
            isEditCreate={this.isEditCreate}
          />
        )
      },
      {
        title: intl.get('hfsecm.archive.room.roomPreview').d('库房预览'),
        content: '555'
      }
    ];
  }

  async componentDidMount() {}

  /**
   * 查询最大的序号 /archive/location/sequence
   * @returns
   */
  handleQueryMaxSeq = params => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/sequence`,
      {
        method: 'GET',
        params
      }
    );
  };

  render() {
    return (
      <>
        {this.stepList && (
          <>
            <Steps current={this.props.currentStep} type="navigation">
              {this.stepList.map(item => (
                <Step key={item.title} title={item.title} />
              ))}
            </Steps>
            <div className="steps-content">{this.stepList[this.props.currentStep]?.content}</div>
          </>
        )}
      </>
    );
  }
}

// DS
let storageDS;
let floorDS;
let roomDS;
let shelfDS;

// 回调
function callback(type, DS) {
  if (type === 'storage') {
    storageDS = DS;
  } else if (type === 'floor') {
    floorDS = DS;
  } else if (type === 'room') {
    roomDS = DS;
  } else if (type === 'shelf') {
    shelfDS = DS;
  }
}

export default function openDetailModal(
  currentStep,
  title,
  treeNode: any = {
    desciption: null,
    roomCode: null,
    locationType: null,
    locationCode: null,
    parentLocationCode: null,
    childLocations: [],
    locationInfo: '',
    parentNode: []
  },
  closeOperate: () => void
) {
  const floorInfo: any = [];
  const modal = Modal.open({
    key: modalKey,
    drawer: true,
    title,
    style: { width: 800 },
    closable: true,
    children: <CreateRooms currentStep={currentStep} treeNode={treeNode} callback={callback} />,
    footer: (okBtn, cancelBtn) => {
      return (
        <div>
          {currentStep < 1 ? (
            cancelBtn
          ) : (
            <Button onClick={() => jumpLastStep(modal)}>
              {intl.get('hfsecm.archive.room.lastStep').d('上一步')}
            </Button>
          )}
          {okBtn}
        </div>
      );
    },
    okText: intl.get('hfsecm.archive.room.nextStepss').d('下一步'),
    onOk: async () => {
      let flag = false;
      if (currentStep < 4) {
        if (currentStep < 1 && (await storageDS.current?.validate())) {
          storageDS.submit().then(async res => {
            if (!(res && res.failed)) {
              const { floorNumber = 0, roomCode, floorHeight } = storageDS.current?.toData();
              if (res && res.content && res.content.length > 0) {
                storageDS.current?.set({ ...res.content[0] });
                storageDS.current?.set('_status', 'sync');
              }
              if (floorDS.length < 1) {
                for (let i = 0, j = floorNumber; i < j; i++) {
                  floorDS.create(
                    {
                      locationType: 'FLOOR',
                      parentLocationCode: roomCode,
                      height: floorHeight,
                      roomCode,
                      locationCode: `${roomCode}-${floorNumber - i}`,
                      description: `${floorNumber - i}${intl.get('hfsecm.archive.room.floor')}`
                    },
                    0
                  );
                }
              }
              currentStep++;
              modal.update({
                children: (
                  <CreateRooms treeNode={treeNode} currentStep={currentStep} callback={callback} />
                )
              });
            }
          });
        } else if (currentStep === 1 && (await floorDS.validate())) {
          floorDS.submit().then(res => {
            if (!(res && res.failed)) {
              currentStep++;
              if (res && res.content && res.content.length > 0) {
                // 保存后,数据需要切换成最新的数据,需要变更每一条数据的状态
                res.content.forEach(item => {
                  item._status = 'update';
                });
                floorDS.data = res.content;
              }
              if (roomDS.length < 1) {
                floorDS.forEach(item => {
                  if (item.get('roomNumber')) {
                    floorInfo.push({
                      title: item.get('description'),
                      code: item.get('locationCode')
                    });
                    const count = item.get('roomNumber');
                    for (let i = 0, j = count; i < j; i++) {
                      const indexNum = j - i > 10 ? j - i : `0${j - i}`;
                      roomDS.create(
                        {
                          currentParts: 'room',
                          locationType: 'ROOM',
                          parentLocationCode: item.get('locationCode'),
                          roomCode: item.get('roomCode'),
                          locationCode: `${item.get('locationCode')}${indexNum}`,
                          description: `档案室`,
                          height: item.get('height')
                        },
                        0
                      );
                    }
                  }
                });
              }
              modal.update({
                children: (
                  <CreateRooms currentStep={currentStep} callback={callback} treeNode={treeNode} />
                )
              });
            }
          });
        } else if (currentStep === 2 && (await roomDS.validate())) {
          let flag = true;
          roomDS.forEach(item => {
            const { doors, windows } = item.toData();
            if (doors && doors.length > 0) {
              for (let i = 0, j = doors.length; i < j; i++) {
                if (!doors[i].appendageId) {
                  flag = false;
                  notification.error({
                    message:
                      intl.get('hfsecm.archive.room.archiveRooms').d('档案室') +
                      item.get('description') +
                      intl
                        .get('hfsecm.archive.room.validateErrorNotNext')
                        .d('信息未保存，无法进行下一步!'),
                    description: null,
                    placement: 'bottomRight'
                  });
                  return false;
                }
              }
            }
            if (windows && windows.length > 0) {
              for (let i = 0, j = windows.length; i < j; i++) {
                if (!windows[i].appendageId) {
                  flag = false;
                  notification.error({
                    message:
                      intl.get('hfsecm.archive.room.archiveRooms').d('档案室') +
                      item.get('description') +
                      intl.get('hfsecm.archive.room.validateError').d('存在未保存的数据, 请保存'),
                    description: null,
                    placement: 'bottomRight'
                  });
                  return false;
                }
              }
            }
          });

          if (flag) {
            currentStep++;
            modal.update({
              children: (
                <CreateRooms currentStep={currentStep} callback={callback} treeNode={treeNode} />
              )
            });
          }
        } else if (currentStep === 2 && !(await roomDS.validate())) {
          notification.error({
            message: intl
              .get('hfsecm.archive.room.validateErrorNotNext')
              .d('信息未保存，无法进行下一步!'),
            description: undefined,
            placement: 'bottomRight'
          });
        } else if (currentStep === 3) {
          currentStep++;
          modal.update({
            okText: intl.get('hfsecm.archive.room.complete').d('完成'),
            children: (
              <CreateRooms currentStep={currentStep} callback={callback} treeNode={treeNode} />
            )
          });
        } else {
          return false;
        }
      } else {
        flag = true;
        modal.close();
      }
      return Promise.resolve(flag);
    },
    afterClose: () => {
      roomDS.reset();
      floorDS.reset();
      storageDS.reset();
      shelfDS.reset();
      currentStep = 0;
      closeOperate();
    }
  });

  /**
   * 跳转到上一步
   * @param modal
   */
  const jumpLastStep = async modal => {
    // if (currentStep === 3) {
    //   if (isEditType === 'FLOOR') {
    //     roomDS.setQueryParameter(
    //       'locationCode',
    //       roomDS.get(0)?.get('parentLocationCode')
    //     );
    //     roomDS.setQueryParameter('locationType', 'FLOOR');
    //   } else if (isEditType === 'ROOM') {
    //     roomDS.setQueryParameter('locationCode', roomDS.get(0)?.get('locationCode'));
    //     roomDS.setQueryParameter('locationType', 'ROOM');
    //   }
    //   await roomDS.query();
    // }
    currentStep--;
    modal.update({
      okText: intl.get('hfsecm.archive.room.nextStepss').d('下一步'),
      children: <CreateRooms currentStep={currentStep} callback={callback} />
    });
  };
}
