/*
 * @Description: 消息推送历史错误数据回滚弹窗
 * @Author: hualv.jiang <hualv.jiang@hand-china.com>
 * @Date: 2020-11-04 14:35:02
 * @LastEditTime: 2021-11-13 14:28:18
 * @Copyright: Copyright (c) 2020, Hand
 */

import { Alert, Col, Row } from 'choerodon-ui';
import { DataSet, Modal, NumberField } from 'choerodon-ui/pro';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { observable } from 'mobx';
import Icon from '@common/components/Icon';
import React, { Component } from 'react';
import intl from 'utils/intl';

interface appendageProps {
  callback: any;
  text: any;
}

class AssignAppendage extends Component<appendageProps> {
  @observable assignAppendageDS: DataSet;

  constructor(props) {
    super(props);
    this.assignAppendageDS = new DataSet({
      fields: [
        {
          name: 'doorNum',
          type: FieldType.number,
          label: intl.get('hfsecm.archive.room.door').d('门'),
          required: true,
          min: 0
        },
        {
          name: 'winNum',
          type: FieldType.number,
          label: intl.get('hfsecm.archive.room.window').d('窗'),
          required: true,
          min: 0
        }
      ]
    });
    this.assignAppendageDS.create({}, 0);
    this.props.callback(this.assignAppendageDS);
  }

  renderTitle = () => {
    return (
      <p className="ecm-room-assign-modal-title">
        {intl.get('hfsecm.archive.room.assignTips').d('当前分配对象为')}
        <span>{this.props.text}</span>
      </p>
    );
  };

  render() {
    return (
      <>
        <Alert message={this.renderTitle()} />
        <Row className="ecm-room-row">
          <Col span={6}>
            <div className="ecm-room-assign-doorBtn">
              {/* <img src={doorImg} alt="" /> */}
              <Icon type="a-men" />
              {intl.get('hfsecm.archive.room.door').d('门')}
            </div>
          </Col>
          <Col span={6}>
            <p className="ecm-room-assign-label">
              {intl.get('hfsecm.archive.room.assignNum').d('分配数量')}:
            </p>
          </Col>
          <Col span={12}>
            <NumberField
              name="doorNum"
              dataSet={assignAppendageDS}
              className="ecm-room-part-form-item"
            />
          </Col>
        </Row>
        <Row className="ecm-room-row">
          <Col span={6}>
            <div className="ecm-room-assign-winBtn">
              {/* <img src={winsImg} alt="" /> */}
              <Icon type="a-chuang" />
              {intl.get('hfsecm.archive.room.window').d('窗')}
            </div>
          </Col>
          <Col span={6}>
            <p className="ecm-room-assign-label">
              {intl.get('hfsecm.archive.room.assignNum').d('分配数量')}:
            </p>
          </Col>
          <Col span={12}>
            <NumberField
              name="winNum"
              dataSet={assignAppendageDS}
              className="ecm-room-part-form-item"
            />
          </Col>
        </Row>
      </>
    );
  }
}

// DS
let assignAppendageDS;

// 回调
function callback(DS) {
  assignAppendageDS = DS;
}

export default function openAssignAppendageModal(text, floors, handleOk) {
  const modal = Modal.open({
    title: intl.get('hfsecm.archive.room.assignRoomParts').d('分配室内配件'),
    closable: true,
    className: 'ecm-room-assign-modal',
    children: <AssignAppendage callback={callback} text={text} />,
    onOk: () => {
      modal.close();
      handleOk(assignAppendageDS, floors);
    }
    // onOk: () => {
    //   modal.close();
    //
    // }
  });
}
