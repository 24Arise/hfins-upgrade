/**
 * @Description: 档案库房设置
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/4/15 9:30
 * @LastEditTime: 2021/4/15 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldIgnore, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/room/by-code`,
      method: 'GET'
    }),
    submit: ({ data, params }): AxiosRequestConfig => {
      return {
        data,
        params,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/room`,
        method: 'POST'
      };
    }
  },
  primaryKey: 'roomId',
  autoQuery: false,
  fields: [
    {
      name: 'description',
      label: intl.get('hfsecm.archive.room.roomName'),
      type: FieldType.intl,
      required: true
    },
    {
      name: 'roomCode',
      label: intl.get('hfsecm.archive.room.roomCode'),
      type: FieldType.string,
      required: true,
      format: FieldFormat.uppercase
    },
    {
      name: 'roomLocation',
      label: intl.get('hfsecm.archive.room.roomLocation'),
      type: FieldType.string
    },
    {
      name: 'destructorObj',
      label: intl.get('hfsecm.archive.room.supervisor'),
      type: FieldType.object,
      lovCode: 'HFSECM.EMPLOYEE',
      ignore: FieldIgnore.always,
      valueField: 'employeeCode',
      textField: 'employeeName'
    },
    {
      name: 'employeeCode',
      label: intl.get('hfsecm.archive.room.supervisor'),
      type: FieldType.string,
      bind: 'destructorObj.employeeCode'
    },
    {
      name: 'destructorName',
      type: FieldType.string,
      bind: 'destructorObj.employeeName'
    },
    {
      name: 'length',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.length').d('长'),
      required: true
    },
    {
      name: 'width',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.width').d('宽'),
      required: true
    },
    {
      name: 'floorNumber',
      type: FieldType.number,
      required: true
    },
    {
      name: 'floorHeight',
      type: FieldType.number,
      required: true
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      defaultValue: true,
      label: intl.get('hfsecm.common.enabledFlag'),
      trueValue: true,
      falseValue: false
    }
  ]
});
