/**
 * @Description: 档案库房设置
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2021/4/15 9:30
 * @LastEditTime: 2021/4/15 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  autoQueryAfterSubmit: true,
  transport: {
    submit: ({ data, params }): AxiosRequestConfig => {
      return {
        data: data[0],
        params,
        url: `${
          commonConfig.ECM_API
        }/v1/${getCurrentOrganizationId()}/archive-locations/auto-create`,
        method: 'POST'
      };
    }
  },
  primaryKey: 'locationId',
  autoCreate: true,
  autoQuery: false,
  fields: [
    {
      name: 'areaId',
      type: FieldType.string,
      required: true
    },
    {
      name: 'parentLocationId',
      type: FieldType.string
    },
    {
      name: 'locationName',
      label: intl.get('hfsecm.archive.room.locationName'),
      type: FieldType.string,
      required: true
    },
    {
      name: 'areaCode',
      label: intl.get('hfsecm.archive.room.areaCode'),
      type: FieldType.string,
      format: FieldFormat.uppercase
    },
    {
      name: 'locationCode',
      label: intl.get('hfsecm.archive.room.locationCode'),
      type: FieldType.string,
      format: FieldFormat.uppercase
    },
    {
      name: 'locationNumber',
      label: intl.get('hfsecm.archive.room.locationNumber'),
      type: FieldType.number,
      required: true
    }
  ]
});
