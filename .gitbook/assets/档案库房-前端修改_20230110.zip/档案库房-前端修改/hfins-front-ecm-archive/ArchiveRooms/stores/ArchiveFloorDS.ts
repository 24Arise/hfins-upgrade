/**
 * @Description: 档案楼层设置
 * @Author: 向芳 <fang.xiang01@hand-china.com>
 * @Date: 2022/12/27 9:30
 * @LastEditTime: 2022/12/28 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  primaryKey: 'roomId',
  autoQuery: false,
  paging: false,
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/floor`,
      method: 'GET'
    }),
    submit: ({ data, params }): AxiosRequestConfig => {
      return {
        data,
        params,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location`,
        method: 'POST'
      };
    }
  },
  fields: [
    {
      name: 'locationType',
      type: FieldType.string
    },
    {
      name: 'description',
      label: intl.get('hfsecm.archive.room.floorName').d('楼层名称'),
      type: FieldType.intl,
      required: true
    },
    {
      name: 'roomCode',
      label: intl.get('hfsecm.archive.room.roomCode'),
      type: FieldType.string,
      required: true,
      format: FieldFormat.uppercase
    },
    {
      name: 'parentLocationCode',
      label: intl.get('hfsecm.archive.room.roomCode'),
      type: FieldType.string,
      required: true,
      format: FieldFormat.uppercase
    },
    {
      name: 'locationCode',
      label: intl.get('hfsecm.archive.room.floorCode').d('楼层代码'),
      type: FieldType.string,
      required: true,
      format: FieldFormat.uppercase
    },
    {
      name: 'height',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.floorHeight').d('层高(m)'),
      required: true
    },
    {
      name: 'roomNumber',
      type: FieldType.number,
      required: true,
      min: 0
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      defaultValue: true,
      label: intl.get('hfsecm.common.enabledFlag'),
      trueValue: true,
      falseValue: false
    }
  ]
});
