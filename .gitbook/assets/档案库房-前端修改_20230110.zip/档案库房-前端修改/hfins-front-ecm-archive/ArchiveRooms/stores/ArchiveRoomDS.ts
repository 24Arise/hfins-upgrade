/**
 * @Description: 档案库房设置
 * @Author: 向芳 <fang.xiang01@hand-china.com>
 * @Date: 2022/4/15 9:30
 * @LastEditTime: 2021/4/15 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  paging: false,
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/room`,
      method: 'GET'
    }),
    submit: ({ data, params }): AxiosRequestConfig => {
      return {
        data: [data],
        params,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location`,
        method: 'POST'
      };
    }
  },
  primaryKey: 'roomId',
  autoQuery: false,
  fields: [
    {
      name: 'locationType',
      type: FieldType.string
    },
    {
      name: 'description',
      label: intl.get('hfsecm.archive.room.roomsName').d('档案室名称'),
      type: FieldType.intl,
      required: true
    },
    {
      name: 'roomCode',
      label: intl.get('hfsecm.archive.room.roomCode'),
      type: FieldType.string,
      required: true,
      format: FieldFormat.uppercase
    },
    {
      name: 'locationCode',
      label: intl.get('hfsecm.archive.room.roomsCode').d('档案室代码'),
      type: FieldType.string,
      required: true,
      format: FieldFormat.uppercase
    },
    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      defaultValue: true,
      label: intl.get('hfsecm.common.enabledFlag'),
      trueValue: true,
      falseValue: false
    },
    {
      name: 'roomComplete',
      type: FieldType.boolean,
      defaultValue: false
    },
    {
      name: 'x1',
      type: FieldType.number,
      required: true
    },
    {
      name: 'x2',
      type: FieldType.number,
      required: true
    },
    {
      name: 'x3',
      type: FieldType.number,
      required: true
    },
    {
      name: 'x4',
      type: FieldType.number,
      required: true
    },
    {
      name: 'y1',
      type: FieldType.number,
      required: true
    },
    {
      name: 'y2',
      type: FieldType.number,
      required: true
    },
    {
      name: 'y3',
      type: FieldType.number,
      required: true
    },
    {
      name: 'y4',
      type: FieldType.number,
      required: true
    }
  ]
});
