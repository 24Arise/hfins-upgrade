import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

/**
 * 主查询
 */
export default (): DataSetProps => ({
  transport: {
    read: config => ({
      ...config,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/room/main`,
      method: 'GET'
    })
  },
  paging: false,
  autoQuery: true,
  queryFields: [
    {
      name: 'roomCode',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.roomCode').d('库房代码')
    },
    {
      name: 'description',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.roomName').d('库房名称')
    },
    {
      name: 'enabledFlag',
      type: FieldType.string,
      label: intl.get('hfsecm.archive.room.enabledFlag').d('是否启用')
    }
  ]
});
