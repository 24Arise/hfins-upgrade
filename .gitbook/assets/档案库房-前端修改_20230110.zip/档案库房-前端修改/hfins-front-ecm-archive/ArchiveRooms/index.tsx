import './index.modules.less';
import { API_HOST } from 'utils/config';
import {
  ArchiveFloorDS,
  ArchiveRoomDS,
  ArchiveRoomTreeDS,
  ArchiveShelfDS,
  ArchiveStorageDS
} from './stores';
import { Button, DataSet, Skeleton } from 'choerodon-ui/pro/lib';
import { ButtonColor } from 'choerodon-ui/pro/lib/button/enum';
import { Content, Header } from 'components/Page';
import { doExport } from '@common/utils/downloadFile';
import { formatterCollections } from 'utils/intl/formatterCollections';
import { getAccessToken, getCurrentOrganizationId } from 'utils/utils';
import { observable } from 'mobx';
import { observer } from 'mobx-react';
import ArchiveRoomsDetail from './components/ArchiveRoomsDetail';
import CreateRooms from './components/ArchiveRoomModal/create';
import EmptyIcon from '@common/assets/no-data.svg';
import Icon from '@common/components/Icon';
import React, { Component } from 'react';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';
import openDetailModal from './components/commonModal/detailModal';
import openImportConfigModal from '@common/utils/ImportConfigModal';

@observer
class ArchiveStorage extends Component {
  @observable list: any = [];

  @observable currentStep = 0;

  archiveRoomTreeDS: DataSet = new DataSet({
    ...ArchiveRoomTreeDS()
  });

  archiveRoomDS: DataSet;

  archiveFloorDS: DataSet;

  archiveStorageDS: DataSet;

  archiveShelfDS: DataSet;

  constructor(props) {
    super(props);
    this.archiveStorageDS = new DataSet({
      ...ArchiveStorageDS()
    });
    this.archiveRoomDS = new DataSet({
      ...ArchiveRoomDS()
    });
    this.archiveFloorDS = new DataSet({
      ...ArchiveFloorDS()
    });

    this.archiveShelfDS = new DataSet({
      ...ArchiveShelfDS()
    });
  }

  handleCreateRooms = () => {
    openDetailModal(0, intl.get('hfsecm.archive.room.createRooms').d('新建库房'), {}, () => {});
    // openInvoiceDetail({});
  };

  handleOk = () => {};

  /**
   * 跳转到上一步
   * @param modal
   */
  jumpLastStep = modal => {
    this.currentStep--;
    modal.update({
      children: (
        <CreateRooms
          storageDS={this.archiveStorageDS}
          floorDS={this.archiveFloorDS}
          roomDS={this.archiveRoomDS}
          shelfDS={this.archiveShelfDS}
          floorInfo={[]}
          currentStep={this.currentStep}
        />
      )
    });
  };

  handleExport = () => {
    doExport(
      `${API_HOST}${
        commonConfig.ECM_API
      }/v1/${getCurrentOrganizationId()}/archive/room/json/export?access_token=${getAccessToken()}`
    );
  };

  handleOpenModal = () => {
    const params = {
      name: 'file',
      action: `${API_HOST}${
        commonConfig.ECM_API
      }/v1/${getCurrentOrganizationId()}/archive/room/json/import?access_token=${getAccessToken()}`,
      accept: ['.json'],
      extra: <p style={{ margin: '8px' }}>请上传JSON配置文件(.json)</p>
    };
    openImportConfigModal(params);
  };

  render() {
    return (
      <>
        <Header>
          <Button color={ButtonColor.primary} onClick={this.handleCreateRooms} icon="add">
            {intl.get('hfsecm.archive.room.createRooms').d('新建库房')}
          </Button>
          <Button onClick={() => this.handleOpenModal()}>
            <Icon type="sample" size={14} style={{ marginRight: 4 }} />
            {intl.get('hfsecm.common.import').d('导入')}
          </Button>
          <Button onClick={() => this.handleExport()}>
            <Icon type="download1" size={14} style={{ marginRight: 4 }} />
            {intl.get('hfsecm.common.export').d('导出')}
          </Button>
        </Header>
        <Content>
          <Skeleton dataSet={this.archiveRoomTreeDS} active paragraph={{ rows: 4 }}>
            {!this.archiveRoomTreeDS.records.length ? (
              <div className="ecm-rooms">
                <img alt="" className="ecm-room-empty-img" src={EmptyIcon} />
                <div className="ecm-room-empty-help">
                  <p className="ecm-room-empty-help-tips">
                    {intl.get('hfsecm.archive.room.empty').d('暂无档案库房信息哦~')}
                  </p>
                  <Button color={ButtonColor.primary} onClick={this.handleCreateRooms} icon="add">
                    {intl.get('hfsecm.archive.room.create').d('点我新建吧')}
                  </Button>
                </div>
              </div>
            ) : (
              <ArchiveRoomsDetail
                archiveStorageDS={this.archiveStorageDS}
                archiveRoomDS={this.archiveRoomDS}
                archiveFloorDS={this.archiveFloorDS}
                archiveShelfDS={this.archiveShelfDS}
                assignAppendageDS={new DataSet()}
              />
            )}
          </Skeleton>
        </Content>
      </>
    );
  }
}

export default formatterCollections({
  code: ['hfsecm.common', 'hfsecm.archive.room']
})(ArchiveStorage);
