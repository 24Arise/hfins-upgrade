import { Button, DataSet, Modal, notification } from 'choerodon-ui/pro';
import { DataSetStatus } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import CheckConfigListDS from './stores/CheckConfigListDS';
import DraggableIcon from '@/assets/images/draggable-icon.png';
import Failed from '@/assets/images/failed.png';
import FailedList from './components/FailedList';
import HecUtil from '@/utils/HecUtil';
import Manuel from '@/assets/images/manuel.png';
import ManuelList from './components/ManuelList';
import PassIcon from '@/assets/images/pass.png';
import PassList from './components/PassList';
import React, { FC, ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import commonConfig from '@/config/commonConfig';
import intl from 'utils/intl';
import request from '@/utils/request';

import './index.less';
// import { RouteComponentProps } from 'react-router';

interface CheckConfigDraggableIconProps {
  headerStore?: any;
  operation?: ReactNode;
}

const CheckConfigDraggableIcon: FC<CheckConfigDraggableIconProps> = ({
  headerStore,
  operation
}) => {
  const { headerDS, docCategory, headerId, readOnly, docNumber } = headerStore;
  const [translateX, setTranslateX] = useState(document.documentElement.clientWidth - 80);
  const [translateY, setTranslateY] = useState(document.documentElement.clientHeight - 160);
  const [expand, setExpand] = useState(false);
  const [divX, setDivX] = useState(0);
  const [divY, setDivY] = useState(0);
  const [passResultLists, setPassResultList] = useState<any[]>([]);
  const [failResultLists, setFailResultList] = useState<any[]>([]);
  const [auditNum, setAuditNum] = useState(0);
  const [idsAuditPassNum, setIdsAuditPassNum] = useState(0);
  const [idsAuditFailNum, setIdsAuditFailNum] = useState(0);
  const [manualAuditNum, setManualAuditNum] = useState(0);
  const checkConfigHidden = !['S', 'P', 'A'].includes(headerDS.current?.get('idsBillCheckStatus'));
  const [taskId, setTaskId] = useState('');
  const [scenarioId, setScenarioId] = useState('');
  const disabled = readOnly && !operation;

  let manualModal: any;
  let passModal: any;
  let failModal: any;

  const CheckConfigListDataSet = useMemo(
    () =>
      new DataSet({
        ...CheckConfigListDS(),
        events: {
          submitSuccess: () => handleQuery(),
          load: ({ dataSet }) => {
            dataSet.forEach(item => {
              item.init(
                'showMessage',
                item.get('checkMethod') === 'AUTO' ? item.get('note') : item.get('pointMessage')
              );
            });
          }
        }
      }),
    []
  );

  useEffect(() => {
    if (!checkConfigHidden) {
      handleQuery();
    } else {
      manualModal?.close();
      passModal?.close();
      failModal?.close();
    }
  }, [checkConfigHidden]);

  useCallback(() => {}, [Modal]);

  const handleQuery = () => {
    CheckConfigListDataSet.status = DataSetStatus.loading;
    request(`${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-result`, {
      method: 'GET',
      params: {
        docCategory,
        docId: headerId,
        sourceSystem: 'HFINS'
      }
    }).then((res: any) => {
      if (res) {
        const {
          taskId,
          scenarioId,
          auditCount,
          idsAuditPassCount,
          idsAuditFailCount,
          manualAuditCount,
          passResultList,
          failResultList,
          manualResultList
        } = res;
        if (auditCount === null) setAuditNum(0);
        if (idsAuditPassCount === null) setIdsAuditPassNum(0);
        if (idsAuditFailCount === null) setIdsAuditFailNum(0);
        if (manualAuditCount === null) setManualAuditNum(0);
        setTaskId(taskId);
        setScenarioId(scenarioId);
        setAuditNum(auditCount || 0);
        setIdsAuditPassNum(idsAuditPassCount || 0);
        setIdsAuditFailNum(idsAuditFailCount || 0);
        setManualAuditNum(manualAuditCount || 0);
        if (manualResultList) {
          CheckConfigListDataSet.loadData(manualResultList);
          CheckConfigListDataSet.totalCount = manualAuditCount;
        }
        if (passResultList) {
          setPassResultList(passResultList);
        }
        if (failResultList) {
          setFailResultList(failResultList);
        }
        CheckConfigListDataSet.status = DataSetStatus.ready;
      }
    });
  };

  const handleMouseDown = event => {
    event.preventDefault();
    event.stopPropagation();
    event.persist();
    event.target.style.transform = 'scale(0.8)';
    setDivX(event.clientX);
    setDivY(event.clientY);
    document.addEventListener('mousemove', handleMouseMove);
  };

  const handleMouseMove = useCallback(event => {
    setTranslateX(event.clientX - 25);
    setTranslateY(event.clientY - 25);
  }, []);

  const handleMouseUp = event => {
    event.preventDefault();
    event.stopPropagation();
    event.persist();
    document.removeEventListener('mousemove', handleMouseMove);
    if (event.target !== document.getElementById('check-config')?.children[0]) {
      event.target.children[0].style.transform = 'scale(1)';
    } else {
      event.target.style.transform = 'scale(1)';
    }
    if (divX === event.clientX && divY === event.clientY) {
      document.getElementById('check-config')?.addEventListener('click', handleExpand);
    } else {
      document.getElementById('check-config')?.removeEventListener('click', handleExpand);
    }
  };

  const handleExpand = useCallback(() => {
    setExpand(!expand);
  }, [expand]);

  const renderManualAuditModal = useCallback(() => {
    if (manualAuditNum > 0) {
      // clickLimit('manual');
      if (!manualModal) {
        manualModal = Modal.open({
          title: `${intl.get('hfins.common.manualCheck')} ${manualAuditNum} ${intl.get(
            'hfins.common.item'
          )}`,
          mask: false,
          closable: true,
          style: { width: 1000 },
          contentStyle: { border: '1px solid #FFB700' },
          className: 'checkConfig-draggModal',
          children: (
            <ManuelList CheckConfigListDataSet={CheckConfigListDataSet} readOnly={disabled} />
          ),
          // resizable: true,
          okText: `${intl.get('hfins.common.save')}`,
          onOk: () => handleSaveManual(),
          footer: (okBtn, cancelBtn) => {
            return !disabled ? (
              <div>
                <Button onClick={() => handleBatchPass(manualModal)}>
                  {intl.get('hfins.common.batchPass')}
                </Button>
                <Button onClick={() => handleBatchNotPass(manualModal)}>
                  {intl.get('hfins.common.batchNotPass')}
                </Button>
                {cancelBtn}
                {okBtn}
              </div>
            ) : null;
          },
          afterClose: () => {
            manualModal = null;
          }
        });
      }
    }
  }, [Modal, manualAuditNum]);

  const handleBatchPass = modal => {
    CheckConfigListDataSet.map(item => {
      return item.set('pointResult', 'Y');
    });
    modal.update({
      children: <ManuelList CheckConfigListDataSet={CheckConfigListDataSet} readOnly={disabled} />
    });
  };

  const handleBatchNotPass = modal => {
    CheckConfigListDataSet.map(item => {
      return item.set('pointResult', 'N');
    });
    modal.update({
      children: <ManuelList CheckConfigListDataSet={CheckConfigListDataSet} readOnly={disabled} />
    });
  };

  const handleSaveManual = () => {
    const { employeeCode, employeeName } = HecUtil.getCurrentUserAdditionInfo();
    const data = {
      batchPass: false,
      batchNoPass: false,
      taskId,
      scenarioId,
      remarker: `${employeeCode}-${employeeName}`,
      remarkType: operation ? 'FINANCE' : 'BUSINESS',
      docNumber,
      list: CheckConfigListDataSet.toJSONData()
    };
    request(`${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/task-point-results`, {
      method: 'POST',
      data
    }).then((res: any) => {
      if (res && res.failed) {
        notification.error({
          message: res.message,
          description: null,
          placement: 'bottomRight'
        });
        return Promise.reject();
      }
      handleQuery();
    });
  };

  const renderPassModal = useCallback(() => {
    if (passResultLists.length !== 0 && !passModal) {
      passModal = Modal.open({
        title: `${intl.get('hfins.common.passItem')} ${idsAuditPassNum} ${intl.get(
          'hfins.common.item'
        )}`,
        key: 'pass',
        mask: false,
        closable: true,
        style: { width: 1000 },
        footer: null,
        className: 'checkConfig-draggModal',
        contentStyle: { border: '1px solid #00DCC9' },
        resizable: true,
        children: <PassList passResultList={passResultLists} />,
        afterClose: () => {
          passModal = null;
        }
        // getContainer
      });
    }
  }, [Modal, idsAuditPassNum, passResultLists]);

  const renderFailedModal = useCallback(() => {
    if (failResultLists.length !== 0 && !failModal) {
      failModal = Modal.open({
        title: `${intl.get('hfins.common.failItem')} ${idsAuditFailNum} ${intl.get(
          'hfins.common.item'
        )}`,
        key: 'failed',
        mask: false,
        closable: true,
        style: { width: 1000 },
        className: 'checkConfig-draggModal',
        contentStyle: { border: '1px solid #f96f68' },
        footer: null,
        resizable: true,
        children: <FailedList failResultList={failResultLists} />,
        afterClose: () => {
          failModal = null;
        }
        // getContainer:() => contentContainer
      });
    }
  }, [Modal, failResultLists, idsAuditFailNum]);

  return (
    <div
      hidden={checkConfigHidden}
      className="draggable-check-config"
      style={{ top: `${translateY}px`, left: `${translateX}px` }}
    >
      <div id="check-config" onMouseDown={handleMouseDown} onMouseUp={handleMouseUp}>
        <img className="main-icon" src={DraggableIcon} alt="" />
      </div>
      <div className="check-config-item">
        {intl.get('hfins.common.idsDocCheck').d('小财能单据检查')}&nbsp;
        <span className="num">{auditNum}&nbsp;</span>
        {intl.get('hfins.common.item')}
      </div>

      <div className={expand ? 'pass-item-expand' : 'pass-item'}>
        {expand && (
          <div onClick={renderPassModal}>
            {intl.get('hfins.common.passItem')}&nbsp;
            <span className="num">{idsAuditPassNum}&nbsp;</span>
            {intl.get('hfins.common.item')}
          </div>
        )}
      </div>
      <div className={expand ? 'failed-item-expand' : 'failed-item'}>
        {expand && (
          <div onClick={renderFailedModal}>
            {intl.get('hfins.common.failItem')}&nbsp;
            <span className="num">{idsAuditFailNum}&nbsp;</span>
            {intl.get('hfins.common.item')}
          </div>
        )}
      </div>
      <div className={expand ? 'manual-item-expand' : 'manual-item'}>
        {expand && (
          <div onClick={renderManualAuditModal}>
            {intl.get('hfins.common.manualCheck')}&nbsp;
            <span className="num">{manualAuditNum}&nbsp;</span>
            {intl.get('hfins.common.item')}
          </div>
        )}
      </div>
      <div
        className={expand ? 'draggable-check-config-list-expand' : 'draggable-check-config-list'}
      >
        {expand && (
          <div className="icon" style={{ marginTop: '12px' }} onClick={renderManualAuditModal}>
            {/* <Icon type="artificial" size={20} /> */}
            <img src={Manuel} width={20} alt="" />
          </div>
        )}
        {expand && (
          <div className="icon" onClick={renderFailedModal}>
            {/* <Icon type="pass" size={20} /> */}
            <img src={Failed} width={20} alt="" />
          </div>
        )}
        {expand && (
          <div className="icon" onClick={renderPassModal}>
            {/* <Icon type="pass-the-audit" size={20} /> */}
            <img src={PassIcon} width={20} alt="" />
          </div>
        )}
      </div>
    </div>
  );
};
export default CheckConfigDraggableIcon;
