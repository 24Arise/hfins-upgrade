/**
 * 智能检查单据卡片-人工审核DS
 * @Author: 林郁舜<yushun.lin@hand-china.com>
 * @Date: 2022/3/23 19:00
 * @LastEditTime: 2022/3/23 19:05
 * @Copyright: Copyright (c) 2022, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldType, SortOrder } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => {
  return {
    selection: false,
    transport: {
      submit: ({ data }): AxiosRequestConfig => {
        return {
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/task-point-results`,
          method: 'POST',
          data
        };
      }
    },
    paging: false,
    // pageSize: 10,
    primaryKey: 'pointResultId',
    fields: [
      {
        name: 'pointResult',
        label: intl.get('hfins.common.checkResult'),
        type: FieldType.string,
        lookupCode: 'HFINS.IDS.CHECK.RESULT',
        order: SortOrder.asc
      },
      {
        name: 'pointMessage',
        label: intl.get('hfins.common.checkPoint'),
        type: FieldType.string
      },
      {
        name: 'planName',
        label: intl.get('hfins.common.checkPoint'),
        type: FieldType.string
      },
      {
        name: 'priorityName',
        label: intl.get('hfins.common.priority'),
        type: FieldType.string
      },
      {
        name: 'checkMethodName',
        label: intl.get('hfins.common.pointType'),
        type: FieldType.string
      },
      {
        name: 'note',
        // label: intl.get('hfins.common.notes'),
        type: FieldType.string
      },
      {
        name: 'remark',
        label: intl.get('hfins.common.notes'),
        type: FieldType.string
      },
      {
        name: 'showMessage',
        label: intl.get('hfins.common.checkPoint'),
        type: FieldType.string
      }
    ]
  };
};

export const notThroughStatisticsDS = (): DataSetProps => ({
  transport: {
    submit: ({ data }): AxiosRequestConfig => {
      return {
        url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/task-point-results`,
        method: 'POST',
        data
      };
    }
  },
  fields: [
    {
      name: 'pointResult',
      label: intl.get('hfins.common.checkResult'),
      type: FieldType.string
    },
    {
      name: 'planName',
      label: intl.get('hfins.common.checkPoint'),
      type: FieldType.string
    },
    {
      name: 'priorityName',
      label: intl.get('hfins.common.priority'),
      type: FieldType.string
    },
    {
      name: 'checkMethodName',
      label: intl.get('hfins.common.pointType'),
      type: FieldType.string
    },
    {
      name: 'note',
      label: intl.get('hfins.common.notes'),
      type: FieldType.string
    }
  ]
});
