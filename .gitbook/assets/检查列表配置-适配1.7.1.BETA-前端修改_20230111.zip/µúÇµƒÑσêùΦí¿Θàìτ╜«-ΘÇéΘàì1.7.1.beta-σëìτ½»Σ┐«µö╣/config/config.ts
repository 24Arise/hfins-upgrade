import { extendParentConfig } from '@hzerojs/plugin-micro';

const { winPath } = require('@umijs/utils');
const path = require('path');

const getComponentPath = (packages, comp) => {
  // 需要获取对应的相对路径
  const to = path.join(winPath(require.resolve(`${packages}/package.json`, { paths: [process.cwd()] })).replace('/package.json', ''), `lib/${comp}`);
  const form = path.join(__filename, '../../src');
  const p = winPath(path.relative(form, to));
  return `@/${p}`;
};

export default extendParentConfig({
  webpack5: {},
  devServer: {
    // port: 8887               //为了微前端本地启动，和主模块microService配置的端口对应
  },
  // 是否启用按需加载
  dynamicImport: {
    loading: '@hzerojs/plugin-layout/browsers/components/PageLoading'
  },
  routes: [
    // Insert New Router
    {
      path: '/ids/check-scene',
      component: '@/pages/CheckScene'
    },
    {
      path: '/ids/check-point',
      component: '@/pages/CheckPointConfig'
    },
    {
      path: '/ids/check-plan',
      component: '@/pages/CheckPlanConfig'
    },
    {
      path: '/ids/check-formula',
      component: '@/pages/CheckFormula'
    },
    {
      path: '/ids/check-record',
      component: '@/pages/CheckRecord'
    },
    {
      path: '/ids/check-list',
      component: '@/pages/CheckListConfig'
    },
    // 检查列表导入
    {
      path: '/ids/check-list/import-data/:code',
      component: getComponentPath('hzero-front-himp', 'routes/CommentImport')
    }
  ],
  extraBabelPlugins: [
    // 原/packages/xxx/.babelrc.js--plugins
    [
      'module-resolver',
      {
        root: ['./'],
        alias: {
          '@': './src'
        }
      }
    ]
  ],

  presets: [
    // require.resolve('@hzerojs/preset-hzero'),根目录下已经配置过了
  ],
  hzeroMicro: {
    microConfig: {
      // "registerRegex": "(\\/aps)|(\\/orderPerfomace)|(\\/pub/aps)"
      // 原先在.hzerorc.json使用的是"initLoad": true,现在使用的模块加载规则：当匹配到对应的路由后，才加载对应的模块。
      // 主模块下microServices下registerRegex优先级最高
    }
  }
});
