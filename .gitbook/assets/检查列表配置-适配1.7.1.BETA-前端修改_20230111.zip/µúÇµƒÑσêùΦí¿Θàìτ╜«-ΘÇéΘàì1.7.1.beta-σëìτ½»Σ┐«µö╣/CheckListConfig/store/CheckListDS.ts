/**
 * CheckScene - 检查场景配置ds
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2022/3/3 15:04
 * @LastEditTime: 2022/3/3 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => {
  return {
    transport: {
      read: (config): AxiosRequestConfig => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list`,
          method: 'GET'
        };
      },
      submit: ({ data }): AxiosRequestConfig => {
        return {
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list`,
          method: 'POST',
          data
        };
      }
    },
    paging: false,
    fields: [
      {
        name: 'listId',
        type: FieldType.string
      },
      {
        name: 'listCode',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.listCode'),
        required: true
      },
      {
        name: 'description',
        type: FieldType.intl,
        label: intl.get('hfsids.checkListConfig.listName'),
        required: true
      },
      // 启动标志
      {
        name: 'enabledFlag',
        lookupCode: 'HFSIDS.ENABLED_FLAG',
        type: FieldType.boolean,
        label: intl.get('hfsids.checkListConfig.enabledFlag'),
        defaultValue: false,
        required: true
      }
    ],
    autoQuery: false,
    queryFields: [
      {
        name: 'keyword',
        type: FieldType.string
      },
      {
        name: 'listCode',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.listCode')
      },
      {
        name: 'description',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.listName')
      },
      // 启动标志
      {
        name: 'enabledFlag',
        type: FieldType.boolean,
        label: intl.get('hfsids.checkListConfig.enabledFlag')
      }
    ]
  };
};
