/**
 * CheckSceneDetail - 检查场景配置详情ds
 * @Author: 赵丽杰 <lijie.zhao@hand-china.com>
 * @Date: 2022/3/3 15:04
 * @LastEditTime: 2022/3/3 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';
import request from '@common/utils/request';

export const CheckListEditDS = (): DataSetProps => {
  return {
    transport: {
      read: ({ params, data }): AxiosRequestConfig => {
        return {
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list`,
          method: 'GET',
          params,
          data
        };
      },
      submit: ({ data }): AxiosRequestConfig => {
        return {
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list`,
          method: 'POST',
          data
        };
      }
    },
    autoCreate: false,
    autoQuery: false,
    paging: false,
    fields: [
      {
        name: 'listId',
        type: FieldType.string
      },
      {
        name: 'listCode',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.listCode'),
        required: true
      },
      {
        name: 'description',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.listName'),
        required: true
      },
      // 启动标志
      {
        name: 'enabledFlag',
        // lookupCode: 'HFSIDS.ENABLED_FLAG',
        type: FieldType.boolean,
        label: intl.get('hfsids.checkListConfig.enabledFlag'),
        defaultValue: false,
        required: true
      }
    ]
  };
};

const setColumnNameLovPara = dataSet => {
  // 已存在使用字段
  const valuesList = dataSet
    .filter(rec => rec.get('columnName'))
    .map(rec => `'${rec.get('columnName')}'`);
  dataSet.getField('columnName').setLovPara('usedValue', valuesList.join());
};

export const CheckFieldsDS = (id: string | undefined): DataSetProps => {
  return {
    transport: {
      read: (config): AxiosRequestConfig => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-field`,
          method: 'GET',
          data: { listId: id }
        };
      },
      submit: config => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-field`,
          method: 'POST'
        };
      }
    },
    events: {
      load: ({ dataSet }) => {
        // 设置字段LOV参数
        setColumnNameLovPara(dataSet);
      },
      update: ({ dataSet, name }) => {
        if (name === 'columnName') {
          setColumnNameLovPara(dataSet);
        }
      }
    },
    autoQuery: false,
    fields: [
      // 通用字段
      {
        name: 'columnName',
        type: FieldType.string,
        lookupUrl: `${
          commonConfig.IDS_API
        }/v1/${getCurrentOrganizationId()}/check-list-field/column/options`,
        lookupAxiosConfig: () => {
          return {
            params: {
              listId: id
            }
          };
        },
        label: intl.get('hfsids.checkListConfig.columnName').d('通用字段')
      },
      // 检查点描述
      {
        name: 'fieldName',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.pointDesc')
      },
      // 检查登记
      {
        name: 'description',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.priority')
      },
      // 条件字段，不能与结果字段同时存在
      {
        name: 'conditionFlag',
        type: FieldType.boolean,
        defaultValue: false,
        label: intl.get('hfsids.checkListConfig.checkMethod')
      },
      // 结果字段，唯一
      {
        name: 'resultFlag',
        type: FieldType.boolean,
        defaultValue: false,
        label: intl.get('hfsids.checkListConfig.essentialFlag')
      },
      // 不通过统计
      {
        name: 'enabledFlag',
        type: FieldType.boolean,
        label: intl.get('hfsids.checkListConfig.failStatistics')
      }
    ]
  };
};
/**
 * * @description: 获取通用字段数据
 * @param {string} params 已有通用字段
 * @return {promise} 接口返回
 */
export const getColumnName = async (params: any) => {
  return request(
    `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-field/column/options`,
    {
      method: 'GET',
      params: {
        usedValue: params.usedValue,
        listId: params.listId
      }
    }
  );
};

/**
 * * @description: 获取字段配置所有启用的字段
 * @param {string} params
 * @return {promise} 接口返回
 */
export const getFields = async (params: any) => {
  return request(`${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-field/row`, {
    method: 'GET',
    params: {
      listId: params.listId
    }
  });
};
