/**
 * CheckScene - 检查场景配置 - Store 用于管理整个页面的数据
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { Bind } from 'lodash-decorators';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { DataSet, TextField } from 'choerodon-ui/pro';
import { FieldType } from 'choerodon-ui/dataset/data-set/interface';
import { action, computed, observable, runInAction, set } from 'mobx';
import { getCurrentOrganizationId } from 'hzero-front/src/utils/utils';
import { getFields } from './CheckListDetailStore';
import { onBeforeMenuTabRemove, openTab } from 'hzero-front/src/utils/menuTab';
import CheckConfigDetailDS from './CheckConfigDetailDS';
import CheckListDS from './CheckListDS';
import React, { ReactNode } from 'react';
import commonConfig from '@common/config/commonConfig';
import intl from 'hzero-front/src/utils/intl';
import querystring from 'querystring';
import request from '@common/utils/request';

export interface CheckListType {
  description: string; // 检查列表名称
  listCode: string;
  enabledFlag: boolean;
  listId: string;
}

export default class CheckListStore {
  checkListDS: DataSet;

  @observable checkConfigDS: DataSet;

  @observable isReady: boolean;

  @observable curListId: string | undefined;

  @observable curListCode: string | undefined;

  @observable description: string | undefined;

  @observable configColumns: ColumnProps[] = [];

  @observable editConfig = false;

  @observable configForm: Array<ReactNode> = [];

  @observable frozenFlag = false;

  constructor() {
    this.isReady = false;
    this.checkListDS = new DataSet({
      ...CheckListDS(),
      events: {
        load: ({ dataSet }) => {
          // this.setIsReady(true);
          if (!this.curListId) {
            this.setCurList(
              dataSet.current?.get('listId'),
              dataSet.current?.get('listCode'),
              dataSet.current?.get('description')
            );
          }
        }
      }
    });
    this.checkConfigDS = new DataSet({
      ...CheckConfigDetailDS()
    });
    this.checkListDS.query().then(() => {
      this.setIsReady(true);
      this.setFrozenFlag(this.checkListDS.current?.get('enabledFlag'));
    });
    // const { queryDataSet } = this.checkListDS;
    // queryDataSet?.addEventListener('update', () => this.checkListDS.query());
  }

  @action.bound
  setIsReady(isReady: boolean) {
    this.isReady = isReady;
  }

  @action.bound
  setFrozenFlag(frozenFlag: boolean) {
    this.frozenFlag = frozenFlag;
  }

  @action.bound
  setCurList(
    curListId: string | undefined,
    curListCode: string | undefined,
    description: string | undefined
  ) {
    this.curListId = curListId;
    this.curListCode = curListCode;
    this.description = description;
    // this.queryEnabledFields();
  }

  @computed get checkListQueryDS(): DataSet | undefined {
    return this.checkListDS.queryDataSet;
  }

  @computed get checkList(): CheckListType[] {
    return this.checkListDS.map(record => record.toJSONData());
  }

  @Bind()
  querycheckListDS() {
    this.checkListDS.query();
  }

  @Bind()
  queryEnabledFields() {
    getFields({ listId: this.curListId }).then(res => {
      this.checkConfigDS.queryDataSet?.current?.clear();
      // console.log('res ==', res);
      this.configColumns = [];
      this.configForm = [];
      const fields = this.checkConfigDS?.fields;
      const queryFields = this.checkConfigDS?.queryDataSet?.fields;
      // const oldFields = JSON.parse(JSON.stringify(fields));
      if (fields) {
        for (const key of fields.keys()) {
          fields.delete(key);
          queryFields?.delete(key);
        }
      }

      runInAction(() => {
        // @ts-ignore
        set(this.checkConfigDS.queryDataSet?.props, 'fields', [{}]);
      });
      const result = JSON.parse(JSON.stringify(res));
      const queryDSFields: any = [];
      const getFormItems: Array<ReactNode> = [];
      if (result && result.length) {
        result.forEach(item => {
          queryDSFields.push({
            name: item.columnName,
            label: item.description,
            type: FieldType.string
          });
          this.checkConfigDS.addField(item.columnName, {
            name: item.columnName,
            label: item.description,
            type: FieldType.string
          });
          this.checkConfigDS.queryDataSet?.addField(item.columnName, {
            name: item.columnName,
            label: item.description,
            type: FieldType.string,
            defaultValue: ''
          });
          if (item.fieldType === 'STRING') {
            getFormItems.push(<TextField name={item.columnName} />);
          } else if (item.fieldType === 'DATE') {
            getFormItems.push(
              <TextField
                name={item.columnName}
                placeholder={intl
                  .get('hfsids.checkListConfig.datePlaceholder')
                  .d('YYYY-MM-DD,英文逗号隔开,如：2022-10-27,2022-11-30')}
              />
            );
          } else if (item.fieldType === 'NUMBER') {
            getFormItems.push(
              <TextField
                name={item.columnName}
                placeholder={intl
                  .get('hfsids.checkListConfig.numberPlaceholder')
                  .d('请输入数字,并以英文逗号隔开,如：123,234')}
              />
            );
          }
        });
        const configColumns = result
          .filter(item => !item.resultFlag)
          .map(column => ({
            name: column.columnName,
            label: column.description,
            editor: record => !record?.get('_token')
          }));
        const resultColumn = result
          .filter(item => item.resultFlag)
          .map(column => ({
            name: column.columnName,
            label: column.description,
            editor: record => !record?.get('_token')
          }));
        if (resultColumn && resultColumn.length) {
          this.configColumns = configColumns.concat(resultColumn);
        } else {
          this.configColumns = configColumns;
        }
        this.configForm = getFormItems;
        runInAction(() => {
          // @ts-ignore
          set(this.checkConfigDS.queryDataSet?.props, 'fields', [...queryDSFields]);
        });
      }
    });
  }

  handleImport = () => {
    const key = '/ids/check-list/import-data/HFSIDS.CHECK_LIST_DETAIL';
    openTab({
      key,
      title: intl.get('hfsids.checkListConfig.importData'),
      search: querystring.stringify({
        // 如果是客户端导入, 那么一般是该模块的接口前缀,
        prefixPath: commonConfig.IDS_API,
        action: intl.get('hfsids.checkListConfig.importData')
      })
    });
    // MenuTab 的回调 用于处理关闭后刷新主页面及数据等 Tips: 返回 true 关闭 TAB，返回 false 不关闭 TAB
    onBeforeMenuTabRemove(key, () => {
      // this.incomeItemDs.query();
      return true;
    });
  };

  // loadMore = (total) => {
  //   if(total === this.checkListDS.length){
  //     return (
  //       <div
  //         style={{
  //           textAlign: 'center',
  //           marginTop: 12,
  //           height: 32,
  //           lineHeight: '32px'
  //         }}
  //       >
  //         {/* {loadingMore && <Spin />} */}
  //         {/* {!loadingMore && ( */}
  //         <Button onClick={this.loadingMore}>loading more</Button>
  //         {/* )} */}
  //       </div>
  //     )
  //   }
  //   return null;
  // }

  // loadingMore = async () => {
  //   const data = JSON.parse(JSON.stringify(this.checkListDS.toJSONData()));
  //   const res = await this.checkListDS().qeury()
  // }

  /**
   * 生成公式
   */
  generatorFormula = listCode => {
    return request(`${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list/formula`, {
      method: 'GET',
      params: {
        listId: this.curListId,
        listCode
      }
    });
  };
}
