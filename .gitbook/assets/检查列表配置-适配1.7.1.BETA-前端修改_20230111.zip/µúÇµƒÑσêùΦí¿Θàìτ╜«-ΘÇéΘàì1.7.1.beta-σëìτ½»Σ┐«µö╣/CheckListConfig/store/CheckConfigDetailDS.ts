/**
 * CheckScene - 检查方案明细ds
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2022/3/4 15:04
 * @LastEditTime: 2022/3/4 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */

import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
// import { DataSet } from 'choerodon-ui/pro';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => {
  return {
    transport: {
      read: (config): AxiosRequestConfig => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-detail`,
          method: 'GET'
        };
      },
      submit: config => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-detail`,
          method: 'POST'
        };
      }
    },
    autoQueryAfterSubmit: true,
    events: {
      // submit: ({dataSet, data}) => {
      //   console.log('SUBMIT===   ', dataSet, data);
      //   const record = JSON.parse(JSON.stringify(data))[0];
      //   // eslint-disable-next-line no-restricted-syntax
      //   for (const key in record) {
      //     if (Array.isArray(record[key])) {
      //       record[key] = record[key].join(',');
      //     }
      //   }
      //   dataSet.current?.set({...record});
      //   console.log('aaa ', record)
      // }
      // load: ({ dataSet }) => {
      //   // 设置字段LOV参数
      //   setColumnNameLovPara(dataSet);
      // }
      // update: ({dataSet, name}) => {
      //   if (name === 'columnName') {
      //     setColumnNameLovPara(dataSet);
      //   }
      // }
    },
    autoQuery: false,
    fields: [
      {
        name: 'listId',
        type: FieldType.string
      },
      // qiyong
      {
        name: 'enabledFlag',
        type: FieldType.boolean,
        defaultValue: true,
        label: intl.get('hfsids.checkListConfig.enabledFlag')
      }
    ],
    queryFields: []
  };
};
