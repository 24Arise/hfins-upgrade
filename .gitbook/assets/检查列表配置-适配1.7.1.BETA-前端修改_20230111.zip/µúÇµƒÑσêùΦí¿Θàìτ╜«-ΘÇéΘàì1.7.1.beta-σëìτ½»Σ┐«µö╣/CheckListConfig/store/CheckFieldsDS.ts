/**
 * CheckScene - 检查方案明细ds
 * @Author: 王新诚 <xincheng.wang@hand-china.com>
 * @Date: 2022/3/4 15:04
 * @LastEditTime: 2022/3/4 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */

import { AxiosRequestConfig } from 'axios';
// import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { DataSet } from 'choerodon-ui/pro';
import { FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default () =>
  new DataSet({
    transport: {
      read: (config): AxiosRequestConfig => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-field`,
          method: 'GET'
        };
      },
      submit: config => {
        return {
          ...config,
          url: `${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list-field`,
          method: 'POST'
        };
      }
    },
    autoQuery: false,
    fields: [
      {
        name: 'listId',
        type: FieldType.string
      },
      // 通用字段
      {
        name: 'columnName',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.columnName').d('通用字段')
      },
      // 字段类型
      {
        name: 'fieldType',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.fieldType').d('字段类型'),
        lookupCode: 'HFSIDS.FIELD_TYPE',
        defaultValue: 'STRING',
        required: true
      },
      // 字段名称
      {
        name: 'fieldName',
        type: FieldType.string,
        label: intl.get('hfsids.checkListConfig.fieldName').d('字段名称'),
        required: true
      },
      // 描述
      {
        name: 'description',
        type: FieldType.intl,
        label: intl.get('hfsids.checkListConfig.description').d('描述'),
        required: true
      },
      // 条件字段，不能与结果字段同时存在
      {
        name: 'conditionFlag',
        type: FieldType.boolean,
        defaultValue: false,
        label: intl.get('hfsids.checkListConfig.conditionFlag').d('是否条件字段'),
        computedProps: {
          disabled: ({ record }) => {
            return record?.get('resultFlag');
          }
        }
      },
      // 结果字段，唯一
      {
        name: 'resultFlag',
        type: FieldType.boolean,
        defaultValue: false,
        label: intl.get('hfsids.checkListConfig.resultFlag').d('是否结果字段'),
        computedProps: {
          disabled: ({ record }) => {
            return record?.get('conditionFlag');
          }
        }
      },
      // qiyong
      {
        name: 'enabledFlag',
        type: FieldType.boolean,
        defaultValue: true,
        label: intl.get('hfsids.checkListConfig.enabledFlag')
      }
    ]
  });
