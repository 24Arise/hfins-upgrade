/**
 * CheckScene - 检查场景配置 - 右侧单体详情 - 表格详情
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
// import { CheckFieldsDS } from '@/pages/CheckListConfig/store/CheckListDetailStore';
import { Button, Form, Modal, Table } from 'choerodon-ui/pro';
import { ColumnLock, TableButtonType } from 'choerodon-ui/pro/lib/table/enum';

import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { RecordStatus } from 'choerodon-ui/dataset/data-set/enum';
import { observer } from 'mobx-react';
import { useCheckListStore } from '@/pages/CheckListConfig/hooks';
import Collapse from '@common/components/Collapse';
import Icons from '@common/components/Icons';
import React, { useEffect } from 'react';
import intl from 'utils/intl';

export const ListConfigTable: React.FC = observer(() => {
  const {
    curListId,
    checkConfigDS,
    configColumns,
    handleImport,
    configForm,
    frozenFlag
  } = useCheckListStore();
  // const checkConfigDS = useDataSet(CheckConfigDetailDS, ListConfigTable);

  const columns: ColumnProps[] = [
    ...configColumns,
    {
      header: intl.get('hfsids.common.operation'),
      lock: ColumnLock.right,
      command: ({ record }) => {
        return [
          <a
            key="add"
            hidden={record.status === RecordStatus.add}
            onClick={() => {
              openModal(record);
            }}
            // @ts-ignore
            disabled={frozenFlag}
          >
            {intl.get('hfsids.common.edit').d('编辑')}
          </a>
        ];
      }
    }
  ];

  useEffect(() => {
    checkConfigDS.setQueryParameter('listId', curListId);
    checkConfigDS.query();
  }, [curListId]);

  const openModal = record => {
    Modal.open({
      title: intl.get('hfsids.checkListConfig.editFields').d('编辑列表字段'),
      key: Modal.key(),
      drawer: true,
      children: <Form record={record}>{configForm}</Form>,
      footer: (okBtn, cancelBtn) => {
        return (
          <div>
            {cancelBtn}
            {okBtn}
          </div>
        );
      },
      onCancel: async () => {
        checkConfigDS.reset();
        return Promise.resolve(true);
      },
      onOk: async () => {
        const subRes = await checkConfigDS.submit();
        if (subRes && subRes.failed) {
          return Promise.reject();
        }
        checkConfigDS.query();
        return Promise.resolve(subRes);
      }
    });
  };

  const handleAddFields = async () => {
    checkConfigDS.create(
      {
        listId: curListId
      },
      0
    );
    openModal(checkConfigDS.current);
  };

  const importBtn = (
    <Button onClick={handleImport}>
      <Icons type="import" />
      {intl.get('hfsids.common.import')}
    </Button>
  );

  return (
    <Collapse defaultActiveKey={['listConfig']}>
      <Collapse.Panel
        key="listConfig"
        header={intl.get('hfsids.checkListConfig.listConfig').d('检查列表配置')}
      >
        <Table
          buttons={
            !frozenFlag
              ? [
                [TableButtonType.add, { onClick: handleAddFields }],
                TableButtonType.save,
                // flushBtn,
                importBtn,
                [
                  TableButtonType.delete,
                  {
                    afterClick: () => {
                      checkConfigDS.query();
                    }
                  }
                ]
              ]
              : []
          }
          dataSet={checkConfigDS}
          columns={columns}
          highLightRow
        />
      </Collapse.Panel>
    </Collapse>
  );
});
