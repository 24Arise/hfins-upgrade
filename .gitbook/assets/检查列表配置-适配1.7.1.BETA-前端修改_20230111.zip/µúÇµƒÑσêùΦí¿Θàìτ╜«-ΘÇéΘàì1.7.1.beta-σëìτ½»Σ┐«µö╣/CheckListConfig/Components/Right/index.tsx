/**
 * CheckScene - 检查场景配置 - 右侧单体详情
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */

import { FieldConfigTable } from './FieldConfigTable';
import { ListConfigTable } from './CheckConfigTable';
import { RightHeaderCard } from './HeaderCard';
import { observer } from 'mobx-react';
import React from 'react';
import styles from './index.module.less';

export const Right = observer(() => {
  return (
    <div className={styles.rightDetail}>
      <RightHeaderCard />
      <FieldConfigTable />
      <ListConfigTable />
    </div>
  );
});
