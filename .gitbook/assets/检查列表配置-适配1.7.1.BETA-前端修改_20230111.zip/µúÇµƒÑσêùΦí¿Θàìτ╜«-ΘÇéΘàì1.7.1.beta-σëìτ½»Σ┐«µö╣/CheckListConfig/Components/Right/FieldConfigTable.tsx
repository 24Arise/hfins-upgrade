/**
 * CheckScene - 检查场景配置 - 右侧单体详情 - 表格详情
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
// import { CheckFieldsDS } from '@/pages/CheckListConfig/store/CheckListDetailStore';
import { ColumnAlign, TableButtonType } from 'choerodon-ui/pro/lib/table/enum';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { Switch, Table } from 'choerodon-ui/pro';
import { useDataSet } from 'hzero-front/lib/utils/hooks';

import CheckFieldsDS from '@/pages/CheckListConfig/store/CheckFieldsDS';
// import { RecordStatus } from 'choerodon-ui/pro/lib/data-set/enum';
import { getColumnName } from '../../store/CheckListDetailStore';
import { observer } from 'mobx-react';
import { showEditor } from '@common/utils/editor';
import { useCheckListStore } from '@/pages/CheckListConfig/hooks';
import Collapse from '@common/components/Collapse';
import React, { useEffect } from 'react';
import intl from 'utils/intl';

export const FieldConfigTable: React.FC = observer(() => {
  const { curListId, queryEnabledFields, frozenFlag } = useCheckListStore();
  const checkFieldsDS = useDataSet(CheckFieldsDS, FieldConfigTable);

  const columns: ColumnProps[] = [
    {
      name: 'columnName'
    },
    {
      name: 'fieldType',
      editor: !frozenFlag && showEditor
    },
    {
      name: 'fieldName',
      editor: !frozenFlag && showEditor
    },
    {
      name: 'description',
      editor: !frozenFlag && showEditor
    },
    {
      name: 'conditionFlag',
      editor: !frozenFlag && showEditor
    },
    {
      name: 'resultFlag',
      editor: !frozenFlag && showEditor
    },
    {
      name: 'enabledFlag',
      // width: 100,
      align: ColumnAlign.center,
      editor: (record, name) =>
        !frozenFlag && <Switch name={name} disabled={showEditor(record, name)} />
    }
  ];

  useEffect(() => {
    checkFieldsDS.setQueryParameter('listId', curListId);
    checkFieldsDS.query();
    queryEnabledFields();
  }, [curListId]);

  const handleAddFields = async () => {
    const valuesList: any = [];
    checkFieldsDS.forEach(item => {
      if (item.get('columnName')) {
        valuesList.push(`${item.get('columnName')}`);
      }
    });
    const res = await getColumnName({ listId: curListId, usedValue: valuesList.join() });
    checkFieldsDS.create(
      {
        listId: curListId,
        columnName: res[0]
      },
      0
    );
  };

  return (
    <Collapse defaultActiveKey={['fields']}>
      <Collapse.Panel
        key="fields"
        header={intl.get('hfsids.checkListConfig.feildConfig').d('字段配置')}
      >
        <Table
          buttons={
            !frozenFlag
              ? [
                [TableButtonType.add, { onClick: handleAddFields }],
                [TableButtonType.save, { afterClick: queryEnabledFields }]
              ]
              : []
          }
          dataSet={checkFieldsDS}
          columns={columns}
          highLightRow
        />
      </Collapse.Panel>
    </Collapse>
  );
});
