/**
 * CheckScene - 检查场景配置 - 右侧单体详情 - 头卡片
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { Icon as C7NIcon, Switch } from 'choerodon-ui/pro/lib';
// import { CheckListEditDS } from '@/pages/CheckListConfig/store/CheckListDetailStore';
import { DataSet, Form, Modal, Output, TextField } from 'choerodon-ui/pro';
import { LabelAlign } from 'choerodon-ui/pro/lib/form/enum';
import { handleEnabledChange } from '@/utils/commonUtils';
import { observer } from 'mobx-react';
import { useCheckListStore } from '@/pages/CheckListConfig/hooks';
import CheckListDS from '../../store/CheckListDS';
import Collapse from '@common/components/Collapse';
import React, { useEffect, useMemo } from 'react';
import intl from 'utils/intl';
import styles from './index.module.less';

export const RightHeaderCard: React.FC = observer(() => {
  const {
    curListId,
    curListCode,
    description,
    querycheckListDS,
    setCurList,
    setFrozenFlag,
    frozenFlag
  } = useCheckListStore();
  const checkListEditDS = useMemo(() => {
    return new DataSet({
      ...CheckListDS(),
      events: {
        update: async ({ dataSet, record, name, value }) => {
          if (name === 'enabledFlag' && record?.get('_token')) {
            let title = intl
              .get('hfsids.common.confirmeEnabledFlag')
              .d('启用后无法进行编辑,确认是否启用？');
            if (!value) {
              title = intl.get('hfsids.common.disabledFlag').d('是否确认禁用该笔数据？');
            }
            const res = await handleEnabledChange({
              dataSet,
              record,
              title,
              keyField: '_token'
            });
            if (res) {
              setFrozenFlag(value);
              querycheckListDS();
            }
          }
        }
      }
    });
  }, [curListId]);

  useEffect(() => {
    checkListEditDS.setQueryParameter('listCode', curListCode);
    checkListEditDS.query();
  }, [curListId]);

  const openEditModel = () => {
    Modal.open({
      title: intl.get('hfsids.checkScene.sceneInfo'),
      movable: false,
      closable: true,
      destroyOnClose: true,
      style: { width: 500 },
      footer: (okBtn, cancelBtn) => {
        return (
          <>
            {okBtn}
            {cancelBtn}
          </>
        );
      },
      children: (
        <Form dataSet={checkListEditDS}>
          <TextField name="listCode" disabled />
          <TextField name="description" />
          {/* <CheckBox name="enabledFlag" /> */}
        </Form>
      ),
      onOk: async () => checkListEditDS.submit(),
      afterClose: async () => {
        await querycheckListDS();
        setCurList(curListId, curListCode, description);
      }
    });
  };
  return (
    <Collapse defaultActiveKey={['checkList']}>
      <Collapse.Panel key="checkList" header={description}>
        <div className={styles.rightListHeaderCard}>
          {!frozenFlag && (
            <p className={styles.editButton}>
              <span onClick={openEditModel}>
                <C7NIcon type="edit-o" />
                {intl.get('hfsids.common.edit')}
              </span>
            </p>
          )}
          <Form dataSet={checkListEditDS} columns={3} labelWidth={90} labelAlign={LabelAlign.left}>
            <Output name="listCode" />
            <Output name="description" />
            <Switch name="enabledFlag" />
          </Form>
        </div>
      </Collapse.Panel>
    </Collapse>
  );
});
