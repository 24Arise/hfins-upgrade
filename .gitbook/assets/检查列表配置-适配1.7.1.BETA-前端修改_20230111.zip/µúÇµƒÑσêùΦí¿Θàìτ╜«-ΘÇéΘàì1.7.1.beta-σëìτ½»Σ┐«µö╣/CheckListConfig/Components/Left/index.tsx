/**
 * CheckScene - 检查场景配置 - 左侧列表
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { Button, Icon as C7NIcon, Form, Switch, TextField } from 'choerodon-ui/pro';
import { ButtonColor, ButtonType, FuncType } from 'choerodon-ui/pro/lib/button/enum';
import { LabelLayout } from 'choerodon-ui/pro/lib/form/enum';
import { LeftListItems } from './LeftListItems';
import { Popover } from 'choerodon-ui';
import { observer } from 'mobx-react';
import { useCheckListStore } from '@/pages/CheckListConfig/hooks';
import React, { ReactElement, useState } from 'react';
import intl from 'utils/intl';
import styles from '@/pages/CheckScene/index.module.less';

export const LeftList = observer(() => {
  const [visibleFlag, setVisibleFlag] = useState(false);
  const { checkListQueryDS, querycheckListDS } = useCheckListStore();
  const filterForm: ReactElement = (
    <>
      <Form
        dataSet={checkListQueryDS}
        style={{ width: '280px', padding: '16px 16px 16px 0' }}
        labelWidth={90}
      >
        <TextField
          name="listCode"
          onEnterDown={() => {
            querycheckListDS();
            setVisibleFlag(false);
          }}
        />
        <TextField
          name="description"
          onEnterDown={() => {
            querycheckListDS();
            setVisibleFlag(false);
          }}
        />
        <Switch
          name="enabledFlag"
          onChange={() => {
            querycheckListDS();
            setVisibleFlag(false);
          }}
        />
        <div>
          <Button
            color={ButtonColor.primary}
            onClick={() => {
              querycheckListDS();
              setVisibleFlag(false);
            }}
          >
            {intl.get('hfsids.common.inquiry')}
          </Button>
          <Button
            type={ButtonType.reset}
            style={{ marginLeft: 8 }}
            onClick={() => {
              checkListQueryDS?.reset();
              querycheckListDS();
              setVisibleFlag(false);
            }}
          >
            {intl.get('hfsids.common.reset')}
          </Button>
        </div>
      </Form>
    </>
  );

  return (
    <div className={styles.leftList}>
      <div className={styles.searchBar}>
        <Form
          dataSet={checkListQueryDS}
          labelLayout={LabelLayout.placeholder}
          style={{ width: '172px' }}
        >
          <TextField
            name="keyword"
            placeholder={intl.get('hfsids.common.keyword')}
            onEnterDown={querycheckListDS}
          />
        </Form>
        <Popover
          content={filterForm}
          placement="bottomLeft"
          visible={visibleFlag}
          onVisibleChange={() => setVisibleFlag(!visibleFlag)}
        >
          <Button funcType={FuncType.raised} className={styles.filterMoreBtn}>
            <C7NIcon type="filter2" />
          </Button>
        </Popover>
      </div>
      <LeftListItems />
    </div>
  );
});
