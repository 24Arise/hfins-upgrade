/**
 * CheckScene - 检查场景配置 - 左侧列表 - 具体
 * @Author:  <haotian.liu@hand-china.com>
 * @Date: 2022/9/6 15:04
 * @LastEditTime: 2022/9/6 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { CheckListType } from '../../store/CheckListStore';
import { List, Tooltip } from 'choerodon-ui';
import { observer } from 'mobx-react';
import { useCheckListStore } from '@/pages/CheckListConfig/hooks';
import React, { useMemo } from 'react';
import classnames from 'classnames';
import intl from 'utils/intl';
import styles from '@/pages/CheckListConfig/index.module.less';

export const LeftListItems = observer(() => {
  const { checkList } = useCheckListStore();
  return (
    <>
      {/* {checkList.map(item => (
        <ListItem key={item.listId} item={item} />
      ))} */}
      <List
        itemLayout="horizontal"
        // loadMore={loadMore}
        dataSource={checkList}
        renderItem={item => <ListItem key={item.listId} item={item} />}
      />
    </>
  );
});

const ListItem: React.FC<{ item: CheckListType }> = observer(({ item }) => {
  const { curListId, setCurList, setFrozenFlag } = useCheckListStore();
  const handleItemClick = (listId: string) => {
    setCurList(listId, item.listCode, item.description);
    setFrozenFlag(item.enabledFlag);
  };

  const isCurItem = useMemo(() => {
    return item.listId?.toString() === curListId?.toString();
  }, [curListId]);

  const itemStyle = useMemo(() => {
    if (isCurItem) {
      return classnames([styles.listItemBox, styles.itemSelected]);
    }
    return styles.listItemBox;
  }, [isCurItem]);

  const flagStyle = useMemo(() => {
    const styleList: string[] = [];
    if (item.enabledFlag) {
      styleList.push(styles.enable);
      if (isCurItem) {
        styleList.push(styles.enableSelected);
      }
    } else {
      styleList.push(styles.disable);
      if (isCurItem) {
        styleList.push(styles.disableSelected);
      }
    }

    return classnames(styleList);
  }, [isCurItem, item]);

  return (
    <div className={itemStyle} onClick={() => handleItemClick(item.listId)}>
      <div className={styles.titleBox}>
        <p className={styles.title}>
          <Tooltip title={item.description}>{item.description}</Tooltip>
        </p>
        <p className={flagStyle}>
          {item.enabledFlag
            ? intl.get('hfsids.checkListConfig.enabledFlag')
            : intl.get('hfsids.checkListConfig.disabledFlag')}
        </p>
      </div>
      <div className={styles.listFieldsBox}>
        <div className={styles.fieldItem}>
          <span>{item.listCode}</span>
        </div>
      </div>
    </div>
  );
});
