/**
 * CheckScene - 检查列表配置
 * @Author:  向芳<fang.xiang01@hand-china.com>
 * @Date: 2022/10/21 15:04
 * @LastEditTime: 2022/10/21 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { Button, Modal, Spin, notification } from 'choerodon-ui/pro';
import { ButtonColor } from 'choerodon-ui/pro/lib/button/enum';
import { CheckListContext } from '@/pages/CheckListConfig/hooks';
import { Header } from 'components/Page';
import { LeftList } from './Components/Left';
import { Right } from './Components/Right';
import { observer } from 'mobx-react';
import CheckEditModal from './Form/CheckEditModal';
import CheckListStore from './store/CheckListStore';
import React, { useState } from 'react';
import copy from 'copy-to-clipboard';
import formatterCollections from 'utils/intl/formatterCollections';
import intl from 'utils/intl';
import styles from '@/pages/CheckScene/index.module.less';

const CheckListConfig = observer(() => {
  // const { checkListDS, curListCode, isReady, setCurList, generatorFormula, querycheckListDS } = useCheckListStore();

  const [checkListStore] = useState(new CheckListStore());
  const { curListId, curListCode, isReady, generatorFormula, querycheckListDS } = checkListStore;

  const handleEditModal = type => {
    const listId = type === 'copy' ? curListId : undefined;
    Modal.open({
      title:
        type === 'copy'
          ? intl.get('hfsids.checkListConfig.copyList').d('复制检查列表')
          : intl.get('hfsids.checkListConfig.createList'),
      fullScreen: false,
      movable: false,
      closable: true,
      // drawer: true,
      destroyOnClose: true,
      style: { width: 500 },
      footer: (okBtn, cancelBtn) => {
        return (
          <>
            {okBtn}
            {cancelBtn}
          </>
        );
      },
      children: <CheckEditModal listId={listId} type={type} />,
      afterClose: async () => {
        await querycheckListDS();
        // if(type === 'copy')
        //   setCurList(undefined, undefined);
      }
    });
  };

  const handleGenerator = () => {
    generatorFormula(curListCode).then(res => {
      const modal = Modal.open({
        title: intl.get('hfsids.checkListConfig.formula'),
        fullScreen: false,
        movable: false,
        closable: true,
        // drawer: true,
        footer: null,
        destroyOnClose: true,
        // footer: (okBtn, cancelBtn) => {
        //   return (
        //     <>
        //       {okBtn}
        //       {cancelBtn}
        //     </>
        //   );
        // },
        children: (
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <p>{res}</p>
            <a onClick={() => handleCopyFormula(res, modal)}>{intl.get('hfsids.common.copy')}</a>
          </div>
        )
      });
    });
  };

  const handleCopyFormula = (data, modal) => {
    copy(data);
    notification.success({
      message: intl.get('hfsids.common.successfulOperation'),
      description: '',
      placement: 'bottomRight'
    });
    modal.close();
  };

  return (
    <>
      <Header title={intl.get('hfsids.checkListConfig.checkListConfig')}>
        <Button onClick={() => handleEditModal('add')} color={ButtonColor.primary}>
          {intl.get('hfsids.checkListConfig.new')}
        </Button>
        <Button onClick={() => handleEditModal('copy')} color={ButtonColor.primary}>
          {intl.get('hfsids.checkListConfig.copyList')}
        </Button>
        <Button onClick={handleGenerator} color={ButtonColor.primary}>
          {intl.get('hfsids.checkListConfig.generateFormula')}
        </Button>
      </Header>
      <CheckListContext.Provider value={checkListStore}>
        <div className={styles.container}>
          <LeftList />
          {isReady ? (
            <Right />
          ) : (
            <Spin spinning style={{ width: '100%', height: '100%', background: '#fff' }} />
          )}
        </div>
      </CheckListContext.Provider>
    </>
  );
});

export default formatterCollections({ code: ['hfsids.common', 'hfsids.checkListConfig'] })(
  CheckListConfig
);
