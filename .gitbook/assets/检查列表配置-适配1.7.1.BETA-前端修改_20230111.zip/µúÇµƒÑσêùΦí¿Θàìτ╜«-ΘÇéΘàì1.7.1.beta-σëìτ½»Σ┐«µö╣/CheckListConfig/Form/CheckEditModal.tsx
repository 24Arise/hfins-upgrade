/**
 * CheckSceneEdite - 检查场景配置新建以及维护
 * @Author: 赵丽杰 <lijie.zhao@hand-china.com>
 * @Date: 2022/3/3 15:04
 * @LastEditTime: 2022/3/3 15:04
 * @Copyright: Copyright (c) 2022, Hand
 */
import { Bind } from 'lodash-decorators';
import { DataSet, Form, IntlField, Switch, TextField } from 'choerodon-ui/pro';
import { FormProps } from 'choerodon-ui/pro/lib/form/Form';
import { getCurrentOrganizationId } from 'hzero-front/src/utils/utils';
import { modalChildrenProps } from 'choerodon-ui/pro/lib/modal/interface';
import CheckListDS from '../store/CheckListDS';
import React, { Component } from 'react';
import commonConfig from '@common/config/commonConfig';
import formatterCollections from 'utils/intl/formatterCollections';
import intl from 'utils/intl';
import notification from 'utils/notification';
import request from '@common/utils/request';

interface CheckEditModalProps extends FormProps {
  modal?: modalChildrenProps;
  listId?: number | string;
  type?: string | undefined;
  // setCurScenarioId?: any;
}

class CheckEditModal extends Component<CheckEditModalProps> {
  checkListEditDS: DataSet;

  constructor(props) {
    super(props);
    this.checkListEditDS = new DataSet({
      ...CheckListDS()
    });
    // 区分是否有scenarioId，有则为维护，没有则为创建
    if (this.props.type === 'edit') {
      this.checkListEditDS.query();
    } else if (this.props.type === 'copy') {
      this.checkListEditDS.create(
        { listId: this.props.listId, listCode: null, description: null },
        0
      );
    } else {
      this.checkListEditDS.create({ listCode: null, description: null }, 0);
    }
    // console.log('aaaa == ', this.checkListEditDS.toData())
    this.props.modal?.handleOk(this.handleSubmit);
  }

  @Bind
  async handleSubmit() {
    // 数据校验
    if (!(await this.checkListEditDS.validate())) {
      notification.warning({
        message: intl.get('hfsids.common.dataVerificationFailed'),
        description: ''
      });
      return false;
    }
    if (this.props.type === 'copy') {
      const list = this.checkListEditDS?.toJSONData();
      request(`${commonConfig.IDS_API}/v1/${getCurrentOrganizationId()}/check-list/copy`, {
        method: 'POST',
        data: list
      });
      // handleCopy(checkListDS.get(0))
    } else {
      await this.checkListEditDS.submit();
    }
  }

  render() {
    return (
      <>
        <Form columns={1} dataSet={this.checkListEditDS}>
          <TextField name="listCode" />
          <IntlField name="description" />
          {this.props.type !== 'add' && <Switch name="enabledFlag" />}
        </Form>
      </>
    );
  }
}

export default formatterCollections({ code: ['hfsids.common', 'hfsids.checkConfigList'] })(
  CheckEditModal
);
