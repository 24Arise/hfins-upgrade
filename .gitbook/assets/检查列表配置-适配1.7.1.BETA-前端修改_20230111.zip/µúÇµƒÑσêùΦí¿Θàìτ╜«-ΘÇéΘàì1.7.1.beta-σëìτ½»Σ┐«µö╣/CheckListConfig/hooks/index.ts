/**
 * @Description: 结果模型定义——字段详情——详情页 hooks
 * @Author: <haotian.liu@hand-china.com>
 * @Date: 2022-09-07 09:26:23
 * @LastEditTime: 2022-09-07 09:26:23
 * @Copyright: Copyright (c) 2022, Hand
 */
import { createContext, useContext } from 'react';
import CheckListStore from '@/pages/CheckListConfig/store/CheckListStore';

export const CheckListContext = createContext<CheckListStore>(new CheckListStore());

export const useCheckListStore = () => {
  return useContext(CheckListContext);
};
