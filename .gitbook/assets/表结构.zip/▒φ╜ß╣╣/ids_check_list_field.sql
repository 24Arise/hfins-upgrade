/*
version:1
*/
CREATE TABLE ids_check_list_field (
list_field_id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
list_id bigint(20) NOT NULL COMMENT '检查列表ID',
field_name varchar(50) NOT NULL COMMENT '转换前字段名(字段名称)',
column_name varchar(50) NOT NULL COMMENT '转换后字段名(通用字段)',
description varchar(480) NOT NULL COMMENT '字段描述',
field_type varchar(30) NOT NULL DEFAULT'CHARACTER' COMMENT '字段类型',
condition_flag tinyint(1) NOT NULL DEFAULT'0' COMMENT '是否条件字段',
result_flag tinyint(1) NOT NULL DEFAULT'0' COMMENT '是否结果字段',
created_by bigint(20) NOT NULL DEFAULT'-1' COMMENT '创建人',
last_updated_by bigint(20) NOT NULL DEFAULT'-1' COMMENT '最近更新人',
creation_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
last_update_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最近更新时间',
object_version_number bigint(20) NOT NULL DEFAULT'1' COMMENT '行版本号，用来处理锁',
tenant_id bigint(20) NOT NULL COMMENT '租户ID',
KEY ids_check_list_field_n1 (`list_id`), 
UNIQUE KEY ids_check_list_field_u1 (`list_id`, `field_name`), 
UNIQUE KEY ids_check_list_field_u2 (`list_id`, `column_name`), 
PRIMARY KEY(`list_field_id`)
)ENGINE=innodb  CHARSET=utf8mb4 COMMENT='检查列表字段表';

/*
version:2
*/
ALTER TABLE ids_check_list_field ADD COLUMN enabled_flag tinyint(1) Not Null Default '1' Comment '启用标志' after result_flag;
