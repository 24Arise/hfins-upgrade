/*
 Navicat Premium Data Transfer

 Source Server         : 172.22.3.206
 Source Server Type    : MySQL
 Source Server Version : 50737
 Source Host           : 172.22.3.206:3306
 Source Schema         : hfins_ids

 Target Server Type    : MySQL
 Target Server Version : 50737
 File Encoding         : 65001

 Date: 10/01/2023 14:41:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for himp_data
-- ----------------------------
CREATE TABLE `himp_data`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `batch` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '批次',
  `template_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '模板编码',
  `data_status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '数据状态[NEW(Excel导入),VALID_SUCCESS(验证成功),VALID_FAILED(验证失败),IMPORT_SUCCESS(导入成功),IMPORT_FAILED(导入失败)]',
  `sheet_index` int(11) NOT NULL COMMENT '页码',
  `error_msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '错误信息',
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '数据',
  `back_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `himp_data_n1`(`batch`, `data_status`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 993 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin COMMENT = '导入临时数据' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
