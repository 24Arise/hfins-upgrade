/*
version:1
*/
CREATE TABLE ids_check_list_tl (
lang varchar(30) NOT NULL COMMENT '语言',
list_id bigint(20) NOT NULL COMMENT '检查列表ID',
description varchar(480) COMMENT '描述',
UNIQUE KEY ids_check_list_tl_u1 (`list_id`, `lang`)
)ENGINE=innodb  CHARSET=utf8mb4 COMMENT='检查列表多语言表';

