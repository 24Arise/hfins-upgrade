/*
version:1
*/
CREATE TABLE ids_check_list (
list_id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
list_code varchar(30) NOT NULL COMMENT '列表代码',
description varchar(480) NOT NULL COMMENT '列表描述',
enabled_flag tinyint(1) NOT NULL DEFAULT'0' COMMENT '启用标志',
created_by bigint(20) NOT NULL DEFAULT'-1' COMMENT '创建人',
last_updated_by bigint(20) NOT NULL DEFAULT'-1' COMMENT '最近更新人',
creation_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
last_update_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最近更新时间',
object_version_number bigint(20) NOT NULL DEFAULT'1' COMMENT '行版本号，用来处理锁',
tenant_id bigint(20) NOT NULL COMMENT '租户ID',
UNIQUE KEY ids_check_list_u1 (`list_code`, `tenant_id`), 
PRIMARY KEY(`list_id`)
)ENGINE=innodb  CHARSET=utf8mb4 COMMENT='检查列表表';

