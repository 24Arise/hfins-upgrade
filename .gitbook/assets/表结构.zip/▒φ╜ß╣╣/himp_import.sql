/*
 Navicat Premium Data Transfer

 Source Server         : 172.22.3.206
 Source Server Type    : MySQL
 Source Server Version : 50737
 Source Host           : 172.22.3.206:3306
 Source Schema         : hfins_ids

 Target Server Type    : MySQL
 Target Server Version : 50737
 File Encoding         : 65001

 Date: 10/01/2023 14:41:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for himp_import
-- ----------------------------
CREATE TABLE `himp_import`  (
  `import_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `batch` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '批次',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '当前状态',
  `data_count` int(11) NOT NULL COMMENT '数据数量',
  `OBJECT_VERSION_NUMBER` bigint(20) DEFAULT NULL,
  `CREATION_DATE` datetime(0) DEFAULT CURRENT_TIMESTAMP,
  `CREATED_BY` bigint(20) DEFAULT 0,
  `LAST_UPDATED_BY` bigint(20) DEFAULT 0,
  `LAST_UPDATE_DATE` datetime(0) DEFAULT CURRENT_TIMESTAMP,
  `template_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '模板编码',
  `tenant_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '租户',
  `param` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '自定义参数',
  `file_name` varchar(240) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '文件名',
  PRIMARY KEY (`import_id`) USING BTREE,
  UNIQUE INDEX `himp_import_u1`(`batch`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
