/*
 * @Description: 消息推送历史错误数据回滚弹窗
 * @Author: hualv.jiang <hualv.jiang@hand-china.com>
 * @Date: 2020-11-04 14:35:02
 * @LastEditTime: 2021-11-13 14:28:18
 * @Copyright: Copyright (c) 2020, Hand
 */

import { ArchiveShelfDS } from '../../stores';
import {
  Button,
  DataSet,
  Form,
  IntlField,
  Modal,
  Select,
  Table,
  TextField
} from 'choerodon-ui/pro';
import { ColumnProps } from 'choerodon-ui/pro/lib/table/Column';
import { getCurrentOrganizationId } from 'hzero-front/src/utils/utils';
import { notification } from 'choerodon-ui';
import React, { Component } from 'react';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';
import request from '@common/utils/request';

interface shelfProps {
  current: any;
  callback: any;
  type: any;
}

class AssignShelf extends Component<shelfProps> {
  stepList: any;

  shelfDS: DataSet;

  constructor(props) {
    super(props);
    this.shelfDS = new DataSet({
      ...ArchiveShelfDS()
    });
    this.stepList = [];
    this.props.callback('shelf', this.shelfDS);
  }

  get shelfColumns(): ColumnProps[] {
    return [
      {
        name: 'standardCode'
      },
      {
        name: 'description',
        width: 130,
        editor: this.props.type === 'assign'
      },
      {
        name: 'assignNum',
        editor: this.props.type === 'assign',
        hidden: this.props.type !== 'assign'
      },
      {
        name: 'length',
        width: 90
      },
      {
        name: 'width',
        width: 90
      },
      {
        name: 'height',
        width: 90
      },
      {
        name: 'rowNum',
        width: 60
      },
      {
        name: 'colNum',
        width: 60
      },
      {
        name: 'shelfType'
      },
      {
        name: 'archivedType'
      },
      {
        name: 'capacity',
        width: 110
      }
    ];
  }

  async componentDidMount() {
    this.shelfDS.setQueryParameter('parentLocationCode', this.props.current.get('locationCode'));
    await this.shelfDS.query();
  }

  /**
   * 新增档案架
   * @returns
   */
  handleAddShelfType = () => {
    this.shelfDS.create({}, 0);
    Modal.open({
      title: intl.get('hfsecm.archive.room.addShelfType').d('新增档案架规格'),
      closable: true,
      children: (
        <Form record={this.shelfDS.current} columns={2}>
          <TextField name="standardCode" />
          <IntlField name="description" />
          <TextField name="length" />
          <TextField name="width" />
          <TextField name="height" />
          <TextField name="rowNum" />
          <TextField name="colNum" />
          <Select name="shelfType" />
          <Select name="archivedType" />
          <TextField name="capacity" />
        </Form>
      ),
      onOk: async () => {
        const res = await this.shelfDS.validate();
        if (res) {
          this.shelfDS.submit().then(subRes => {
            if (subRes.failed) {
              return false;
            }
            shelfDS.query();
          });
        } else {
          return false;
        }
      },
      onCancel: () => {
        this.shelfDS.reset();
      }
    });
  };

  render() {
    return (
      <Table
        columns={this.shelfColumns}
        dataSet={this.shelfDS}
        buttons={[
          <Button key="add" icon="playlist_add" onClick={() => this.handleAddShelfType()}>
            {intl.get('hfsecm.archive.room.addShelfType').d('新增档案架规格')}
          </Button>
        ]}
      />
    );
  }
}

// DS
let shelfDS;

// 回调
function callback(type, DS) {
  if (type === 'shelf') {
    shelfDS = DS;
  }
}

export default function openAssignShelfModal(data, type, closeOperate: () => void) {
  const shelfModal = Modal.open({
    title: intl.get('hfsecm.archive.room.assignShelf').d('分配档案架'),
    style: { width: '880px' },
    closable: true,
    children: <AssignShelf callback={callback} current={data} type={type} />,
    onOk: async () => {
      // /archive/location/shelf
      // 得到选中的档案架
      const { selected } = shelfDS;
      const locationList: any = [];
      const standardList: any = [];
      locationList.push(data?.toData());
      if (selected && selected.length) {
        selected.forEach(sel => {
          standardList.push(sel.toData());
        });
        handleAssignReq({ locationList, standardList }).then(async (res: any) => {
          if (res?.failed) {
            notification.error({
              message: res.message,
              description: null,
              placement: 'bottomRight'
            });
          } else {
            notification.success({
              message: intl.get('hfsecm.common.successfulOperation'),
              description: null,
              placement: 'bottomRight'
            });
            shelfModal.close();
          }
        });
      }
    },
    afterClose: () => {
      closeOperate();
    }
  });

  /**
   * 批量分配档案架
   */
  const handleAssignReq = data => {
    return request(
      `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/location/shelf`,
      {
        method: 'POST',
        data
      }
    );
  };
}
