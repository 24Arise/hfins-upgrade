/**
 * @Description: 档案架设置
 * @Author: 向芳 <fang.xiang01@hand-china.com>
 * @Date: 2022/12/27 9:30
 * @LastEditTime: 2022/12/28 15:04
 * @Copyright: Copyright (c) 2021, Hand
 */
import { AxiosRequestConfig } from 'axios';
import { DataSetProps } from 'choerodon-ui/pro/lib/data-set/DataSet';
import { FieldFormat, FieldType } from 'choerodon-ui/pro/lib/data-set/enum';
import { getCurrentOrganizationId } from 'utils/utils';
import commonConfig from '@common/config/commonConfig';
import intl from 'utils/intl';

export default (): DataSetProps => ({
  transport: {
    read: ({ data, params }) => ({
      data: { standardType: 'SHELF', ...data },
      params,
      url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/standard`,
      method: 'GET'
    }),
    submit: ({ data, params }): AxiosRequestConfig => {
      return {
        data,
        params,
        url: `${commonConfig.ECM_API}/v1/${getCurrentOrganizationId()}/archive/standard`,
        method: 'POST'
      };
    }
  },
  events: {
    update: ({ record, name, value }) => {
      if (name === 'shelfType') {
        record.set('archivedType', null);
        if (value === 'SINGLE_FACE') {
          record.set('archivedType', 'ONE_SIDE');
          record.getField('archivedType').set('disabled', true);
        } else {
          record.getField('archivedType').set('disabled', false);
        }
      }
    },
    load: ({ dataSet }) => {
      dataSet.forEach(item => {
        if (!item.get('assignNum')) {
          item.init('assignNum', 0);
        }
      });
    }
  },
  fields: [
    {
      name: 'locationType',
      type: FieldType.string
    },
    {
      name: 'standardType',
      type: FieldType.string,
      required: true,
      defaultValue: 'SHELF'
    },
    {
      name: 'description',
      label: intl.get('hfsecm.archive.room.fileName').d('档案架名称'),
      type: FieldType.intl,
      required: true
    },
    {
      name: 'standardCode',
      label: intl.get('hfsecm.archive.room.standardCode').d('规格编码'),
      type: FieldType.string,
      format: FieldFormat.uppercase,
      required: true
    },
    {
      name: 'locationCode',
      label: intl.get('hfsecm.archive.room.fileCode').d('档案架编码'),
      type: FieldType.string,
      format: FieldFormat.uppercase
    },
    {
      name: 'length',
      label: intl.get('hfsecm.archive.room.shelfLength').d('长(cm)'),
      type: FieldType.number,
      required: true
    },
    {
      name: 'width',
      label: intl.get('hfsecm.archive.room.shelfWidth').d('宽(cm)'),
      type: FieldType.number,
      required: true
    },
    {
      name: 'height',
      label: intl.get('hfsecm.archive.room.shelfHeight').d('高(cm)'),
      type: FieldType.number,
      required: true
    },
    {
      name: 'rows',
      label: intl.get('hfsecm.archive.room.rows').d('层数'),
      type: FieldType.number
    },
    {
      name: 'cols',
      label: intl.get('hfsecm.archive.room.cols').d('列数'),
      type: FieldType.number
    },
    {
      name: 'rowNum',
      label: intl.get('hfsecm.archive.room.rows').d('层数'),
      type: FieldType.number,
      required: true
    },
    {
      name: 'colNum',
      label: intl.get('hfsecm.archive.room.cols').d('列数'),
      type: FieldType.number,
      required: true
    },
    {
      name: 'capacity',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.capacity').d('每格容量(个)'),
      required: true
    },
    {
      name: 'assignNum',
      type: FieldType.number,
      label: intl.get('hfsecm.archive.room.assignShelfNum').d('放置个数'),
      required: true,
      defaultValue: 0
    },
    {
      name: 'shelfType',
      type: FieldType.string,
      required: true,
      lookupCode: 'HFSECM.ARCHIVE_SHELF_TYPE',
      label: intl.get('hfsecm.archive.room.shelfType').d('档案架类型')
    },
    {
      name: 'archivedType',
      type: FieldType.string,
      required: true,
      lookupCode: 'HFSECM.ARCHIVED_TYPE',
      label: intl.get('hfsecm.archive.room.archivedType').d('归档类型')
    },

    {
      name: 'enabledFlag',
      type: FieldType.boolean,
      defaultValue: 1,
      label: intl.get('hfsecm.common.enabledFlag'),
      trueValue: 1,
      falseValue: 0
    }
  ]
});
